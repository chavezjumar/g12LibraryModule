<?php
$dbhost = "localhost";
$dbusername ="root";
$dbpassword ="";
$dbname ="event";

$server = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);


$email= $_POST['email'];
$password= $_POST['password'];
$username= $_POST['username'];
$gender= $_POST['gender'];
$fname= $_POST['fname'];
$lname= $_POST['lname'];
$account= $_POST['account'];

	
	$result =  $server->query("SELECT * from account where lname ='$lname' AND fname ='$fname' AND username ='$username' ");
$numrow = $result->num_rows;
if($numrow==1){
	
	echo "<script>alert('Account is already existing!');history.back();</script>";
}else{
	$result =  $server->query("INSERT INTO account 
					(lname,fname,gender,username,email,password,account) 
					values('$lname','$fname','$gender','$username', '$email', '$password', '$account')   ");				
echo "<script>alert('Registation Successful!');window.location.href='index.php'</script>";	
}

?>					