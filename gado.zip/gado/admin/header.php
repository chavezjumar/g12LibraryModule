<head>
<title>Calendar Event Module</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
			header{
				background-color: #3366CC;
			}
			body{background-color: #3399FF;
			}
			h2{
				font-size: 30px;
				font-family: arial;
				color: white;
			}
		</style>
</head>
	<body>
		<center>
				<header>
					<br>
					<h2>Asian Institute of Computer Studies </h2>
					<h2>Calendar Event Module</h2>
					<br>
				</header>
		</center>
	</body>	