<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="event";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);



$id = $_POST['id'];
$year=$_POST['year'];
$month=$_POST['month'];
$day=$_POST['day'];
$description=$_POST['description'];


$result =  $dbserver->query("SELECT * from event where id ='$id'");
$numrow = $result->num_rows;
if($numrow==1){
	
if($year==""||$month==""||$day==""||$description==""){
	echo "<script>alert('Please complete all fields');history.back();</script>";
}else{
$result =  $dbserver->query("UPDATE event SET 
		year='$year',
		month='$month',
		day='$day',
		description='$description'
		where id='$id' ");				
echo "<script>alert('Event Updated Successfully!');window.location.href='event-form.php'</script>";	
}
}
			
?>

