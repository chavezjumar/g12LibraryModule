<head>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<div id="content"><br>
<h1>Add event</h1>
<form class="insert-form" method="POST" action="add.php" enctype="multipart/form-data">
	<label class="lbl_add">SELECT YEAR:</label>
	<select name="year">
		<option></option>		
		<option value="2018">2018</option>
		<option value="2019">2019</option>
		<option value="2020">2020</option>
	</select>	<br><br>
	<label class="lbl_add">SELECT MONTH:</label>
	<select name="month">
		<option></option>		
		<option value="january">January</option>
		<option value="february">February</option>
		<option value="march">March</option>
		<option value="april">April</option>
		<option value="may">May</option>
		<option value="june">June</option>
		<option value="july">July</option>
		<option value="august">August</option>
		<option value="september">September</option>
		<option value="october">October</option>
		<option value="november">November</option>
		<option value="december">December</option>
	</select>	<br><br>
	<label class="lbl_add">DAY:</label><br>
		<input class="input_add" type="number" name="day"><br><br>
	<label class="lbl_add">DESCRIPTION:</label><br>
		<textarea style="height:100; width:250;" name="desc"></textarea><br><br>
		<input type="submit" value="ADD EVENT"><br>			
		</form>
		
</div>
<?php
include('footer.php');
?>


