<?php
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="event";

$connect = new mysqli ($dbhost,$dbusername,$dbpassword,$dbname);
	
$year=$_POST['year'];
$month=$_POST['month'];
$day=$_POST['day'];
$desc=$_POST['desc'];
	
	$result =  $connect->query("SELECT * from event where year ='$year' AND month ='$month' AND day ='$day' AND description ='$desc' ");
$numrow = $result->num_rows;
if($numrow=1){
	
	echo "<script>alert(' This Event is already existing!');history.back();</script>";
}else{
	$result =  $connect->query("INSERT INTO event 
					(year,month,day,description) 
					values('$year','$month','$day','$desc')   ");
					
echo "<script>alert('You added Event  Successfully!');window.location.href='home.php'</script>";	
}
?>