<?php

include('header.php');

?>
<center>
<div id="content"><br><br><br>
<a href="home.php">HOME</a>&nbsp&nbsp&nbsp
<a href="event-form.php">EVENT</a>&nbsp&nbsp&nbsp
<a href="logout.php" onclick="return confirm('Do you really want to Logout?');">LOGOUT?</a>
<style type="text/css">
	label{
			font-family: arial;
			font-size: 20px;
		}

	select{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	input{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	option{
		padding: 10px;
		font-size: 17px;
		border: 2px;
		border-radius: 10px;
	}
	textarea{
		border-radius: 10px;
		border:2px;
		font-size: 17px;
	}
	button{
		width: 150px;
		padding: 7px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	button:hover{
		background-color: #3366CC;
		color: white;	 
	}
	a{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	a:hover{
		background-color: #3366CC;
		color: white;	 
	}		
</style>
<h1>Add event</h1>




<form class="insert-form" method="POST" action="add.php" enctype="multipart/form-data">
	<label class="lbl_add">SELECT YEAR:</label>
	<select name="year">
		<option></option>		
		<option value="2018">2018</option>
		<option value="2019">2019</option>
		<option value="2020">2020</option>
	</select>	<br><br>
	<label class="lbl_add">SELECT MONTH:</label>
	<select name="month">
		<option></option>		
		<option value="01">January</option>
		<option value="02">February</option>
		<option value="03">March</option>
		<option value="04">April</option>
		<option value="05">May</option>
		<option value="06">June</option>
		<option value="07">July</option>
		<option value="08">August</option>
		<option value="09">September</option>
		<option value="10">October</option>
		<option value="11">November</option>
		<option value="12">December</option>
	</select>	<br><br>
	<label class="lbl_add">DAY:</label><br>
		<input class="input_add" type="number" name="day"><br><br>
	<label class="lbl_add">DESCRIPTION:</label><br>
		<textarea style="height:100; width:250;" name="description"></textarea><br><br>
		<a href="event-form.php">Back</a>
		<button type="submit"><strong>ADD EVENT</strong></button><br>			
		</form>
		
</div>
</center>

<?php
include('footer.php');
?>
