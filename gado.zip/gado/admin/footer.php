<style type="text/css">
	footer{
		text-align: center;		
	}
</style>



<footer><br>
Copyright All Rights Reserved &copy 2018 CEM
</footer>
<br><br><br>