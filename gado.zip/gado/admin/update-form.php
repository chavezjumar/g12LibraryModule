<?php

$id = $_GET['id'];
$year=$_GET['year'];
$month=$_GET['month'];
$day=$_GET['day'];
$description=$_GET['description'];
?>

<?php
include ('header.php');
?>

<style>
input{margin:5px;}
button{
		width: 150px;
		padding: 7px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	button:hover{
		background-color: #3366CC;
		color: white;	 
	}
	a{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	a:hover{
		background-color: #3366CC;
		color: white;	 
	}label{
			font-family: arial;
			font-size: 20px;
		}
		input{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}textarea{
		border-radius: 10px;
		border:2px;
		font-size: 17px;
	}	
</style>
<center>
<div id="content"><br>
		<h1>Update Event</h1>
				<form class="insert-form" method="POST" action="update.php">
						<input type="text" name="id" value="<?=$id?>" readonly hidden><br>
						<label>Year:</label><input type="text" name="year" value="<?=$year?>"><br>
						<label>Month:</label><input type="text" name="month" value="<?=$month?>"><br>
						<label>Day:</label><input type="text" name="day" value="<?=$day?>"><br><br>
						<label>Description:</label><br><textarea name="description" value="<?=$description?>"></textarea><br><br>
						<a href="event-form.php">Back</a>
						<button type="submit" >Update</button>
				</form>
</div>
</center>
<br><br><br><br><br>
<?php
include('footer.php');
?>

