<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="event";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$id = $_GET['id'];

$result =  $dbserver->query("DELETE from event where id='$id' ");
			
echo "<script>alert('You deleted Event info successfully!');window.location.href='event-form.php';</script>";					

?>

