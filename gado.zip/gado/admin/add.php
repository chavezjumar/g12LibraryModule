<?php
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="event";

$connect = new mysqli ($dbhost,$dbusername,$dbpassword,$dbname);
	
$year=$_POST['year'];
$month=$_POST['month'];
$day=$_POST['day'];
$description=$_POST['description'];




$year1 = date("Y");
$month1 = date("m");
$day1 = date("d");

if ( $year <= $year1 && $month < $month1){
echo "<script>alert('WARNING! INVALID INPUT. EVENT MUST NOT IN THE PAST.');history.back();</script>";
}else{
	$result =  $connect->query("SELECT * from event where year ='$year' AND month ='$month' AND day ='$day' AND description ='$description' ");


$numrow = $result->num_rows;
if($numrow==1){
	
	echo "<script>alert(' This Event is already existing!');history.back();</script>";
}else{
	$result =  $connect->query("INSERT INTO event 
					(year,month,day,description) 
					values('$year','$month','$day','$description') ");
					
echo "<script>alert('Event Successfully Added');window.location.href='event-form.php'</script>";	
}
}

?>