<?php 
include('header.php');
 ?>

<div id="content"><?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="event";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);
 

$year = date("Y");
$month = date("m");


$result =  $dbserver->query("SELECT * from event where year = '$year' ");
$numrow = $result->num_rows;
?>

<br>
<center><br><br>
<a href="home.php">HOME</a>&nbsp&nbsp&nbsp
<a href="event-form.php">EVENT</a>&nbsp&nbsp&nbsp
<a href="logout.php" onclick="return confirm('Do you really want to Logout?');">LOGOUT?</a>
<br><br>
<style type="text/css">
	a{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	a:hover{
		background-color: #3366CC;
		color: white;	 
	}	
</style>
<table border=1>

<tr><th colspan=12>Event</th></tr>
<tr>


<tr>

<th>ID</th>
<th>YEAR</th>
<th>MONTH</th>
<th>DAY</th>
<th>DESCRIPTION</th>
</tr>

<?php
if($numrow==0){
echo "<tr><td colspan=6 style='color:black;'><b>No Upcoming Event Yet</b></td></tr>";
}else{
while($row=mysqli_fetch_array($result)){

?>	
<tr>
<td><?=$row['id']?></td>
<td><?=$row['year']?></td>
<td><?=$row['month']?></td>
<td><?=$row['day']?></td>
<td><?=$row['description']?></td>

</tr>
<?php
}
}
?>

</table>

</center>
</table>
<br><br><br><br><br><br><br><br><br><br>	
	
	
</div>
<?php
include('footer.php');
?>	
