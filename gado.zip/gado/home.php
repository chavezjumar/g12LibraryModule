<! doctype html>
<html>
<head>
<title>Calendar Event Module</title>

</head>
<body><br><br><br>
<center>
<br><br>	
<h1>Asian Institute of Computer Studies </h1><br>
<h4>Calendar Event Module</h4>

<table border=5>
<th colspan=10>January 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>	
	</table>
	<br><br><br>
	
	<table border=5>

	<br><br>
	<th colspan=10>february 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	</table><br><br><br>
	<table border=5>
<br><br>
	<th colspan=10>march 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<table border=5>
<br><br>
	<th colspan=10>april 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	</table>
	<table border=5>
<br><br>
	<th colspan=10>may 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	</table>
	<table border=5>
<br><br>
	<th colspan=10>June 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	</table>
	<table border=5>
<br><br>
	<th colspan=10>july 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	</table>
	<table border=5>
<br><br>
	<th colspan=10>august 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<table border=5>
<br><br>
	<th colspan=10>september 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<table border=5>
<br><br>
	<th colspan=10>october 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<table border=5>
<br><br>
	<th colspan=10>november 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<table border=5>
<br><br>
	<th colspan=10>december 2018</th>
	<tr>
		<td>Sun.</td>
		<td>Mon.</td>
		<td>Tue.</td>
		<td>Wed.</td>
		<td>Thurs.</td>
		<td>Fri.</td>
		<td>Sat.</td>
	</tr>
	<tr>
		<td></td>
		<td><a href="#">1</a></td>
		<td><a href="#">2</a></td>
		<td><a href="#">3</a></td>
		<td><a href="#">4</a></td>
		<td><a href="#">5</a></td>
		<td><a href="#">6</a></td>
	</tr>
	<tr>
		<td><a href="#">7</a></td>
		<td><a href="#">8</a></td>
		<td><a href="#">9</a></td>
		<td><a href="#">10</a></td>
		<td><a href="#">11</a></td>
		<td><a href="#">12</a></td>
		<td><a href="#">13</a></td>
	</tr>
	<tr>
		<td>14</td>
		<td>15</td>
		<td>16</td>
		<td>17</td>
		<td>18</td>
		<td>19</td>
		<td>20</td>
	</tr>
	<tr>
		<td>21</td>
		<td>22</td>
		<td>23</td>
		<td>24</td>
		<td>25</td>
		<td>26</td>
		<td>27</td>
	</tr>
	<tr>
		<td>28</td>
		<td>29</td>
		<td>30</td>
		<td>31</td>
		<td></td>
		<td></td>
		<td></td>
	</tr>	
</table>
<br><br>
</center>

<a href="#">NEXT</a>


</body>
</html>