<style>
	input{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	input[type="radio"]{
		display: inline-block;
	}
	a{
		font-family: arial;
		font-size: 20px;
	}
	label{
		font-family: arial;
		font-size: 20px;
	}
	select{
		padding: 10px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	option{
		padding: 10px;
		font-size: 17px;
		border: 2px;
		border-radius: 10px;
	}
	button{
		padding: 7px;
		font-size: 15px;
		border: 2px;
		border-radius: 10px;
	}
	button:hover{
		background-color: #3366CC;
		color: white;	 
	}	
</style>	
<?php
	include('header.php');
?>
<html>
	<body>
		<center>
			<h2>Register</h2>
				<form action="register1.php" method="post">
					
					<label>First Name:</label>
						&nbsp&nbsp
					<input name="fname" type="text" required>
					
					<label>Last Name:</label>
						&nbsp&nbsp
					<input name="lname" type="text" required><br><br>
					
					<label>Gender:</label>
						&nbsp&nbsp
							<input type="radio" value="male" name="gender" required><label id="lbl_gen" >Male</label>
							<input type="radio" value="female" name="gender" required><label id="lbl_gen" >Female</label><br><br>
					
					<label>Username:</label>
						&nbsp&nbsp
					<input name="username" type="text" required>
					
					<label>Email:</label>
						&nbsp&nbsp
					<input name= "email" type="text"  maxlength="50"  autocomplete="off">
					
					<label>Password:</label>
						&nbsp&nbsp
					<input id="password" name="password" type="password" required>
					<br><br>
					
					<label>Register As:</label>
						&nbsp&nbsp
							<select name="account" required>
								<option></option>
								<option value="admin">Admin</option>
								<option value="student">Student</option>
							</select><br><br>
					
					  <a href="index.php">Back</a>
			   		   &nbsp&nbsp
			   		   <button type="submit" class="button">Register</button>
				
				</form>
		
	</center>						
	</body>
</html>
	
