<! doctype html>
<html>
<head>
	<title>Calendar Event Module</title>
	<link rel="stylesheet" type="text/css" href="style.css">
		<style type="text/css">
			header{
				background-color: #3366CC;
			}
			body{background-color: #3399FF;
			}
			h2{
				font-size: 30px;
				font-family: arial;
				color: white;
			}
			label{
				font-family: arial;
				font-size: 20px;
			}
			h4{
				font-family: arial;
				font-size: 20px;
			}
			input{
				padding: 10px;
				font-size: 15px;
				border: 2px;
				border-radius: 10px;
			}
			select{
				padding: 10px;
				font-size: 15px;
				border: 2px;
				border-radius: 10px;
			}
			option{
				padding: 10px;
				font-size: 17px;
				border: 2px;
				border-radius: 10px;
			}
			button{
				padding: 7px;
				font-size: 15px;
				border: 2px;
				border-radius: 10px;
			}
			button:hover{
		background-color: #3366CC;
		color: white;	 
	}	
	a{
		color: black;
	}
			a:hover{
		color: white;
		 
	}	
		</style>
</head>

<body>
	<center>
		<header>
			<br>
			<h2>Asian Institute of Computer Studies </h2>
			<h2>Calendar Event Module</h2>
			<br>
		</header>
		<br><br><br>
		
		<form method="POST" action="login.php">
			<label>Username:</label><br>
				<input type="text" name="username"><br><br>
			<label>Password:</label><br>
				<input type="password" name="password">
				<br><br>
			<label>Login As:</label>
					<select name="account">
						<option value="admin">Admin</option>
						<option value="student">Student</option>
					</select>
			<br><br>
					<button type="submit"><strong>Login</strong></button>
		</form>
		<h4>Not yet Registered? Click <a href="registerform.php">Yes.</a></h4>
	</center>
</body>	
</html>
<?php
include('footer.php');
?>