<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="luto_db";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$id = $_GET['id'];

$result =  $dbserver->query("DELETE from foods_tb where id='$id' ");
			
echo "<script>alert('RECIPE Deleted!');window.location.href='menu.php';</script>";					

?>

