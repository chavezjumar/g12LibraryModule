<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="luto_db";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$category = "drink";

$result =  $dbserver->query("SELECT * from foods_tb where category ='$category'");
$numrow = $result->num_rows;

?>
<html>

<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/w3.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	    <link rel="stylesheet" href="css/style.css">
	    <link rel="stylesheet" href="css/style1.css">
	    <script src="jquery/jquery-3.3.1.min.js"></script>
	    <script src="bootstrap/js/bootstrap.min.js"></script>
		<title>MENU</title>
		<style type="text/css">	
			body{margin:0;background-color: lightblue;height: auto;width: 100%;}
			.a_tab{display: center; }
			.image{height: 500px;
			width:500px;
				}
			.title{
				font-size: 30px;
				text-align: center;
				padding: 10px;
			}	
			.tb_image{
				text-align: center;
			}.body{
				height: auto;
			}
		</style>
	</head>
	
	<header>
		<a class="logo" href="index.php"><img src="img/bms.png"></a>
		
		<ul class="ul_head">
			<center>
				<li><a style="color:black;" class="pick" href="index.php">HOME</a></li> |
				<li><a style="color:black;" class="pick" href="menu.php">MENU</a></li> |
				<li><a style="color:black;" class="pick" href="addmenu.php">ADD MENU</a></li>
			</center>
		</ul>
	</header>
	<div class="body"><br>
	
		<center>	
		<form action="search.php" method="POST"  >
						<label style="font-size:17px;">Search for:</label>
						<select style="font-size:17px;" name="filter">
							<option value="id">ID</option>
							<option value="title">DISH</option>
							<option value="description">RECIPE</option>
						</select>
						
							<input style="font-size:17px;" type="search" name="keyword" placeholder="Search">
							<input style="font-size:17px;" type="submit" value="search">
							</center>
						</form>	
						</center>
						<center>
			<a href="dessert.php"><button class="btn-primary">DESSERTS</button></a>
			<a href="drink.php"><button class="btn-primary">DRINKS</button></a>
			<a href="meal.php"><button class="btn-primary">MEAL</button></a>
			<a href="appetizer.php"><button class="btn-primary">APPETIZER</button></a>
			<br><br>
		</center>
		<?php
		if($numrow==0){
				echo "<script>alert('Sorry. Foods Is NOT Available.');history.back();</script>";
				}else{
				
			
				while($row=mysqli_fetch_array($result)){
		?>
		<center>
		<table>

			<tr class="title"><td>ID: <?=$row['id']?></td></tr>
			<tr class="title"><td><?=$row['title']?></td></tr>
			<tr  class="tb_image"><td colspan="3"><a  href="modal.php?id=<?=$row['id']?>&title=<?=$row['title']?>&file=<?=$row['file']?>&description=<?=$row['description']?>"><img class="image" src="<?=$row['file']?>"></a></td></tr>
			<tr>
			<td colspan="3" class="title"><a class="a_tab" href="dishupdate.php?id=<?=$row['id']?>&title=<?=$row['title']?>&file=<?=$row['file']?>&description=<?=$row['description']?>">UPDATE			
			
			 &nbsp <a class="a_tab" href="remove.php?id=<?=$row['id']?>" onclick="return confirm('Do you really want to remove this Recipe?');">REMOVE</a></td>
			</tr>
		</table>
		</center>
			



		<?php
			}
			}
		?>
	</div>



	<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
	</footer>
	</body>
</html>

