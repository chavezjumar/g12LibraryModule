<div id="id01" class="w3-modal">
						
					    <div class="w3-modal-content w3-animate-top w3-card-4">
					      <div class="w3-container w3-teal"> 
					        <span onclick="document.getElementById('id01').style.display='none'" 
					        class="w3-button w3-display-topright">&times;</span>
					        <h2><?=$row['title']?></h2>
					      </div>
					      <div class="w3-container">
							<br>
							<iframe src="<?=$row['file']?>" height="500" width="500"></iframe>
					        <p><?=$row['description']?></p>
					        <p>Some text..</p>
					      </div>
					      <footer class="w3-container w3-teal">
					        <p>Modal Footer</p>
					      </footer>
					    </div>
						
					  </div>


<?php
				if($numrow==0){
				echo "<tr><td colspan=5 style='color:black;'><b> Not Available</b></td></tr>";
				}else{
				
			
				while($row=mysqli_fetch_array($result)){
			?>
				<?php
				while($row=mysqli_fetch_array($result)){
				?>
							<a href="#id01"><img  class="image"src="<?=$row['file']?>"></a>

					<div id="id01" class="w3-modal">
						
					    <div class="w3-modal-content w3-animate-top w3-card-4">
					      <div class="w3-container w3-teal"> 
					        <span onclick="document.getElementById('id01').style.display='none'" 
					        class="w3-button w3-display-topright">&times;</span>
					        <h2><?=$row['title']?></h2>
					      </div>
					      <div class="w3-container">
							<br>
							<iframe src="<?=$row['file']?>" height="500" width="500"></iframe>
					        <p><?=$row['description']?></p>
					        <p>Some text..</p>
					      </div>
					      <footer class="w3-container w3-teal">
					        <p>Modal Footer</p>
					      </footer>
					    </div>
						
					  </div>
					
						<?php
						}
						}
						}
						?>	
			

			.style.display='block'



			<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="luto_db";

$dbserver= new mysqli($dbhost,$dbuser,$dbpass,$dbname);



$result =  $dbserver->query("SELECT * from foods_tb");
$numrow = $result->num_rows;



?>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/w3.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	    <link rel="stylesheet" href="css/style.css">
	    <link rel="stylesheet" href="css/style1.css">
	    <script src="jquery/jquery-3.3.1.min.js"></script>
	    <script src="bootstrap/js/bootstrap.min.js"></script>
		<title>MENU</title>
		<style type="text/css">	
			body{margin:0;background-color: lightblue;height: auto;width: 100%;}
			.a_tab{display: center; }
			.image{height: 40%;
			width:30%;
			display: inline-block;}
		</style>
	</head>
	
	<header>
		<a class="logo" href="index.php"><img src="img/bms.png"></a>
		
		<ul class="ul_head">
			<center>
				<li><a style="color:black;" class="pick" href="index.php">HOME</a></li> |
				<li><a style="color:black;" class="pick" href="menu.php">MENU</a></li> |
				<li><a style="color:black;" class="pick" href="addmenu.php">ADD MENU</a></li>
			</center>
		</ul>
	</header>

	<div class="body"><br>
		<center>	
			<a href="dessert.php"><button class="btn-primary">DESSERTS</button></a>
			<a href="drink.php"><button class="btn-primary">DRINKS</button></a>
			<a href="meal.php"><button class="btn-primary">MEAL</button></a>
			<a href="appetizer.php"><button class="btn-primary">APPETIZER</button></a>
			<br><br>
		</center>
		<?php
		if($numrow==0){
				echo "<script>alert('Sorry. Foods Is NOT Available.');history.back();</script>";
				}else{
				
			
				while($row=mysqli_fetch_array($result)){
		?>
							<a href="#id01"><img  class="image"src="<?=$row['file']?>"></a>





		<?php
			}
			}
		?>
	</div>

</html>
	<img onclick="document.getElementById('id01').style.display='block'" class="image"src="<?=$row['file']?>"></a>






<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/w3.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	    <link rel="stylesheet" href="css/style.css">
	    <link rel="stylesheet" href="css/style1.css">
	    <script src="jquery/jquery-3.3.1.min.js"></script>
	    <script src="bootstrap/js/bootstrap.min.js"></script>
		<title>MENU</title>
		<style type="text/css">	
			body{margin:0;background-color: lightblue;height: auto;width: 100%;}
			.a_tab{display: center; }
			.image{height: 40%;
			width:30%;
			display: inline-block;}
		</style>
	</head>
	
	<header>
		<a class="logo" href="index.php"><img src="img/bms.png"></a>
		
		<ul class="ul_head">
			<center>
				<li><a style="color:black;" class="pick" href="index.php">HOME</a></li> |
				<li><a style="color:black;" class="pick" href="menu.php">MENU</a></li> |
				<li><a style="color:black;" class="pick" href="addmenu.php">ADD MENU</a></li>
			</center>
		</ul>
	</header>

	<div class="body"><br>
		<center>	
			<a href="dessert.php"><button class="btn-primary">DESSERTS</button></a>
			<a href="drink.php"><button class="btn-primary">DRINKS</button></a>
			<a href="meal.php"><button class="btn-primary">MEAL</button></a>
			<a href="appetizer.php"><button class="btn-primary">APPETIZER</button></a>
			<br><br>
		</center>
		<?php
		if($numrow==0){
				echo "<script>alert('Sorry. Foods Is NOT Available.');history.back();</script>";
				}else{
				
			
				while($row=mysqli_fetch_array($result)){
		?>
	<div class="w3-container">
<img onclick="document.getElementById('id01').style.display='block'" class="image" src="<?=$row['file']?>">
	
	 
  <div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-animate-top w3-car  d-4">
      <header class="w3-container w3-teal"> 
        <span onclick="document.getElementById('id01').style.display='none'"
        class="w3-button w3-display-topright">&times;</span>
        <h2>Modal Header</h2>
      </header>
      <div class="w3-container">
        <p>Some text..</p>
        <p>Some text..</p>
      </div>
      <footer class="w3-container w3-teal">
        <p>Modal Footer</p>
      </footer>
    </div>
  </div>
</div>





		<?php
			}
			}
		?>
	</div>

</html>
\

 <div class="body"><br>
  <div class="w3-container">
  <h2>W3.CSS Animated Modal</h2>
  <p>Zoom in the modal with the w3-animate-zoom class, or slide in the modal from a specific direction using the w3-animate-top, w3-animate-bottom, w3-animate-left or w3-animate-right class:</p>
  <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-black">Open Animated Modal</button>

  <div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-animate-top w3-card-4">
      <header class="w3-container w3-teal"> 
        <span onclick="document.getElementById('id01').style.display='none'" 
        class="w3-button w3-display-topright">&times;</span>
        <h2>Modal Header</h2>
      </header>
      <div class="w3-container">
        <p>Some text..</p>
        <p>Some text..</p>
      </div>
      <footer class="w3-container w3-teal">
        <p>Modal Footer</p>
      </footer>
    </div>
  </div>
</div>
</div>



------>>>search.php


<?php
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="luto_db";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$keyword=$_POST['keyword'];
$filter=$_POST['filter'];

$result =  $dbserver->query("SELECT * from foods_tb where $filter like '%$keyword%' ");

$numrow = $result->num_rows;

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
      <title>SEARCH</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/style1.css">
        <script src="jquery/jquery-3.3.1.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>

</head>

<body>
	<header>
		<a class="logo" href="index.php"><img src="img/bms.png"></a>
		<ul>
			<li><a class="pick" href="index.php">HOME</a></li> |
			<li><a class="pick" href="menu.php">MENU</a></li> |
			<li><a class="pick" href="addmenu.php">ADD MENU</a></li>
			
		</ul>
	</header>
	<div class="body"><br>
<table border="1" class="table">
			
<?php
if($numrow==0){
echo "<tr><td colspan=5 style='color:black;'><b> Not Available</b></td></tr>";
}else{
while($row=mysqli_fetch_array($result)){

?>
<tr>
	<td><?=$row['title']?></td>
</tr>
<tr>
	<td><img src="<?=$row['file']?>" style="width:500px; height:500px;"></td>
</tr>
<tr>
	<td><a  class="a_tab" href="dishupdate.php?id=<?=$row['id']?>&title=<?=$row['title']?>&description=<?=$row['description']?>&file=<?=$row['file']?>">UPDATE
	
	 &nbsp <a class="a_tab" href="remove.php?id=<?=$row['id']?>" onclick="return confirm('Do you really want to remove this Recipe?');">REMOVE</a></td>

</tr>

<?php
}
}
?>
				</table>
	</div>
	</body>
</html>




