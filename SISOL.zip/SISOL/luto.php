<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="luto_db";

$dbserver= new mysqli($dbhost,$dbuser,$dbpass,$dbname);
$category= $_POST['category'];
$title= $_POST['title'];
$description= $_POST['description'];


//To save photo
if(!isset($_FILES['file']['tmp_name'])){
	echo "<script>alert('Please upload photo!');history.back();</script>";
}else{
addslashes(file_get_contents($_FILES['file']['tmp_name']));
addslashes($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'],"photos/" . $_FILES['file']['name']);
$file = "photos/" . $_FILES['file']['name'];


$result =  $dbserver->query("SELECT * from foods_tb where title ='$title'");
$numrow = $result->num_rows;


if($numrow==1){
		echo "<script>alert('Recipe is Existing');history.back();</script>";
	}
		else{
	
	
			if($title==""||$description==""){
				echo "<script>alert('Please complete all fields');history.back();</script>";
				}else{
				$result =  $dbserver->query("INSERT INTO foods_tb 
									(category,title,description,file) 
									values('$category','$title','$description','$file')   ");				
				echo "<script>alert('You Add Recipe Successfully!');window.location.href='menu.php'</script>";	
											
	}
	}
	}	
?>