<!DOCTYPE html>
<html>
<head>
      <title>HOME</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/style1.css">
        <script src="jquery/jquery-3.3.1.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>
    </head>
<body>
<header>
<a class="logo" href="index.php"><img src="img/bms.png"></a>

<ul class="ul_head">
<center>
<li><a style="color:black;" class="pick" href="index.php">HOME</a></li> |
<li><a style="color:black;" class="pick" href="menu.php">MENU</a></li> |
<li><a style="color:black;" class="pick" href="addmenu.php">ADD MENU</a></li> 


</center>
</ul>
</header>
<div class="body">

<br>
<marquee>
<img src="img/1.jpg" alt="marquee4" style="height:500px; width:450px; ">
<img src="img/marquee2.png" alt="marquee2" style="height:500px; width:400px; ">
<img src="img/sisol.jpg" alt="sisol" style="height:500px; width:400px; ">
</marquee>


</div><br>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
</footer>
</body>
</html>