<!-- <!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<header>
<a class="logo" href="index.php"><img src="img/bms.png"></a>
<ul>
<li><a class="pick" href="index.php">HOME</a></li> |
<li><a class="pick" href="#">MENU</a></li> |
<li><a class="pick" href="update.php">UPDATE</a></li> |
<li><a class="pick" href="#">ABOUT US</a></li> |
<li><a class="pick" href="#">SEARCH</a></li>
</ul>
</header>
<form>
<label>Name of the dish : </label>
<input type="text" class="title" name="title" >

</form>
</body>

</html> -->

<!DOCTYPE html>
<html>
<head>
      <title>ADD MENU</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/style1.css">
        <script src="jquery/jquery-3.3.1.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>
    </head>
<body>
<header>
	<a class="logo" href="index.php"><img src="img/bms.png"></a>
	<ul>
		<li><a style="color:black;" class="pick" href="index.php">HOME</a></li> |
		<li><a style="color:black;" class="pick" href="menu.php">MENU</a></li> |
		<li><a style="color:black;" class="pick" href="addmenu.php">ADD MENU</a></li> 
	</ul>
</header><center><br><br>
<div class="bodyup">
	<h1 style="color:green;">Please fill-up the following:</h1>
		<form method="POST" action="luto.php" enctype="multipart/form-data">
		<center>	Category :
				<select  class="selad" name="category">
					<option value=""></option>
					<option value="appetizer">Apppetizer</option>
					<option value="meal">Meal</option>
					<option value="drink">Drinks</option>
					<option value="dessert">Dessert</option>
				</select><br>


			<label>Name: </label>
				<input type="text" class="title" name="title" >
			<label for="file">Picture: </label>
				<input type="file" class="file" name="file" >
			<label>Recipe and instructions: </label>
				<textarea class="desc" name="description"></textarea><br>
				
				<button type="submit" class="button">SUBMIT</button>
			
		</form>
</div>
</center><br><br><br><br><br><br><br>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
</footer>
</body>
</html>








