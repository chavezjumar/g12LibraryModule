<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="luto_db";

$dbserver= new mysqli($dbhost,$dbuser,$dbpass,$dbname);


$id = $_GET['id'];
$title = $_GET['title'];
$file = $_GET['file'];
$description = $_GET['description'];




$result =  $dbserver->query("SELECT * from foods_tb where id = '$id' ");
$numrow = $result->num_rows;



?>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/w3.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/style1.css">
      <script src="jquery/jquery-3.3.1.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>MENU</title>
    <style type="text/css"> 
      body{margin:0;background-color: lightblue;height: auto;width: 100%;}
      .a_tab{display: center; }
      .image{height:430px;
      width:500px;
      margin-left: 12.5%;
        }
      .title{
        font-size: 30px;
        text-align: center;
        padding: 10px;
      } 
      .tb_image{
        text-align: center;
      }

      .dv_left{
        height: 100%;
        width:50%;
        float: left;
      }

      .dv_right{
        height: 100%;
        width:50%;
        float: left;
      }
      .body{
        margin: 0;
      }


        .desc{
          background-color: transparent;
          height: 100%;
          width: 100%;
          font-size: 15px;
          font-family: verdana;
        }


    </style>
  </head>
  
  <header>
    <a class="logo" href="index.php"><img src="img/bms.png"></a>
    
    <ul class="ul_head">
      <center>
        <li><a style="color:black;" class="pick" href="index.php">HOME</a></li> |
        <li><a style="color:black;" class="pick" href="menu.php">MENU</a></li> |
        <li><a style="color:black;" class="pick" href="addmenu.php">ADD MENU</a></li>
      </center>
    </ul>
  </header>
  <?php
        if ($numrow==1){
              while ($row = mysqli_fetch_assoc($result)){
      ?>


  <div class="body">
      
        <div class="dv_left">
        <center>
          <h1><?=$row['title']?></h1>
          <img  class="image" src="<?=$row['file']?>">
        </center>  
          </div>
          <div class="dv_right"><br>
              <h1><strong>Recipe & Instructions:</strong></h1>
              <h1 class="desc">
                      <?=$row['description']?>

              </h1>
          </div>
  </div>


  <?php
}
}
  ?>
}
</html>
