-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2017 at 06:01 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `luto_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `foods_tb`
--

CREATE TABLE IF NOT EXISTS `foods_tb` (
`id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `file` varchar(250) NOT NULL,
  `description` varchar(20000) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `foods_tb`
--

INSERT INTO `foods_tb` (`id`, `title`, `file`, `description`) VALUES
(9, 'jumar', 'photos/222.jpg', 'people'),
(10, 'sinigang na baboy', 'photos/11 - Copy.jpg', 'revipdkbg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `foods_tb`
--
ALTER TABLE `foods_tb`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `foods_tb`
--
ALTER TABLE `foods_tb`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
