<?php
error_reporting(0);


$id = $_GET['id'];
$title= $_GET['title'];
$file= $_GET['file'];
$description= $_GET['description'];

?>

<style>

li{
	display:block;
	height:30;
}
.pick{
	color: black;
}
.pick{
	display:inline-block;
	padding:10px;
	color: black;
	

}

.pick:hover{
	display:inline-block;	
	background-color:white;
	border-radius: 7px;
	
}
</style>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
      <title>UPDATE</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/style1.css">
        <script src="jquery/jquery-3.3.1.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>

</head>
<body>
	<header>
		<a class="logo" href="index.php"><img src="img/bms.png"></a>
		<ul>
			<li><a class="pick" href="index.php">HOME</a></li> |
			<li><a class="pick" href="menu.php">MENU</a></li> |
			<li><a class="pick" href="addmenu.php">ADD MENU</a></li>
		</ul>
	</header>	<br><br><br><br>
<center>
<div class="bodyup">
<h1>Update dish</h1>

<form action="update.php?id=<?=$id?>" method="POST" enctype="multipart/form-data">

<label>ID:</label><input name="id" value="<?=$id?>" placeholder:"ID	"  readonly>
<label>Name:</label><input name="title" placeholder="New Name of Dish" value="<?=$title?>">
<label for="file"> New Image :</label><input type="file" name="file" placeholder="New Image" value="<?=$file?>">
<label>New Recipe & Instructions :</label>
<textarea name="description" required></textarea><br>
<a href="menu.php?id=<?=$id?>">&laquo Back</a>
<button type="submit" class="button">Update</button>	

</ul><br><br><br><br><br><br><br><br><br><br><br><br>
</form>

</div>
</center>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
</footer>		
</body>
	
	