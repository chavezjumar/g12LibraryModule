<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="luto_db";

$dbserver= new mysqli($dbhost,$dbuser,$dbpass,$dbname);

$id = $_POST['id'];
$title= $_POST['title'];
$description= $_POST['description'];


if (!isset($_FILES['file']['tmp_name'])) {
	echo "<script>alert('Please upload photo!');history.back();</script>";
	}else{

//To save photo
	addslashes(file_get_contents($_FILES['file']['tmp_name']));
addslashes($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'],"photos/" . $_FILES['file']['name']);
$file = "photos/" . $_FILES['file']['name'];



$result =  $dbserver->query("UPDATE foods_tb SET 
		title='$title',
		file = '$file',
		description='$description'
		where  id = '$id' ");				

					
	echo "<script>alert('Update Successfully!');window.location.href = 'menu.php';</script>"; 
	}											
		
				
?>                    