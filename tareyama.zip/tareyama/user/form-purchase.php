<?php

include('header.php');
$brand=$_GET['brand'];
$quantity=$_GET['quantity'];
$price=$_GET['price'];


?>
<style>
input{margin:5px;}
</style>
<div id="content"><br>
<a href="index.php"><button colspan=4>HOME</button></a>
<a href="drinks-form.php"><button colspan=4>DRINKS</button></a>
<a href="foods-form.php"><button colspan=4>FOODS</button></a>
<a href="desserts-form.php"><button colspan=4>DESSERTS</button></a>
<br><br>

<h1>Purchase</h1>
<form class="insert-form" method="GET" action="total.php">
Brand:<input type="text" name="brand" value="<?=$brand?>"readonly><br>
Maximum to Buy:<input type="text" name="max" value="<?=$quantity?>"readonly ><br>
Price:<input type="text" name="price" value="<?=$price?>"readonly><br>
Quantity:<input type="number" name="quantity"><br>

<a href="total.php?
		brand=<?=$row['brand']?>
		&max=<?=$row['max']?>
		$quantity=<?=$row['quantity']?>
		&price=<?=$row['price']?>" style="color:black;">
	<button type="submit" >Total</button>
</a>






</form>
</div>
<?php
include('footer.php');
?>	