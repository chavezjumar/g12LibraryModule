<?php

include('header.php');
$brand=$_GET['brand'];
$max=$_GET['max'];
$quantity=$_GET['quantity'];
$price=$_GET['price'];


$total = $price * $quantity;
?>
<style>
input{margin:5px;}
</style>
<div id="content"><br>
<a href="index.php"><button colspan=4>HOME</button></a>
<a href="drinks-form.php"><button colspan=4>DRINKS</button></a>
<a href="foods-form.php"><button colspan=4>FOODS</button></a>
<a href="desserts-form.php"><button colspan=4>DESSERTS</button></a>
<br><br>

<h1>Purchase</h1>
<form class="insert-form" method="GET" action="cash.php">
Brand:<input type="text" name="brand" value="<?=$brand?>"readonly><br>
Brand:<input type="text" name="brand" value="<?=$brand?>"readonly>
<input type="text" name="max" value="<?=$max?>"readonly hidden><br>
Price:<input type="text" name="price" value="<?=$price?>"readonly><br>
Quantity:<input type="text" name="quantity" value="<?=$quantity?>"readonly ><br>
Total:<input type="number" name="total" value="<?=$total?>"readonly><br>
Cash:<input type="number" name="cash"><br>


 <a href="cash.php?
 brand=<?=$row['brand']?>
 &max=<?=$row['max']?>
 &quantity=<?=$row['quantity']?>
  &price=<?=$row['price']?>
 &total=<?=$row['total']?>
 &cash=<?=$row['cash']?>"
 onclick="return confirm('Do you really want to purchase?');" style="color:black;">
 <button>Purchase</button></a>
</form>
</div>	

<?php
include('footer.php');
?>	