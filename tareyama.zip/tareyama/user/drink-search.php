<?php


include('header.php');


//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$keyword=$_POST['search'];
$filter=$_POST['filter'];
$drink="drinks";

$result =  $dbserver->query("SELECT * from inventory where item='$drink' AND $filter like '%$keyword%'  ");
$numrow = $result->num_rows;
?>
<div id="content"><br><center>
<a href="index.php"><button colspan=4>HOME</button></a>
<a href="drinks-form.php"><button colspan=4>DRINKS</button></a>
<a href="foods-form.php"><button colspan=4>FOODS</button></a>
<a href="desserts-form.php"><button colspan=4>DESSERTS</button></a>
<br><br>
<table border=1 style="background:white;">

<tr><th colspan=12>You search for <i><?=$keyword?></i></th></tr>
<tr>

<tr>
<th colspan=6>

<form method="POST" action="drink-search.php">
<select name="filter">
<option value="id">ID</option>
<option value="brand">BRAND</option>

</select>
<input type="search" name="search" placeholder="Search..">
<button type="submit" >SEARCH</button>
</form>

</th>
</tr>

<tr>

<th>ID</th>
<th>BRAND</th>
<th>QUANTITY</th>
<th>PRICE</th>
<th>ACTION</th>
</tr>

<?php
if($numrow==0){
echo "<tr><td colspan=6 style='color:black;'><b>Drinks Not Available</b></td></tr>";
}else{
while($row=mysqli_fetch_array($result)){

?>	
<tr>
<td><?=$row['id']?></td>
<td><?=$row['brand']?></td>
<td><?=$row['quantity']?></td>
<td><?=$row['price']?></td>
<td><a href="form-purchase.php?id=<?=$row['id']?>&brand=<?=$row['brand']?>&quantity=<?=$row['quantity']?>&price=<?=$row['price']?>" style="color:black;">Purchase?</a>

</tr>
<?php
}
}
?>


</table>
</center>



</div>
<?php
include('footer.php');
?>