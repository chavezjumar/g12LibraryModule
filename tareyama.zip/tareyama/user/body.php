<div id="content"><?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$result =  $dbserver->query("SELECT * from inventory");
$numrow = $result->num_rows;

?>

<br><center>
<label style="color:white;">PURCHASE</label>
<a href="drinks-form.php"><button colspan=4>DRINKS</button></a>
<a href="foods-form.php"><button colspan=4>FOODS</button></a>
<a href="desserts-form.php"><button colspan=4>DESSERTS</button></a>
<a href="logout.php"><button colspan=4>LOGOUT?</button></a>
<br><br>
<table border=1 style="background:white;">
<tr><th colspan=12>AVAILABLE</th></tr>
<tr>

<tr>
<th colspan=6>

<form method="POST" action="form-search.php">
<select name="filter">
<option value="id">ID</option>
<option value="item">ITEM</option>
<option value="brand">BRAND</option>

</select>
<input type="search" name="search" placeholder="Search..">
<button type="submit" >SEARCH</button>
</form>

</th>
</tr>

<tr>

<th>ID</th>
<th>ITEM</th>
<th>BRAND</th>
<th>QUANTITY</th>
<th>PRICE</th>
</tr>

<?php

while($row=mysqli_fetch_array($result)){

?>	
<tr>
<td><?=$row['id']?></td>
<td><?=$row['item']?></td>
<td><?=$row['brand']?></td>
<td><?=$row['quantity']?></td>
<td><?=$row['price']?></td>
</tr>
<?php

}
?>

</table>

</center>
</table>

	
	
	
	
	</center>
	
	
	
</div>