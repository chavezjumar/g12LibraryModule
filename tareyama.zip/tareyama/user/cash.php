<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";
$dbserver = new mysqli ($dbhost,$dbusername,$dbpassword,$dbname);

$brand=$_GET['brand'];
$max=$_GET['max'];
$quantity=$_GET['quantity'];
$price=$_GET['price'];
$total = $_GET['total'];
$cash = $_GET['cash'];



$result =  $dbserver->query("SELECT from inventory where brand='$brand' ");

$minus = $max - $quantity ;
$change = 	$cash - $total ;

$result =  $dbserver->query("UPDATE inventory SET 
		quantity='$minus'
		where brand='$brand' ");				

echo "<script>alert('Thank You for your Purchase!! Your Total Change is $change');window.location.href='index.php';</script>";					

?>