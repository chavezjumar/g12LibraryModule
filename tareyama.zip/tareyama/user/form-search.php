<?php


include('header.php');


//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$keyword=$_POST['search'];
$filter=$_POST['filter'];


$result =  $dbserver->query("SELECT * from inventory where $filter like '%$keyword%'  ");
$numrow = $result->num_rows;
?>
<div id="content"><br><center>

<button>



<table border=1 style="background:white;">

<tr><th colspan=12>You search for <i><?=$keyword?></i></th></tr>
<tr>

<tr>
<th colspan=6>

<form method="POST" action="form-search.php">
<select name="filter">
<option value="id">ID</option>
<option value="item">ITEM</option>
<option value="brand">BRAND</option>

</select>
<input type="search" name="search" placeholder="Search..">
<button type="submit" >SEARCH</button>
</form>

</th>
</tr>

<tr>

<th>ID</th>
<th>ITEM</th>
<th>BRAND</th>
<th>QUANTITY</th>
<th>PRICE</th>
</tr>

<?php
if($numrow==0){
echo "<tr><td colspan=6 style='color:black;'><b>Not Available</b></td></tr>";
}else{
while($row=mysqli_fetch_array($result)){

?>	
<tr>
<td><?=$row['id']?></td>
<td><?=$row['item']?></td>
<td><?=$row['brand']?></td>
<td><?=$row['quantity']?></td>
<td><?=$row['price']?></td>
</tr>
<?php
}
}
?>


</table>
<a href="index.php" style="color:white;">back</a>
</center>



</div>
<?php
include('footer.php');
?>