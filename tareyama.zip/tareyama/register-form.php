<html>
<head>
	<title>Ordering List Module</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<style>
input{margin:5px;}
</style>

	<h1 style="color:white">Register</h1>
<form  method="POST" action="reg.php" enctype="multipart/form-data">
		<input type="text" name="lname" placeholder="Last Name:" required><br>
		<input type="text" name="fname" placeholder="First Name:" required><br>
		<label id="lbl_gen">Gender:</label><br>
		<input type="radio" value="male" name="gender" required><label id="lbl_gen" >Male</label>
		<input type="radio" value="female" name="gender" required><label id="lbl_gen" >Female</label><br>
		<input type="tex" name="username" placeholder="Username:" required><br>
		<input type="password" name="password" placeholder="Password:" required><br>
		<input type="password" name="repassword" placeholder="Confirm Password:" required><br>
		<label id="lbl_gen">Register as:</label>
		<select name="account">
		<option value="admin">Admin</option>
		<option value="user">User</option>
		</select><br><br>

	
	<a href="index.php">Back</a>
	<button type="submit" ><img class="img" src="icon/b_usradd.png"></button>
</form>

</html>