<! doctype html>
<html>
	<head>
			<title>Ordering List Module</title>
			<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<center><br><br>	
	<h2>Asian Institute of Computer Studies </h2><br></center>

	<h2>Ordering List Module</h2>

		<form method="POST" action="login.php">
			<label class="lbl_log">Username:</label><br>
				<input class="log" type="text" name="username"><br>
			<label class="lbl_log">Password:</label><br>
				<input class="log" type="password" name="password"><br><br>
			<label class="lbl_log">Login As:</label>
				<select name="account">
				<option value="admin">Admin</option>
				<option value="user">User</option>
				</select>
				<br><br>
				<input type="submit" id="login" value="Login">

		</form>
		<a href="register-form.php"><button>Not yet Registered?</button></a>
</html>