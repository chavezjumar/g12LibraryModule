<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="stud_db";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$keyword=$_POST['search'];
$filter=$_POST['filter'];


$result =  $dbserver->query("SELECT * from user_tbl where $filter like '%$keyword%'  ");
$numrow = $result->num_rows;
?>

<table border=1>

<tr><th colspan=5>You search for <i><?=$keyword?></i></th><th><a href="form-insert.php"><img src="icon/plus.png"></a></th> </tr>
<tr>

<tr>
<th colspan=6>

<form method="POST" action="#">
<select name="filter">
<option value="stud_name">Name</option>
<option value="stud_tracks">Tracks</option>
</select>
<input type="search" name="search" placeholder="Search..">
<button type="submit" ><img src="icon/b_search.png"></button>
</form>

</th>
</tr>

<tr>

<th>ID</th>
<th>Name</th>
<th>Address</th>
<th>Gender</th>
<th>Tracks</th>
<th>Action</th>
</tr>

<?php

if($numrow==0){
echo "<tr><td colspan=6 style='color:red'>No Student Data</td></tr>";
}else{

while($row=mysqli_fetch_array($result)){

?>	



<tr>
<td><?=$row['stud_id']?></td>
<td><?=$row['stud_name']?></td>
<td><?=$row['stud_address']?></td>
<td><?=$row['stud_gender']?></td>
<td><?=$row['stud_tracks']?></td>
<td><a href="form-update.php?id=<?=$row['stud_id']?>&name=<?=$row['stud_name']?>&address=<?=$row['stud_address']?>&gender=<?=$row['stud_gender']?>&tracks=<?=$row['stud_tracks']?>"><img src="icon/edit.png"></a> &nbsp <a href="delete.php?id=<?=$row['stud_id']?>" onclick="return confirm('Do you really want to delete?')";><img src="icon/delete.png"></a></td>
</tr>
<?php
}
}
?>
</table>
<a href="index.php"><img src="icon/back.png"></a>




