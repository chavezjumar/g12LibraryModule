<?php

include('header.php');
$id = $_GET['id'];
$item=$_GET['item'];
$brand=$_GET['brand'];
$quantity=$_GET['quantity'];
$price=$_GET['price'];
?>
<style>
input{margin:5px;}
</style>
<div id="content"><br>
<h1>Update Stock</h1>
<form class="insert-form" method="POST" action="update.php">
<input type="text" name="id" value="<?=$id?>" readonly hidden><br>
<input type="text" name="item" value="<?=$item?>"><br>
<input type="text" name="brand" value="<?=$brand?>"><br>
<input type="text" name="quantity" value="<?=$quantity?>"><br>
<input type="text" name="price" value="<?=$price?>"><br>
<a href="index.php">Back</a>
<button type="submit" >Update</button>
</form>
</div>
<?php
include('footer.php');
?>