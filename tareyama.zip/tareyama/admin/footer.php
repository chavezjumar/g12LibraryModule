<footer id="footer">
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
    <p>Template by <a href="#">IC2MA	</a></p>
</center>
</footer>