<div id="content"><?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$result =  $dbserver->query("SELECT * from inventory");
$numrow = $result->num_rows;

?>

<br><center>
<table border=1>

<tr><th colspan=5>INVENTORY</th><th><a href="form-insert.php"><button>ADD</button></a></th> </tr>


<tr>
<th colspan=6>

<form method="POST" action="form-search.php">
<select name="filter">
<option value="id">ID</option>
<option value="item">ITEM</option>
<option value="brand">BRAND</option>

</select>
<input type="search" name="search" placeholder="Search..">
<button type="submit" >SEARCH</button>
</form>

</th>
</tr>

<tr>

<th>ID</th>
<th>ITEM</th>
<th>BRAND</th>
<th>QUANTITY</th>
<th>PRICE</th>
<th>ACTION</th>
</tr>

<?php

while($row=mysqli_fetch_array($result)){

?>	
<tr>
<td><?=$row['id']?></td>
<td><?=$row['item']?></td>
<td><?=$row['brand']?></td>
<td><?=$row['quantity']?></td>
<td><?=$row['price']?></td>
<td><a href="form-update.php?id=<?=$row['id']?>&item=<?=$row['item']?>&brand=<?=$row['brand']?>&quantity=<?=$row['quantity']?>&price=<?=$row['price']?>" style="color:white;">update</a>
 &nbsp <a href="delete.php?id=<?=$row['id']?>" onclick="return confirm('Do you really want to delete?');" style="color:white">delete</a></td>
</tr>
<?php

}
?>

</table>
<br>
<a href="logout.php"><button>LOGOUT?</button></a>	
	
</center>
</table>

	
	
	</center>
	
	
	
</div>