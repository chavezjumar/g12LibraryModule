<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);



$id = $_POST['id'];
$item=$_POST['item'];
$brand=$_POST['brand'];
$quantity=$_POST['quantity'];
$price=$_POST['price'];


$result =  $dbserver->query("SELECT * from inventory where id ='$id'");
$numrow = $result->num_rows;
if($numrow==1){
	
if($item==""||$brand==""||$quantity==""||$price==""){
	echo "<script>alert('Please complete all fields');history.back();</script>";
}else{
$result =  $dbserver->query("UPDATE inventory SET 
		item='$item',
		brand='$brand',
		quantity='$quantity',
		price='$price'
		where id='$id' ");				
echo "<script>alert('Stock Updated Successfully!');window.location.href='index.php'</script>";	
}
}
			
?>

