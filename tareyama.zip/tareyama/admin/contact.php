<html>
<head>
<title>Contact</title>
<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>

<?php 
include('header.php');
include('body.php');
include('footer.php');
?>

</body>

</html>