<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$id = $_GET['id'];

$result =  $dbserver->query("DELETE from inventory where id='$id' ");
			
echo "<script>alert('You deleted student info successfully!');window.location.href='index.php';</script>";					

?>

