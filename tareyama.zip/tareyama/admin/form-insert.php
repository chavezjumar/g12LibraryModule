
<?php 
include('header.php');
?><head>
<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<div id="content"><br>
<h1>Add Stock</h1>
<form class="insert-form" method="POST" action="insert.php" enctype="multipart/form-data">
	<label class="lbl_add">SELECT ITEM:</label>
	<select name="item">
		<option></option>		
		<option value="drinks">DRINKS</option>
		<option value="foods">FOODS</option>
		<option value="desserts">DESSERTS</option>
	</select>	<br>
	<label class="lbl_add">BRAND:</label><br>
		<input class="input_add" type="text" name="brand"><br>
	<label class="lbl_add">QUANTITY:</label><br>
		<input class="input_add" type="number" name="quantity"><br>
	<label class="lbl_add">PRICE:</label><br>
		<input class="input_add" type="number" name="price"><br>	
		<input type="submit" value="ADD"><br>			
		</form>
		
</div>
<?php 
include('footer.php');
?>
