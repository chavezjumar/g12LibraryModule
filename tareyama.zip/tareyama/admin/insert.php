<?php
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";

$connect = new mysqli ($dbhost,$dbusername,$dbpassword,$dbname);
	
$item=$_POST['item'];
$brand=$_POST['brand'];
$quantity=$_POST['quantity'];
$price=$_POST['price'];
	
	$result =  $connect->query("SELECT * from inventory where item ='$item' AND brand ='$brand' AND quantity ='$quantity' AND price ='$price' ");
$numrow = $result->num_rows;
if($numrow==1){
	
	echo "<script>alert(' This Stock is already existing!');history.back();</script>";
}else{
	$result =  $connect->query("INSERT INTO inventory 
					(item,brand,quantity,price) 
					values('$item','$brand','$quantity','$price')   ");
					
echo "<script>alert('You added Stock  Successfully!');window.location.href='index.php'</script>";	
}
?>