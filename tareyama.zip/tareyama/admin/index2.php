<! doctype html>
<html>
	<head>
			<title>Ordering List Module</title>
			<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<center><br><br>	
	<h2>Asian Institute of Computer Studies </h2>
	<h2>Ordering Module</h2>
</center>
<header>
<nav>
	<ul>
		<li><a class="nav_a" href="add.php">ADD INVENTORY</a></li>
		<li><a class="nav_a" href="add.php">EDIT INVENTORY</a></li>
		<li><a class="nav_a" href="add.php">DELETE INVENTORY</a></li>
		</ul>
</nav>
</header>
		<a href="register-form.php"><button>Not yet Registered?</button></a>
</html>