<?php
$dbhost = "localhost";
$dbusername ="root";
$dbpassword ="";
$dbname ="order";

$server = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);


$lname=$_POST['lname'];
$fname=$_POST['fname'];
$gender=$_POST['gender'];
$username=$_POST['username'];
$password=$_POST['password'];
$repassword=$_POST['repassword'];
$account=$_POST['account'];


if($password == $repassword){
	
	$result =  $server->query("SELECT * from user_tbl where lname ='$lname' AND fname ='$fname' AND username ='$username' ");
$numrow = $result->num_rows;
if($numrow==1){
	
	echo "<script>alert('Account is already existing!');history.back();</script>";
}else{
	$result =  $server->query("INSERT INTO user_tbl 
					(lname,fname,gender,username,password,repassword,account) 
					values('$lname','$fname','$gender','$username', '$password', '$repassword', '$account')   ");				
echo "<script>alert('Registation Successful!');window.location.href='index.php'</script>";	
}
}else{
echo "<script>alert('Password Did Not Match');history.back();</script>";
}


?>