<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="jerone";
$dbpassword="asd123";
$dbname="stud_db";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);



$id = $_POST['id'];
$name=$_POST['name'];
$address=$_POST['address'];
$gender=$_POST['gender'];
$tracks=$_POST['tracks'];


$result =  $dbserver->query("SELECT * from user_tbl where stud_name ='$name'");
$numrow = $result->num_rows;
if($numrow==1){
	echo "<script>alert('Student is already existing!');history.back();</script>";
}else{


if($name==""||$address==""||$gender==""||$tracks==""){
	echo "<script>alert('Please complete all fields');history.back();</script>";
}else{
$result =  $dbserver->query("UPDATE user_tbl SET 
		stud_name='$name',
		stud_address='$address',
		stud_gender='$gender',
		stud_tracks='$tracks'
		where stud_id='$id' ");				
echo "<script>alert('You updated student info successfully!');window.location.href='index.php'</script>";	
}	
}
			
?>

