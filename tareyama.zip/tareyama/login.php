<?php
session_start();
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="order";


$connect = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$un = $_POST['username'];
$pw = $_POST['password'];
$ac = $_POST['account'];



$sql = $connect->query("SELECT * from user_tbl where username='$un' AND password = '$pw' AND account = '$ac' ");
$count = $sql->num_rows;

if($count==1){
echo "<script>alert('Login Successful!');</script>";

$_SESSION['user'] = $un;
$_SESSION['pass'] = $pw;

	if($ac=="user"){
	echo "<script>window.location.href='user'</script>";
	}else{
	echo "<script>window.location.href='admin'</script>";
	}


}else{
echo "<script>alert('Login Failed!'); history.back();</script>";
}


?>