<?php
//This is for DB Connection
error_reporting(0);
$dbhost="localhost";
$dbusername="jerone";
$dbpassword="asd123";
$dbname="stud_db";

$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$result =  $dbserver->query("SELECT * from chat order by id desc");


?>

<table border=1>

<tr><th colspan=6>Chat Box</th></tr>


<tr>

<th colspan=6>

<form method="POST" action="chat.php">
<span>User: </span><input type="text" name="username" placeholder="Type your username.." value="<?=$_GET['username']?>"><br>
<textarea placeholder="comment.." name="chat"></textarea>

<button><img src="icon/send.png"></button>
</form>


</th>
</tr>

<tr>
<th colspan="2">Comments</th>
</tr>

</table>

<?php
while($row=mysqli_fetch_array($result)){
?>	

<p><b><?=$row['username']?></b>: &nbsp <i><?=$row['comment']?></i></p>
<hr>

<?php
}
?>





