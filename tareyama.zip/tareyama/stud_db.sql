-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2018 at 12:50 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stud_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `comment` varchar(300) NOT NULL,
  `username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `comment`, `username`) VALUES
(58, 'Hello World', 'Yiel'),
(59, 'GGWP', 'Yiel'),
(60, 'HELLO PLAYTO', 'Yiel'),
(61, 'ertyuiuhyrt', '_notshyy'),
(62, 'edfhjkjhgfdfg', '_notshyy'),
(63, 'BADING', 'Yiel'),
(64, 'dfhjkhrfghgasd', '_notshyy'),
(65, '123', '123'),
(66, 'ka', '_notshyy'),
(67, 'llllll', '-_-'),
(68, 'muka nyo', 'Sloth'),
(69, '12357urtdgsdvb', '_notshyy'),
(70, 'suntukan', 'Sloth'),
(71, 'erftgh', '_notshyy'),
(72, 'meow', 'ellaxxi__'),
(73, 'aahhahhhh', 'SLUT'),
(74, '***************************************', '-_-'),
(75, 'ngwsrfdgt\r\n', '_notshyy'),
(76, 'muka mo wiz', 'Sloth'),
(77, '0987654322345', '_notshyy'),
(78, 'Wiz Khalifa', 'SLUT'),
(79, 'WIZ!!!!!!', 'Sloth'),
(80, '123123', '123'),
(81, 'gurang na c shy', 'ellaxxi__'),
(82, 'Sup?', 'Brazzer'),
(83, 'Wiz khalifa men!\r\n', '123'),
(84, 'Hi', 'Pornstar'),
(85, '<h1>NOOB</h1>', 'suck'),
(86, 'Black and Yellow', 'Sloth'),
(87, 'Sup brazzer?\r\n', '123'),
(88, 'Bakla si daniel', '123'),
(89, '<h1>BADING</h1>', 'suck'),
(90, '<img src=\"logo.png\">', 'Jerone'),
(91, '**** ***!!!!!!!!!!!!', 'ellaxxi__'),
(92, 'Hahaha Bakala si Daniel HAHAHAHA', 'Pornstar'),
(93, 'Bakla ako! :)', 'Daniel'),
(94, 'BAKLA BOBO!', 'Pornstar'),
(95, 'nice hahaha', 'Sloth'),
(96, 'jyreeeeee', 'ellaxxi__'),
(97, 'VINCOOOOO!!!', '1431441134'),
(98, '<h1>IC2MA</h1>', 'Jerone'),
(99, 'hillo', 'kookie'),
(100, 'ULul ako to daniel', 'Daniel'),
(101, '<h1>NOOBSSS</h1>', 'Pornstar'),
(102, '<a href=\"#\">google.com</a>', 'Jerone'),
(103, 'rockstar\r\n', 'Daniel'),
(104, 'adf\r\n', 'GGWP'),
(105, 'youtube.com', 'GGWP'),
(106, 'href=\"youtube.com\"', 'GGWP'),
(107, '-___________-', '-_-'),
(108, 'Hello Guys', 'TiraSabaw'),
(109, 'https://twitter.com/', '1431441134'),
(110, 'Geo Walang Ulo', 'TiraSabaw'),
(111, 'vovo si Bryan rous\r\n', 'GG'),
(112, '@href=\"google.com\"', '-_-'),
(113, '<marquee><h1>BADING</h1></marquee>', 'Bading'),
(114, '<h1>QUIET !!!!!</h1>', 'GGWP'),
(115, 'Daniel Bugaw', 'TiraSabaw'),
(116, '<marquee>Daniel Tokhang</marquee>', 'TiraSabaw'),
(117, 'Mahina si Bryan Rous', 'GGWP'),
(118, '<marquee><h1>DANIEL BADING HHAHAHAHAHA</h1></marquee>', 'GGWP'),
(119, '</marquee><h1>James Iyakin</h1></marquee>', 'TiraSabaw'),
(120, 'RICHWERX mamaya\r\n', 'BAKYUT'),
(121, 'Bakla ako :)', 'Daniel'),
(122, 'Baby James :)', 'Daniel'),
(123, 'ge rwx', 'GGWP'),
(124, 'Magnanakaw ng Sabaw si Bryan Rous', 'Alien'),
(125, '<h1>James IYAKIN</h1>', 'TiraSabaw'),
(126, 'peram extrang damit\r\n', '-_-'),
(127, 'mag mineski ako ', '-_-'),
(128, 'hi po', 'KUYUKUT'),
(129, 'Alien Kain Ulo', 'PlayDie'),
(130, '<img src=\"PKb9gx.jpg\">', 'Jerone'),
(131, '50 ko Daniel new year na', 'PinakaAlien'),
(132, 'Hi Kuyukut', 'PlayDie'),
(133, 'asdasd', 'PlayDie'),
(134, 'wjfhdjkndjkfgdfj', 'meow'),
(135, '<marquee><p style=\"font-color=pink\"> BADING</p></marquee>', 'Bading'),
(136, 'ge rwx', 'GGWP'),
(137, 'James Iyakin ', 'CommanderBawang'),
(138, 'Bryan Supot\r\n', 'PinakaAlien'),
(139, '<marquee>MINESKI MAMAYA</marquee>', 'GGWP'),
(140, 'Playto Walang Tulog', 'CommanderBawang'),
(141, 'Try nyo nga css?\r\n', 'Bading'),
(142, 'Walang PEraaaaa', 'CommanderBawang'),
(143, 'Richwerx vs. Mineski', 'CommanderBawang'),
(144, '<marquee><h1>GGWP</h1></marquee>', 'GGWP'),
(145, 'laaaaaaaaaaaaaah', 'meow'),
(146, '<marquee><h1>Mineski vs. Richwerx</h1><marquee>', 'CommanderBawang'),
(147, 'mp_freeztime 0', 'KUYUKUT'),
(148, '<p style=\"font-color:pink\">Test</p>', 'Bading'),
(149, 'brightness 100', 'CommanderBawang'),
(150, 'mp_startmoney 160000', 'CommanderBawang'),
(151, 'mp_startmoney 16000', 'KUYUKUT'),
(152, 'sv_clientrace 999999999999', 'CommanderBawang'),
(153, 'm_yaw 199999', 'CommanderBawang'),
(154, 'noh to bat nagkaganyan yung comments?', '-_-'),
(155, 'BRYAN SUPOT', 'PinakaAlien'),
(156, '<marquee><h1><marquee><h1></h1></marquee></h1></marquee>', 'GGWP'),
(157, 'texgamma 200', 'KUYUKUT'),
(158, 'cl_forwardspeed 3200', 'CommanderBawang'),
(159, 'lightgamma 1000', 'CommanderBawang'),
(160, 'cl_bobcycle .1', 'KUYUKUT'),
(161, '-.- Iyakin', 'CommanderBawang'),
(162, '<marquee><h1>DANIEL BADING !!!!!!</h1></marquee>', 'GGWP'),
(163, 'MAHINA MAG DOTA SI BRYAN SUPOT', 'PinakaAlien'),
(164, 'counter na', 'KUYUKUT'),
(165, 'cl_makunat 100', 'CommanderBawang'),
(166, 'css ', 'Bading'),
(167, 'asasa', 'lude petmalo'),
(168, 'sv_hindi namamatay 199', 'CommanderBawang'),
(169, 'bengbeng', 'lude petmalo'),
(170, '<h1>MINESKI WEAK</h1>', 'CommanderBawang'),
(171, 'masya kame', 'lude petmalo'),
(172, '<h1>Playto walang Brief</h1>', 'CommanderBawang'),
(173, '<h1>Playto walang Brief</h1>', 'Inaswang'),
(174, '<h1>Playto walang Brief</h1>', 'Inaswang'),
(175, '<p style=\"font-size:500px\">Test</p>', 'Bading'),
(176, 'MART ONE EVERY THINGS IS FOR YOU', 'KUYUKUT'),
(177, 'NOOB', 'PinakaAlien'),
(178, 'plok plok plok plok\r\n', 'lude petmalo'),
(179, 'NOOB', 'PinakaAlien'),
(180, 'NOOB', 'PinakaAlien'),
(181, 'PLOK     PLOK', 'KUYUKUT'),
(182, 'Damn IT', 'BunnyHop'),
(183, 'NOOB', 'PinakaAlien'),
(184, 'NOOB si Bryan Rous', 'PinakaAlien'),
(185, 'NOOB si Bryan Rous', 'PinakaAlien'),
(186, 'Hayaan mo sila to BAyaran Mo sila', 'EX BATALLION'),
(187, '<p style=\"font-size:1000px\">Daniel Bading</p>', 'Bading'),
(188, 'NOOB si Bryan Rous', 'PinakaAlien'),
(189, 'HUBARIN MO YANG HIKAW MO!', 'TIMPOG'),
(190, 'PLease 1 like 1 Prayer for James', 'EX BATALLION'),
(191, 'SI CHIEF TO./', 'TIMPOG'),
(192, 'SUBO MO IHO', 'EX BATALLION'),
(193, 'MGA KABABAYAN DYAN', 'XANDER FORD'),
(194, 'Ako si TIMPOG LAKI SA BaHAY ', 'EX BATALLION TIMPOG'),
(195, '<p style=\"font-color:red>Test</p>', 'Bading'),
(196, 'I LOVE YOU KUYA JAMES', 'FETTY WAD'),
(197, 'Hello Guys The Good SOn is Here in the House', 'THE GOOD SON'),
(198, 'I love you mga fans!!', 'XANDER FORD'),
(199, 'KUYA JAMES', 'FETTY WAD'),
(200, 'asSSS', 'lude petmalo'),
(201, '<marquee><h1>PLAYTO NOOB</h1></marquee>', 'GGWP'),
(202, '<p style=\"font-size:250px\">MUWAhaha</p>', 'Bading'),
(203, '<marquee><h1>THE GOOD SON<h1></marquee>', 'THE GOOD SON'),
(204, '<marquee><h1>GEO UNGGOY !!!!</h1></marquee>', 'GGWP'),
(205, 'PLOK   PLOK', 'LILY CRUZ'),
(206, '<marquee><h1><marquee><h1></h1></marquee><marquee><h1></h1></marquee></h1></marquee>', 'GGWP'),
(207, '<marquee><h1><marquee><h1>gg</h1></marquee></h1></marquee>', 'GGWP'),
(208, 'r+w+e+q+w+d+f+e+D+F', 'SKT T1 FAKER'),
(209, '<h1><h1><h1>adfasdfs</h1></h1></h1>', 'GGWP'),
(210, '<h1>odfdf</h1>', 'meow'),
(211, '<h1>THESIS MUNA</h1>', 'divisoria'),
(212, 'g', 'GEO UNGGOY'),
(213, 'asdfghjkl', 'asdfghjkl'),
(214, 'Haha XD', 'pwetnimalu'),
(215, 'Annyeong!\r\n', 'Lodibells');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `stud_id` int(11) NOT NULL,
  `stud_name` varchar(30) DEFAULT NULL,
  `stud_address` varchar(30) DEFAULT NULL,
  `stud_gender` varchar(6) DEFAULT NULL,
  `stud_tracks` varchar(30) DEFAULT NULL,
  `comment` varchar(300) NOT NULL,
  `stud_photo` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`stud_id`, `stud_name`, `stud_address`, `stud_gender`, `stud_tracks`, `comment`, `stud_photo`) VALUES
(297, 'asdfasdfasdf', 'asasd', 'female', 'ICT', '', 'photos/Capture.PNG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`stud_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
