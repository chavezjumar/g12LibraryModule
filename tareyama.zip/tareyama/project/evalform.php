<html>
<link rel="stylesheet" href="style.css" type="text/css">
<body>
<header id="header" >
<img src="logo.png" >

<h1 id="p1">WELCOME TO AICS EVALUATION SYSTEM !!</h1>
<h2 id="p">- "Evaluate and assess your life"</h2>
</header>
<div id="eval">
<div id="lefte">
		<a href="teacher.php"><button id="back1">Back</button></a>
</div>
<div id="table">
<center>
	<h2>Evaluation form</h2>
		<th><b>Explicit Curriculum:</b><br>How does the teacher teach the core subject?</th>
			<table border="1 solid" id="evalform">
			<tr>
				<td>1</td>
					<td>Teacher is prepared for class. <br> 
					<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
					</td>
			</tr>
			<tr>
				<td>2</td>
					<td>Teacher know his/her subject.<br>
					<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
					</td>
			</tr>																											
			<tr>
				<td>3</td>
					<td>Teacher is organized and neat.<br>
					<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
				</td>
			</tr>
			<tr>
				<td>4</td>
					<td>Teacher plans class time and assignments that helps students to problem to solve and think critically.<br>Teacher provides activities that make subject matter meaningful.<br>
					<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
					</td>
			</tr>
			<tr>
				<td>5</td>
					<td>Teacher is flexible in accomodating for individual student needs.<br>
					<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
					</td>
			</tr>
			<tr>
				<td>6</td>
					<td>Teacher is clear in giving directions and on explaining what is expected on assignments and tests.<br>
					<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
					</td>
			</tr>
				<td>7</td>
					<td>Teacher allows you to be active in the classroom learning environment.<br>
					<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
					</td>
			</tr>
			<tr>
				<td>8</td>
				<td>Teacher manages the time well.<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
			</tr>
			<tr>
				<td>9</td>
				<td>Teacher returns homework in a timely manner.<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
			</tr>
			<tr>
				<td>10</td>
				<td>Teacher has clear classroom procedures so students don't waste time.<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
			</tr>
			<tr>
				<td>11</td>
				<td>Teacher has grades fairly.<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
			</tr>
			<tr>
				<td>12</td>
				<td>I have learned a lot from this teacher about this subject.<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
			</tr>
			<tr>
				<td>13</td>
				
				<td>Teacher gives me  good feedback on homework and projects so that i can improve.
				<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
				</td>
			</tr>
			<tr>
				<td>14</td>
				<td>Teacher is creative in developing activities and lessons.<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
			</tr>
			<tr>
				<td>15</td>
				<td>Teacher encourages students to speak up and be active in the class.<br>
				<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
			</tr>
			</table>
	</center>
</div>
<div id="rightd">		
		<a href="evalform2.php"><button id="next">Next</button></a>
</div>
</div>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
    
</center>
	</footer>
</body>
</html>