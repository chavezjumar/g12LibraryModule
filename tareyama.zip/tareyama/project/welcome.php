<?php
$connect = mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("project_db",$connect) or die (mysql_error());
$username = $_GET['user'];
?>
<html>
<link rel="stylesheet" href="style.css" type="text/css">
<body>
<center>
<header id="header" >
<img src="logo.png" >

<h1 id="p1">WELCOME TO AICS EVALUATION SYSTEM !!</h1>
<h2 id="p">- "Evaluate and assess your life"</h2>
</header>
<div id="welbak"><br>
<h3>Are you sure you want to Evaluate?</h3>
<a href="index.php"><button>No</button></a>
<a href="teacher.php"><button>Yes</button></a>
</div>
</center>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
    
</center>
	</footer>		
</body>
</html>

