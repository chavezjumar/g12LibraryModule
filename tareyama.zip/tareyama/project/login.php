<html>

 <input type="text" id="uname" placeholder="Username">
<input type="password" id="pword" placeholder="password">
<input type="button" onclick="login()" value="login">

</html>