<?php
//To connect to database
$connect = mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("project_db",$connect) or die (mysql_error());

$password= $_POST['password'];
$username= $_POST['username'];
	
// To protect MySQL injection for Security purpose
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

//To check if the provided username & password are existing on the database
$query = mysql_query("select * from signup_tb where username='$username' AND password='$password'"  , $connect);
$rows = mysql_num_rows($query);

if ($rows == 1){
	echo "<script>window.location.href = 'welcome.php?user=$username';</script>"; 	
}else{
	echo "<script>alert('Invalid account, try again!');history.back();</script>";	
}			
					

						
	
?>