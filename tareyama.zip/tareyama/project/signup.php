<?php
$connect = mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("project_db",$connect) or die (mysql_error());




$fname= $_POST['fname'];
$lname= $_POST['lname'];
$grade= $_POST['grade'];
$sectioon= $_POST['section'];
$idnumber= $_POST['idnumber'];
$username= $_POST['username'];
$password= $_POST['password'];
$repassword= $_POST['repassword'];

if ($password == $repassword)
{
	
	if (isset($_FILES['lname']['tmp_name'])) {
	echo "<script>alert('Please complete all fields!');history.back();</script>";
//To insert data to database			
	}else{
	mysql_query("insert signup_tb set 
			fname='".$fname."',
			lname='".$lname."',
			password='".$password."',
			username='".$username."',
			idnumber='".$idnumber."',
			repassword='".$repassword."',
			grade='".$grade."',
			section='".$sectioon."' ");
	
    echo "<script>alert('Registration successful!');window.location.href = 'index.php';</script>";
	}
	} else 
{
    echo "<script>alert('PASSWORD DID MATCH!');history.back();</script>";
}
	
			

?>