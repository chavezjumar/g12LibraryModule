-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2017 at 07:56 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `signup_tb`
--

CREATE TABLE IF NOT EXISTS `signup_tb` (
`id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `grade` varchar(20) NOT NULL,
  `section` varchar(30) NOT NULL,
  `idnumber` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `signup_tb`
--

INSERT INTO `signup_tb` (`id`, `fname`, `lname`, `grade`, `section`, `idnumber`, `username`, `password`, `repassword`) VALUES
(1, 'ae fE', ' chavz', 'asdhg', 'sdg', 1111, 'jumar@yahoo.com', '123', '123'),
(4, 'ae fE', ' chavz', 'asdhg', 'sdg', 1111, 'jumar@yahoo.com', '123', '123'),
(5, 'ae fE', ' chavz', 'asdhg', 'sdg', 1111, 'jumar@yahoo.com', '123', '123'),
(6, 'XBF', '', '', '', 0, '', '', ''),
(7, 'dd', 'dav', 'adv', 'adv', 0, 'av', 'asd', 'asd'),
(8, 'dd', 'dav', 'adv', 'adv', 0, 'av', 'asd', 'asd'),
(9, 'dvbd', 'dvb', 'adb', 'adv', 12345, 'adg', '1245', '1245'),
(10, 'ae fE', ' chavz', 'asdhg', 'acacia', 122, 'jumar@yahoo.com', '1245', '1245'),
(11, 'ascasc', ' chavz', '12', 'sdg', 122, 'asdasf', '147', '147'),
(12, '', 'xvdx', 'xv', 'xv', 1111, 'xvxv', 'asx', 'asx'),
(13, 'xcx', '', 'sxv', 'sxv', 1111, 'svadv', 'asw', 'asw'),
(14, 'asvadv', 'sdg', '', 'adg', 1111, 'adg', '125', '125');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signup_tb`
--
ALTER TABLE `signup_tb`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `signup_tb`
--
ALTER TABLE `signup_tb`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
