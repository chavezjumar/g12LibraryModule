<html>
<link rel="stylesheet" href="style.css" type="text/css">
<body>
<header id="header" >
<img src="logo.png" >

<h1 id="p1">WELCOME TO AICS EVALUATION SYSTEM !!</h1>
<h2 id="p">- "Evaluate and assess your life"</h2>
</header>
<div id="eval1">
<div id="leftee">
		<a href="evalform.php"><button id="back1">Back</button></a>
</div>
<div id="tablee">
	<center>
<h2>Evaluation form</h2>
<th><b>Implicit Curriculum:</b><br>How well does the teacher model the core values through how he/she behave <br>with students and with other staff persons?</th>
<table border="1" id="evalform">
	<tr>
		<td>16</td>
		<td>Teacher follows through on what he/she says. You can count on the teacher's word.
		<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
		</td>
	</tr>
	<tr>
		<td>17</td>
		<td>Teacher listens and understands students'point of view;he/she may not agree, But students feel <br>understood.
<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
		</td>
	</tr><tr>
		<td>18</td>
		<td>Teacher respects the opinions and decisions of students.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>19</td>
		<td>Teacher is willing to accept responsibility for his/her own mistakes<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>20</td>
		<td>Teacheris willing to learn from students<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>21</td>
		<td>Teacher is sensitive to the needs of students.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>22</td>
		<td>Teacher's words and action match.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>23</td>
		<td>Teacher is fun to be with.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>24</td>
		<td>Teacher like and respects students.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor
</td>
	</tr><tr>
		<td>25</td>
		<td>Teacher helps you when you ask for help.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>26</td>
		<td>Teacher is consistent and fair is discipline.<br>
<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>27</td>
		<td>I trust this teacher.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>28</td>
		<td>Teacher tries to model what teacher expects of students.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr><tr>
		<td>29</td>
		<td>Teacher is fair and firm in discipline without being to strict.<br>
	<input type="radio" name="gender"
<?php if (isset($check) && $check=="verygood") echo "checked";?>
value="verygood">verygood
<input type="radio" name="gender"
<?php if (isset($check) && $check=="good") echo "checked";?>
value="male">good
<input type="radio" name="gender"
<?php if (isset($check) && $check=="poor") echo "checked";?>
value="male">poor</td>
	</tr>
</table><br>
What can you say about your teacher?<br>Please leave a comment below.
<br>
<input type="text" id="comment" name="comment" placeholder="comment">
<input type="submit" name="submit" value="submit">	
</center>
</div>
<div id="rightde">		
		<a href="text.php"><button id="next">Next</button></a>	
		</div>
		</div>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
    
</center>
</footer>
</body>
</html>