<html>
<link rel="stylesheet" href="style.css" type="text/css">
<body>
<header id="header" >
<img src="logo.png" >

<h1 id="p1">WELCOME TO AICS EVALUATION SYSTEM !!</h1>
<h2 id="p">- "Evaluate and assess your life"</h2>
</header>
<div>
</div>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
    
</center>
	</footer>
</body>
</html>