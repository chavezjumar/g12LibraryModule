<html>
<link rel="stylesheet" href="style.css" type="text/css">
<body>			
<header id="header" >
<img src="logo.png" >

<h1 id="p1">WELCOME TO AICS EVALUATION SYSTEM !!</h1>
<h2 id="p">- "Evaluate and assess your life"</h2>
</header>

<div id="teach"><br><center>
<h2>Please click the Teachers of your subjects. </h2>
<a href="evalform.php"><button>Jerone B. Alimpia</button></a>
<a href="evalform.php"><button>Reynaldo F. Biag jr.</button></a>
<a href="evalform.php"><button>Annabel A. Palmarin</button></a>
<a href="evalform.php"><button>Jurlex Curray</button></a><br><br>
<a href="evalform.php"><button>Cristory C. Sabejon</button></a>
<a href="evalform.php"><button>Gary R. Illahi</button></a>
<a href="evalform.php"><button>Ramil V. Garrido</button></a>
<a href="evalform.php"><button>Charwayne anne P. Dait</button></a>
</center>
</div	>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
    
</center>
	</footer>	
</body>
<html>