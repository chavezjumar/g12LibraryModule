
<!-- saved from url=(0036)http://localhost/chavz1/project.php? -->
<html>
	<head>	
	<title>AICSteacherevaluation.com</title>
	<link rel="stylesheet" href="style.css" type="text/css">
	</head>
	<body>
<header id="header">
<img src="aicslogo2.jpg" >

<h1> AICS Teachers Evaluation System</h1>
	<form action="login1.php" method="post" >
	<nav id="form">
		Username: <input type="text" name="username" id="uname" style="border-radius: 5px; border: 1px solid black; height:25px; ">
		Password: <input type="password" name="password" id="pword"style="border-radius: 5px; border: 1px solid black; height:25px;">
				<input type="submit" id="login" onclick="login()" class="button" value="login"style="border-radius: 5px; border: 1px solid black; height:25px;">
	</nav>
	</form>	
</header>

<div id="body">
<div id="content">	
	</div>
<div id="left">
	<form id="signup" method="post" action="signup.php">
<center><h2>Sign up</h2></center><br>

<input type="text" id="fn" name="fname" placeholder="Firstname:">
<input type="text" id="ln" name="lname"placeholder="Lastname:"><br><br>

<input type="text" id="grade" name="grade" placeholder="grade:">
<input type="text" id="Section" name="section" placeholder="Section:"><br>
<br>
<input type="number" id="ID number" name="idnumber" placeholder="ID Number:">
<input type="text" id="username" name="username" placeholder="username:">
<br><br>
<input type="password" id="password" name="password" maxlength="50"  autocomplete="off" placeholder="password:">
<input type="password" id="password1" name="repassword" placeholder="Confirm password"><br><br>
<input type="submit" id="signupb" name="submit" value="signup">	<br><br><br><br>		<br>
</form>
</div>
</div>
<footer>
<center>
    <p>Copyright &copy; 2017 - All Rights Reserved - My Website</p>
    
</center>
	</footer>
	
</html>