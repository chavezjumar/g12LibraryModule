-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2018 at 02:15 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `number` int(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `title` varchar(75) NOT NULL,
  `author` varchar(150) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `pages` int(100) NOT NULL,
  `publisher` varchar(200) NOT NULL,
  `isbn` int(50) NOT NULL,
  `copies` int(100) NOT NULL,
  `copyright` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `number`, `category`, `title`, `author`, `edition`, `pages`, `publisher`, `isbn`, `copies`, `copyright`) VALUES
(690, 1, 'Programming', 'MS Excel 2010', 'Jemma Development Group', '', 158, 'Jemma Inc.', 123456789, 1, '2011'),
(691, 2, 'Programming', 'Learning Computers', 'Jemma Development Group', '', 168, 'Jemma Inc.', 213456789, 1, '2009'),
(692, 3, 'Programming', 'Harnessing Computers', 'Jemma Development Group', '', 322, 'Jemma Inc.', 321456789, 1, '2009'),
(693, 4, 'Programming', 'Using Computers', 'Jemma Development Group', '2nd', 301, 'Jemma Inc.', 213434567, 1, '2010'),
(694, 5, 'Programming', 'Office Productivity', 'Jemma Development Group', '2nd', 320, 'Jemma Inc.', 555554444, 1, '2009'),
(695, 6, 'Programming', 'Fundamentals of Information Systems', 'Stair Ralph', '3rd', 414, 'Course Technology', 111112222, 1, '2006'),
(696, 7, 'Programming', 'Introduction to E-Commerce', 'Rayport Jeffrey', '2nd', 516, 'McGraw-hill', 33334433, 1, '2004'),
(697, 8, 'Programming', 'HTML: Comprehensive Concepts and Techniques', 'Shelly Gary B. et. Al', '3rd', 624, 'Cengage Learning', 333344444, 1, '2006'),
(698, 9, 'Programming', 'Secrets of Designing Websites', 'Mangilit, Joel R.', '1st, 2010 reprint', 112, 'Rex Book Store', 453442312, 1, '2001'),
(699, 10, 'Programming', 'Office XP Hands on the Easy Way', 'Harina, Ricardo M.', '2010 reprint', 162, 'Natl. Book Store', 2147483647, 1, '2004'),
(700, 11, 'Programming', 'Application Software', 'Engr. Faaustino D. Reyes II', '1st, 2007 reprint', 163, 'Rex Book Store', 234333234, 1, '2006'),
(701, 12, 'Programming', 'Information Technology: Concepts and Issues', 'Laudon Kenneth', '2nd', 312, 'Course Technology', 33223343, 1, '1997'),
(702, 13, 'Programming', 'Discovering Information Technology', 'Baldauf Kenneth', '', 343, 'Course Technology', 332244, 1, '2009'),
(703, 14, 'Programming', 'Problem Solving with C++ the object programming', 'Savitch Walter', '', 807, 'Addison Wesley', 235566, 1, '1996'),
(704, 15, 'Programming', 'Computer Confluence: Exploring Tomorrows Technology', 'Beekman George', '3rd', 487, 'Pearson Educ. Inc', 777778888, 1, '2000'),
(705, 16, 'Programming', 'Creative Design with photoshop, illustrator, indesign, acrobat', 'Jemma Development Group', '', 291, 'Jemma Inc.', 888887777, 1, '2011'),
(706, 17, 'Programming', 'The World of Information Technology', 'Baldauf/Stair', '', 349, 'Course Technology', 888889999, 1, '2009'),
(707, 18, 'Programming', 'Principles of Web Design', 'Sklar, Joel', '', 288, 'Course Technology', 1234567891, 1, '2000'),
(708, 19, 'Programming', 'Control Systems Technology', 'Fenical Les', '', 492, 'Thomson Delmar', 1213456789, 1, '2007'),
(709, 20, 'Programming', 'Principles of Ethics in Information Technology', 'Reynolds, George W.', '', 404, 'Cengage Learning', 1321456789, 1, '2009'),
(710, 21, 'Programming', 'Introduction to Computer and Information Processing', 'Long,Larry', '4th', 462, 'Prentice Hall', 1213434567, 1, '1994'),
(711, 22, 'Programming', 'Introduction to Turbo Pascal Programming', 'Pepito Copernicus', '2008 reprint', 161, 'Natl. Book Store', 1555554444, 1, '2003'),
(712, 23, 'Programming', 'Assembler Inside and Out', 'Hann, Harley', '', 540, 'McGraw-hill', 1111112222, 1, '1992'),
(713, 24, 'Programming', 'Using HTML', 'Randall, Neil', '', 374, 'Que', 313334433, 1, '1996'),
(714, 25, 'Programming', 'Windows, Word, and Excel: Office Companion', 'Burns Patrick', '2nd', 653, 'The Ventana Press', 2147483647, 1, '1994'),
(715, 26, 'Programming', 'Visual Basic 5: Object-Oriented Programming', 'Swartzfager, Gene', '', 611, 'Coriolis Group books', 1453442312, 1, '1997'),
(716, 27, 'Programming', 'Teach Yourself: Access 95 in 14 days', 'Cassel Paul', '3rd', 682, 'Sams', 2147483647, 1, '1995'),
(717, 28, 'Programming', 'Mastering Visual Fox Pro 3', 'Siegel, Charles', 'special 3rd', 1089, 'Sybex Inc.', 2147483647, 1, '1995'),
(718, 29, 'Programming', 'Digital Communication', 'Proakis John', '4th', 1002, 'McGraw-hill', 133223343, 1, '2001'),
(719, 30, 'Programming', 'Workbook In C Programming', 'Gatpandan, Paulino', '2009 reprint', 135, 'Natl. Book Store', 1332244, 1, '2005'),
(720, 31, 'Programming', 'Introduction to Systems Analysis and Design', 'Whitten Jeffrey', '1st', 609, 'McGraw-hill', 2135566, 1, '2008'),
(721, 32, 'Programming', 'Computer Basics', 'Gorres, Ma. Minerva', '', 201, 'Jemma Inc.', 777178888, 1, '2008'),
(722, 33, 'Programming', 'Discovering Computers Fundamentals', 'Shelly Gary', '3rd', 488, 'Course Technology', 2147483647, 1, '2006');

-- --------------------------------------------------------

--
-- Table structure for table `borrow_tb`
--

CREATE TABLE `borrow_tb` (
  `id` int(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `stud_num` int(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `isbn` int(200) NOT NULL,
  `book_num` int(100) NOT NULL,
  `avail_copies` int(11) NOT NULL,
  `copies` int(11) NOT NULL,
  `date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `id` int(11) NOT NULL,
  `last` varchar(50) NOT NULL,
  `first` varchar(50) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `stud_num` int(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`id`, `last`, `first`, `grade`, `section`, `stud_num`, `username`, `email`, `password`, `repassword`) VALUES
(22, 'chavez', 'Jumar', '12', 'IC2DA', 161082, 'jumar_chavez', 'jumarchavez@yahoo.com', 'admin', 'admin'),
(23, 'cha', 'cha', '11', 'cha', 1212, 'cha', 'cha@yahoo.com', 'cha', 'cha'),
(26, 'dela Cruz', 'Joyce', '11', 'GA1MA', 121212, 'joyt', 'joyt@yahoo.com', 'yahyahyah', 'yahyahyah'),
(30, 'Alimpia', 'Jerone', '12', 'IC2Ma', 101010, 'jerone123', 'jerone@yahoo.com', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrow_tb`
--
ALTER TABLE `borrow_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=723;

--
-- AUTO_INCREMENT for table `borrow_tb`
--
ALTER TABLE `borrow_tb`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
