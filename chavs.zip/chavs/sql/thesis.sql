-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2004 at 05:12 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `number` int(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `title` varchar(75) NOT NULL,
  `author` varchar(150) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `pages` int(100) NOT NULL,
  `publisher` varchar(200) NOT NULL,
  `isbn` int(50) NOT NULL,
  `copies` int(100) NOT NULL,
  `copyright` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `number`, `category`, `title`, `author`, `edition`, `pages`, `publisher`, `isbn`, `copies`, `copyright`) VALUES
(142, 1, 'Programming', 'MS Excel 2010', 'Jemma Development Group', '', 158, 'Jemma Inc.', 2147483647, 0, '2011'),
(143, 2, 'Programming', 'Learning Computers', 'Jemma Development Group', '', 168, 'Jemma Inc.', 0, 1, '2009'),
(144, 3, 'Programming', 'Harnessing Computers', 'Jemma Development Group', '', 322, 'Jemma Inc.', 0, 1, '2009'),
(145, 4, 'Programming', 'Using Computers', 'Jemma Development Group', '2nd', 301, 'Jemma Inc.', 0, 1, '2010'),
(146, 5, 'Programming', 'Office Productivity', 'Jemma Development Group', '2nd', 320, 'Jemma Inc.', 0, 1, '2009'),
(147, 6, 'Programming', 'Fundamentals of Information Systems', 'Stair Ralph', '3rd', 414, 'Course Technology', 0, 1, '2006'),
(148, 7, 'Programming', 'Introduction to E-Commerce', 'Rayport Jeffrey', '2nd', 516, 'McGraw-hill', 0, 1, '2004'),
(149, 8, 'Programming', 'HTML: Comprehensive Concepts and Techniques', 'Shelly Gary B. et. Al', '3rd', 624, 'Cengage Learning', 0, 1, '2006'),
(150, 9, 'Programming', 'Secrets of Designing Websites', 'Mangilit, Joel R.', '1st, 2010 reprint', 112, 'Rex Book Store', 0, 1, '2001'),
(151, 10, 'Programming', 'Office XP Hands on the Easy Way', 'Harina, Ricardo M.', '2010 reprint', 162, 'Natl. Book Store', 0, 1, '2004'),
(152, 11, 'Programming', 'Application Software', 'Engr. Faaustino D. Reyes II', '1st, 2007 reprint', 163, 'Rex Book Store', 0, 1, '2006'),
(153, 12, 'Programming', 'Information Technology: Concepts and Issues', 'Laudon Kenneth', '2nd', 312, 'Course Technology', 0, 1, '1997'),
(154, 13, 'Programming', 'Discovering Information Technology', 'Baldauf Kenneth', '', 343, 'Course Technology', 0, 1, '2009'),
(155, 14, 'Programming', 'Problem Solving with C++ the object programming', 'Savitch Walter', '', 807, 'Addison Wesley', 0, 1, '1996'),
(156, 15, 'Programming', 'Computer Confluence: Exploring Tomorrows Technology', 'Beekman George', '3rd', 487, 'Pearson Educ. Inc', 0, 1, '2000'),
(157, 16, 'Programming', 'Creative Design with photoshop, illustrator, indesign, acrobat', 'Jemma Development Group', '', 291, 'Jemma Inc.', 0, 1, '2011'),
(158, 17, 'Programming', 'The World of Information Technology', 'Baldauf/Stair', '', 349, 'Course Technology', 0, 1, '2009'),
(159, 18, 'Programming', 'Principles of Web Design', 'Sklar, Joel', '', 288, 'Course Technology', 0, 1, '2000'),
(160, 19, 'Programming', 'Control Systems Technology', 'Fenical Les', '', 492, 'Thomson Delmar', 0, 1, '2007'),
(161, 20, 'Programming', 'Principles of Ethics in Information Technology', 'Reynolds, George W.', '', 404, 'Cengage Learning', 0, 1, '2009'),
(162, 21, 'Programming', 'Introduction to Computer and Information Processing', 'Long,Larry', '4th', 462, 'Prentice Hall', 0, 1, '1994'),
(163, 22, 'Programming', 'Introduction to Turbo Pascal Programming', 'Pepito Copernicus', '2008 reprint', 161, 'Natl. Book Store', 0, 1, '2003'),
(164, 23, 'Programming', 'Assembler Inside and Out', 'Hann, Harley', '', 540, 'McGraw-hill', 0, 1, '1992'),
(165, 24, 'Programming', 'Using HTML', 'Randall, Neil', '', 374, 'Que', 0, 1, '1996'),
(166, 25, 'Programming', 'Windows, Word, and Excel: Office Companion', 'Burns Patrick', '2nd', 653, 'The Ventana Press', 0, 1, '1994'),
(167, 26, 'Programming', 'Visual Basic 5: Object-Oriented Programming', 'Swartzfager, Gene', '', 611, 'Coriolis Group books', 0, 1, '1997'),
(168, 27, 'Programming', 'Teach Yourself: Access 95 in 14 days', 'Cassel Paul', '3rd', 682, 'Sams', 0, 1, '1995'),
(169, 28, 'Programming', 'Mastering Visual Fox Pro 3', 'Siegel, Charles', 'special 3rd', 1089, 'Sybex Inc.', 0, 1, '1995'),
(170, 29, 'Programming', 'Digital Communication', 'Proakis John', '4th', 1002, 'McGraw-hill', 0, 1, '2001'),
(171, 30, 'Programming', 'Workbook In C Programming', 'Gatpandan, Paulino', '2009 reprint', 135, 'Natl. Book Store', 0, 1, '2005'),
(172, 31, 'Programming', 'Introduction to Systems Analysis and Design', 'Whitten Jeffrey', '1st', 609, 'McGraw-hill', 0, 1, '2008'),
(173, 32, 'Programming', 'Computer Basics', 'Gorres, Ma. Minerva', '', 201, 'Jemma Inc.', 0, 1, '2008'),
(174, 33, 'Programming', 'Discovering Computers Fundamentals', 'Shelly Gary', '3rd', 488, 'Course Technology', 0, 1, '2006'),
(175, 34, 'Programming', 'Javascript Complete Concepts and Techniques', 'Shelly Gary et. Al', '2nd', 0, 'Course Technology', 0, 1, '2001'),
(176, 35, 'Programming', 'Microsoft Office 2003 : Essential Concepts and Techniques', 'Shelly, Gary B.', '2nd', 0, 'Course Technology', 0, 1, '2006'),
(177, 36, 'Programming', 'Algorithms in C', 'Sedgewick, Robert', '3rd', 702, 'Addison Wesley', 0, 1, '1998'),
(178, 37, 'Programming', 'Visual Basic: An Introduction to Object Oriented Program', 'Trajano, Emily', '', 354, 'Jemma Inc.', 0, 1, '2008'),
(179, 38, 'Programming', 'Turbo Pascal 7.0', 'Savitch Walter', '4th', 686, 'The Benjamin', 0, 1, '1993'),
(180, 39, 'Programming', 'Systems Analysis and Design Methods', 'Shelly Gary B.', '7th', 631, 'Course Technology', 0, 1, '2009'),
(181, 40, 'Programming', 'Programming Logic and Design Comprehensive', 'Farrell, Joyce', '3rd', 603, 'Course Technology', 0, 1, '2006'),
(182, 41, 'Programming', 'Operating System: A Systematic View', 'Davis William S.', '5th', 605, 'Pearson Educ. Inc', 0, 1, '2001'),
(183, 42, 'Programming', 'Turbo C Programming Language for Beginners Book 1', 'Abante, Marmelo V.', '', 166, 'Anvil', 0, 1, '2008'),
(184, 43, 'Programming', 'Introduction to C++ Game Programming', 'Dawson Michael', '', 296, 'Cengage Learning', 0, 1, '2010'),
(185, 44, 'Programming', 'Discovering Computers Complete', 'Shelly Gary', '2nd', 1101, 'Cengage Learning', 0, 1, '2010'),
(186, 45, 'Programming', 'Simple AutoCAD 1 for Beginners', 'Barba, Joshua A.', '', 304, 'Natl. Book Store', 0, 1, '2010'),
(187, 46, 'Programming', 'Introduction to Java 6 Programming (Series 1- Applet)', 'Pepito Copernicus', '', 472, 'Natl. Book Store', 0, 1, '2009'),
(188, 47, 'Programming', 'Fireworks and Flash 8: Multimedia and Web Design', 'Abante, Marmelo V.', '', 112, 'Anvil', 0, 1, '2009'),
(189, 48, 'Programming', 'Dreamweaver 8: System and Web Development', 'Abante, Marmelo V.', '', 126, 'Anvil', 0, 1, '2009'),
(190, 49, 'Programming', 'Programming Logic Formulation', 'Farrell, Joyce', '6th', 450, 'Natl. Book Store', 0, 1, '2009'),
(191, 50, 'Programming', 'Visual C++ Programming Language: Programming Made Easy', 'Abante, Marmelo V.', '', 175, 'Anvil', 0, 1, '2009'),
(192, 51, 'Programming', 'Research Methods: Principles and Applications', 'Adanza, E.g', '', 0, 'Rex Book Store', 0, 1, '1995'),
(193, 52, 'Programming', 'Microsoft Internet Explorer 4', 'Haskin, David', '', 374, 'Ventana Communica', 0, 1, '1998'),
(194, 53, 'Programming', 'Database Systems', 'Connolly Thomas', '', 839, 'Addison Wesley', 0, 1, '1996'),
(195, 54, 'Programming', 'Modern Database System', 'Kim, Won editor', '', 705, 'Addison Wesley', 0, 1, '1995'),
(196, 55, 'Programming', 'C How to Program', 'P & H Deitel', '5th', 1089, 'Pearson Educ. Inc', 0, 1, '2007'),
(197, 56, 'Programming', 'AutoCAD Quick Reference', 'Sharp Craig', '3rd', 167, 'Que Corporation', 0, 1, '1992'),
(198, 57, 'Programming', 'Multimedia for the Web Revealed', 'Coorough, Calleen', '', 554, 'Thomson Course Tech.', 0, 1, '2006'),
(199, 58, 'Programming', 'Management Information System for the Information Age', 'Haag, Stephen', '7th', 541, 'McGraw-hill', 0, 1, '2008'),
(200, 59, 'Programming', 'JAVA Programming Complete Concepts and Techniques', 'Shelly Gary', '', 7, 'Course Technology', 0, 1, '2001'),
(201, 60, 'Programming', 'Management Information System', 'Oz, Effy', '5th', 527, 'Course Technology', 0, 1, '2007'),
(202, 61, 'Programming', 'CGI/Perl', 'Zak Diane', '', 365, 'Course Technology', 0, 1, '2002'),
(203, 62, 'Programming', 'Web Design: Introductory Concepts and Techniques', 'Shelly Gary', '', 7, 'Course Technology', 0, 1, '2001'),
(204, 63, 'Programming', 'Internet Programming w/ VBScript & Javascript', 'Kalata Kathleen', '', 578, 'Course Technology', 0, 1, '2001'),
(205, 64, 'Programming', 'Internet 101: The New Mass Medium for Filipinos', 'Khan Rachel', '2008 reprint', 204, 'Anvil', 0, 1, '2006'),
(206, 65, 'Programming', 'Multimedia Concepts', 'Shuman, James E.', '', 230, 'Course Technology', 0, 1, '2001'),
(207, 66, 'Programming', 'Computing Concepts with Java Essentials', 'Hortsman, Cay S.', '', 624, 'John Wiley & Sons', 0, 1, '1998'),
(208, 67, 'Programming', 'Database Management Systems', 'Pratt Philip', '', 343, 'Cengage Learning', 0, 1, '2010'),
(209, 68, 'Programming', 'Data Structure and Algorithms in C++', 'Drozdeck, Adam', '3rd', 758, 'Course Technology', 0, 1, '2007'),
(210, 69, 'Programming', 'Data Structure and Algorithms in Java', 'Drozdeck, Adam', '2nd', 752, 'Course Technology', 0, 1, '2007'),
(211, 70, 'Programming', 'Database Demystified', 'Oppel Andy', '2nd', 430, 'McGraw-hill', 0, 1, '2011'),
(212, 71, 'Programming', 'Sam\'s Teach Yourself C++', 'Liberty, Jesse', '6th', 857, 'Sams', 0, 1, '2009'),
(213, 72, 'Programming', 'Fundamentals of Database Systems', 'Elmasriv Ramez', '5th', 1123, 'Pearson Educ. Inc', 0, 1, '2007'),
(214, 73, 'Programming', 'Reasoning for the Reasonable', 'Fronda, Earl S.', '1st, 2006 reprint', 255, 'Rex Book Store', 0, 1, '2005'),
(215, 74, 'Programming', 'An Introduction to Database System', 'Date, C.J', '7th', 938, 'Addison Wesley', 0, 1, '2000'),
(216, 75, 'Programming', 'An Introduction to Object-Oriented Programming w/ JAVA', 'Wu C. Thomas', '2nd', 938, 'McGraw-hill', 0, 1, '2001'),
(217, 76, 'Programming', 'Microsoft Visual Basic 6: Complete concepts and techniques', 'Shelly Gary B. et. Al', '', 8, 'Cengage Learning', 0, 1, '2009'),
(218, 77, 'Programming', 'Weaving a Website', 'Anderson-Freed, Susan', '', 712, 'Prentice Hall', 0, 1, '2002'),
(219, 78, 'Programming', 'Programming Languages', 'Pratt, Terrence W.', '4th, 2002 reprint', 649, 'Prentice Hall', 0, 1, '2001'),
(220, 79, 'Programming', 'Turbo C Sample Programs and Solutions Book 2', 'Abante, Marmelo V.', '', 211, 'Anvil', 0, 1, '2008'),
(221, 80, 'Programming', 'Teaching and Learning Logic', 'Joven, Jose R.', '1st 2007 reprint', 228, 'Rex Book Store', 0, 1, '2006'),
(222, 81, 'Programming', 'Database Systems', 'Peter Carlos', '2009 reprint', 593, 'Cengage Learning', 0, 1, '2009'),
(224, 82, 'Operating Books', 'Introduction to information Systems', 'Rainer Jr., Kelly', '3rd', 538, 'John Wiley & Sons Inc.', 0, 1, '2011'),
(225, 83, 'Operating Books', 'Introduction to Management', 'Schermerhom Jr., John', '10th', 519, 'John Wiley & Sons Inc.', 0, 1, '2010'),
(226, 84, 'Operating Books', 'Information Technology Project Management', 'Schwalbe Kathy', '2nd', 561, 'Course Technology', 0, 1, '2008'),
(227, 85, 'Operating Books', 'Operating Systems', 'Deitel H.M.', '3rd', 1209, 'Pearson Educ. Inc', 0, 1, '2004'),
(228, 86, 'Operating Books', 'Control Systems Principles and Design', 'Gopal M.', '2nd', 971, 'McGraw-hill', 0, 1, '2002'),
(229, 87, 'Operating Books', 'Data Management', 'Watson Richard', '', 568, 'John Wiley & Sons', 0, 1, '1996'),
(230, 88, 'Operating Books', 'Operating System: Internet and Design Principles', 'Stalling, William', '4th', 779, 'Prentice Hall', 0, 1, '2001'),
(231, 89, 'Operating Books', 'Operating System Principles', 'Silberschatz Abraham', '7th', 896, 'John Wiley & Sons Inc.', 0, 1, '2006'),
(232, 90, 'Operating Books', 'A Gift of Fire', 'Baase, Sara', '2nd', 464, 'Pearson Educ. Inc', 0, 1, '2004'),
(233, 91, 'Operating Books', 'Introduction to FoxPro Database Programming', 'Pepito Copernicus', '2010 reprint', 194, 'Natl. Book Store', 0, 1, '2005'),
(234, 92, 'Operating Books', 'Introduction to Visual FoxPro 6.0', 'Pepito Copernicus', '2010 reprint', 285, 'Natl. Book Store', 0, 1, '2005'),
(235, 93, 'Operating Books', 'Introduction to Turbo C Programming', 'Pepito Copernicus', '2010 reprint', 164, 'Natl. Book Store', 0, 1, '2003'),
(236, 94, 'Operating Books', 'Curriculum Development System', 'Palama, Jesus', '2nd', 205, 'Natl. Book Store', 0, 1, '2009'),
(237, 95, 'Operating Books', 'Word for Windows 95: Instant Reference', 'Dienes Sheila', '2nd', 333, 'Sybex Inc.', 0, 1, '1995'),
(238, 96, 'Operating Books', 'Computer Viruses and Data Protection', 'Burger Ralf', '', 353, 'Abacus', 0, 1, '1991'),
(239, 97, 'Operating Books', 'Introduction to UNIX', 'Schulman Mark', '', 458, 'Que Corporation', 0, 1, '1992'),
(240, 98, 'Operating Books', 'Industrial Organization and Management', 'Riggs James et. Al', '6th', 610, 'McGraw-hill', 0, 1, '1980'),
(241, 99, 'Operating Books', 'The Elements of Style', 'Strunk Jr., William', '50th Anniversary', 105, 'Pearson Educ. Inc', 0, 1, '2009'),
(242, 100, 'Operating Books', 'Teaching Computer for Secondary and Tertiary Level', 'Casiano, Michael', '2nd', 190, 'Rex Book Store', 0, 1, '2007'),
(243, 101, 'Operating Books', 'Elements of Power System Analysis', 'William D. Stevenson jR.', '4th Edition', 436, 'McGraw-hill', 0, 1, '1984'),
(306, 102, 'Computer Dictionaries', 'Computer Dictionary', 'Microsoft Press', '', 392, 'Microsoft Press', 0, 1, '1991'),
(307, 103, 'Computer Dictionaries', 'The PC User\'s Essential Accessible Pocket Dictionary', 'Dyson Peter', '', 577, 'Sybex Inc.', 0, 1, '1994'),
(308, 104, 'Computer Dictionaries', 'Computer and Internet Dictionary', 'Pfaffenberger, Bryan', '6th', 574, 'Que Corporation', 0, 1, '1995'),
(309, 105, 'Computer Dictionaries', 'Diksyunaryo', 'Maria Odullo De Guzman', '2008 reprint', 353, 'Natl. Book Store', 0, 1, '1970'),
(310, 106, 'Computer Dictionaries', 'Talatinigang Pilipino-Pilipino', 'Del Valle Bartolome', '2008 reprint', 212, 'Rex Book Store', 0, 1, '1969'),
(311, 107, 'Computer Dictionaries', 'Computer Dictionary', 'Tribobert', '', 222, 'Palinsad General me', 0, 1, '2009'),
(312, 108, 'Computer Dictionaries', 'Computer Dictionary', 'Torrenueva', '', 0, 'Natl. Book Store', 0, 1, ''),
(313, 109, 'Computer Dictionaries', 'Electrician\'s Vest Pocket Reference Book', 'Henry Hansteen', 'Newly revised', 190, 'Prentice Hall', 0, 1, '1986'),
(314, 110, 'Computer Dictionaries', 'File Structures', 'Folk Michael', '', 724, 'Addison Wesley', 0, 1, '1999'),
(316, 111, 'Computer Books', 'Routing Protocols and Concepts: CCNA Exploration lab and Study Guide', 'Johnson, Allan', '', 538, 'Cisco Press', 0, 1, '2008'),
(317, 112, 'Computer Books', 'Accessing the WAN: CCNA Exploration Labs & Study Guide', 'Rullan, John', '', 343, 'Cisco Press', 0, 1, '2008'),
(318, 113, 'Computer Books', 'Network Fundamentals CCNA Exploration Labs anf Study Guide', 'Rufi Antton et. Al', '', 370, 'Cisco Press', 0, 1, '2008'),
(319, 114, 'Computer Books', 'LAN Switching & Wireless: CCNA Exploration Labs & Study Guide', 'Johnson, Allan', '', 336, 'Cisco Press', 0, 1, '2008'),
(320, 115, 'Computer Books', 'Cisco Networking Academy Program: CCNA 1 and 2 Lab', 'Cisco System', '3rd revised', 428, 'Cisco Press', 0, 1, '2005'),
(321, 116, 'Computer Books', 'Physics for Scientist and Engineers with Modern Physics', 'Serway, Raymond A.', '6th', 1552, 'Brooks/Cole', 0, 1, '2004'),
(322, 117, 'Computer Books', 'Data Communications and Computer Networks', 'White Curt', '', 496, 'Course Technology', 0, 1, '2001'),
(323, 118, 'Computer Books', 'Basic Statistics with Calculator and Computer Application', 'Narag, Edilyn Castillo', '1st', 191, 'Rex Book Store', 0, 1, '2010'),
(324, 119, 'Computer Books', 'Elementary Statistics with Computer Applications', 'Altares, Priscilla et, al', '2010 reprint', 305, 'Rex Book Store', 0, 1, '2005'),
(325, 120, 'Computer Books', 'The PC Doctor\'s Fix it Yourself Guide', 'Kingsley- Hughes, Adrian', '', 499, 'The Mc-Graw Hill', 0, 1, '2004'),
(326, 121, 'Computer Books', 'Software Engineering', 'Pressman, Roger', '6th', 912, 'McGraw-hill', 0, 1, '2005'),
(327, 122, 'Computer Books', 'Introduction to Visual C++ 2008 Programming Series 1 Windows Application', 'Copernicus, Pepito', '', 377, 'Natl. Book Store', 0, 1, '2009'),
(328, 123, 'Computer Books', 'Applied Operating Systems Concept', 'Silberschatz Avi', '1st', 840, 'John Wiley & Sons Inc.', 0, 1, '2000'),
(329, 124, 'Computer Books', 'LAN Switching & Wireless: CCNA Exploration Companion Guide', 'Lewis, Wayne', '', 497, 'Cisco Press', 0, 1, '2008'),
(330, 125, 'Computer Books', 'Data Communication and Networking', 'Forouzan Behrouz', '4th', 1134, 'McGraw-hill', 0, 1, '2007'),
(331, 126, 'Computer Books', 'Computer Communications and Networking Technologies', 'Gallo, Michael', '', 632, 'Booklore', 0, 1, '2002'),
(332, 127, 'Computer Books', 'Data and Network Communications', 'Miller, Michael', '', 522, 'Delmar', 0, 1, '2000'),
(333, 128, 'Computer Books', 'Business Data Communication and Networking', 'Fitzgerald, Jerry', '7th', 457, 'John Wiley & Sons Inc.', 0, 1, '2002'),
(334, 129, 'Computer Books', 'Data Communications and Networking', 'Tomazi Wayne', '', 967, 'Pearson Educ. Inc', 0, 1, '2006'),
(335, 130, 'Computer Books', 'Routing Protocols and Concepts: CCNA Exploration Companion Guide', 'Graziani, Rick', '', 606, 'Cisco Press', 0, 1, '2008'),
(336, 131, 'Computer Books', 'Introduction to Information Technology and OpenOffice Org.', 'Feria Charmagne', '', 402, 'New Day', 0, 1, '2009'),
(337, 132, 'Computer Books', 'Introduction to Computer Fundamentals', 'Pepito Copernicus', '2010 reprint', 112, 'Natl. Book Store', 0, 1, '2002'),
(338, 133, 'Computer Books', 'Computer Fundamentals', 'Fajarito, Dennis', '', 196, 'Natl. Book Store', 0, 1, '2009'),
(339, 134, 'Computer Books', 'Network Fundamentals CCNA Exploration Companion Guide', 'Dye Mark', '', 528, 'Cisco Press', 0, 1, '2008'),
(340, 135, 'Computer Books', 'Statistics with Computer', 'Paler-Calmorin, Laurentina', '1st', 394, 'Rex Book Store', 0, 1, '2009'),
(341, 136, 'Computer Books', 'Teach Yourself ? C', 'Siegel Charles', '1990 reprint', 357, 'Management Information', 0, 1, '1989'),
(342, 137, 'Computer Books', 'Basic Office Application', 'Abante, Marmelo V.', '', 285, 'Anvil', 0, 1, '2010'),
(343, 138, 'Computer Books', 'Managing to Excel: A guide for Managers and Entrepreneur', 'Gaudencio, Aquino', '', 237, 'Natl. Book Store', 0, 1, '2005'),
(345, 139, 'Electronic Books', 'The Intel Microprocessor Family', 'Antonakos, James L.', '', 618, 'Thomson Delmar', 0, 1, '2007'),
(346, 140, 'Electronic Books', 'Form & Style: Theses, Reports, Term Papers', 'Campbell William', '8th', 279, 'Houghton Mifflin', 0, 1, '1991'),
(347, 141, 'Electronic Books', 'Schaum\'s Outline Basic Electricity', 'Gussow, Milton', '2nd', 561, 'McGraw-hill', 0, 1, '2007'),
(348, 142, 'Electronic Books', 'A First Course in Semiconductor Devices and Circuits', 'Araneta, Jose C.', '', 351, 'Natl. Book Store', 0, 1, '2007'),
(349, 143, 'Electronic Books', 'The Intel Microprocessors', 'Brey, Barry', '8th', 925, 'Prentice Hall', 0, 1, '2011'),
(350, 144, 'Electronic Books', 'Build Your own PC', 'Rosenthal Morris', '4th', 223, 'McGraw-hill', 0, 1, '2004'),
(351, 145, 'Electronic Books', 'Microprocessors and Microcomputers', 'Tocci, Ronald J.', '5th, 2001 reprint', 591, 'Prentice Hall', 0, 1, '2000'),
(352, 146, 'Electronic Books', 'Microcomputers and Microprocessors', 'John Uffenbeck', 'Reprinted 2001', 729, 'Jemma Inc.', 0, 1, '2001'),
(353, 147, 'Electronic Books', 'New Perspective on Computer Concepts', 'Parson, June Jamrich', '9th', 452, 'Course Technology', 0, 1, '2007'),
(354, 148, 'Electronic Books', 'New Perspective on The Internet Comprehensive', 'Perry James T.', '2nd', 11, 'Course Technology', 0, 1, '2000'),
(355, 149, 'Electronic Books', 'Fundamentals of Electronics: DC/AC Circuits', 'Terrell David', '', 1072, 'Delmar', 0, 1, '2000'),
(356, 150, 'Electronic Books', 'Digital Design with CPLD Applications and VHDL', 'Dueck Robert', '', 846, 'Delmar', 0, 1, '2001'),
(357, 151, 'Electronic Books', 'Principles of Electronic Devices', 'Stanley, William D.', '', 1044, 'Prentice Hall', 0, 1, '1995'),
(358, 152, 'Electronic Books', 'Understanding Solid State Electronics', 'Cannon, Don L.', '5th, revised', 307, 'Sams', 0, 1, '1991'),
(359, 153, 'Electronic Books', 'Digital Design Principles and Practices', 'Wakerly John', '3rd updated', 946, 'Pearson Educ. Inc', 0, 1, '2001'),
(360, 154, 'Electronic Books', 'Electronic Communications Systems: Fundamentals Though', 'Tomasi Wayne', '5th', 1163, 'Pearson Educ. Inc', 0, 1, '2004'),
(361, 155, 'Electronic Books', 'Electronic Troubleshooting', 'Matsuda, Don', '', 472, 'Prentice Hall', 0, 1, '1992'),
(362, 156, 'Electronic Books', 'Upgrading and Repairing PC', 'Scott Mueller', '19th', 1153, 'Natl. Book Store', 0, 1, '2010'),
(363, 157, 'Electronic Books', 'Introduction to Computer Concepts', 'La Putt, Juny Pilapil', '2010 reprint', 306, 'Natl. Book Store', 0, 1, '1984'),
(364, 158, 'Electronic Books', 'Electronic Devices and Circuit Theory', 'Boylested, Robert', '10th', 894, 'Pearson Educ. Inc', 0, 1, '2009'),
(365, 159, 'Electronic Books', 'Grob\'s Basic Electronics', 'Schultz, Mitchel', '10th', 1119, 'McGraw-hill', 0, 1, '2007'),
(366, 160, 'Electronic Books', 'Electronic Component Testing Simplified', 'Benjamin Velasco', '2009 reprint', 243, 'Natl. Book Store', 0, 1, '1994'),
(367, 161, 'Electronic Books', 'Worktext in Electromagnetism', 'Bulos Evangeline', '', 134, 'Natl. Book Store', 0, 1, '2004'),
(368, 162, 'Electronic Books', 'Statistics and Probability: A simplified Approach', 'Caras, Madeleine S. et. Al', '', 274, 'Natl. Book Store', 0, 1, '2009'),
(369, 163, 'Electronic Books', 'Systems Architecture', 'Burd, Stephen', '3rd', 616, 'Course Technology', 0, 1, '2001'),
(370, 164, 'Electronic Books', 'Contemporary Logic Design', 'Katz Randy H.', '', 699, 'The Benjamin', 0, 1, '1994'),
(371, 165, 'Electronic Books', 'Operational Amplifiers and Linear Integrated Circuits', 'Coughlin Robert, E.', '6th', 529, 'Prentice Hall', 0, 1, '2001'),
(372, 166, 'Electronic Books', 'Digital and Analog Communication Systems', 'Couch Ll Leon', '6th', 758, 'Prentice Hall', 0, 1, '2001'),
(373, 167, 'Electronic Books', 'Teach Yourself: Electricity and Electronics', 'Gibilisco, Stan', '4th', 699, 'McGraw-hill', 0, 1, '2006'),
(374, 168, 'Electronic Books', 'Computer Systems Design & Architecture', 'Heuring, Vincent', '', 571, 'Addison Wesley', 0, 1, '1997'),
(375, 169, 'Electronic Books', 'Fundamentals of Linear Electronics: Integrated & Discrete', 'Cox, James', '2nd', 884, 'Delmar', 0, 1, '2002'),
(376, 170, 'Electronic Books', 'Electronic Commerce', 'Schneider Gary', '7th annual', 624, 'Course Technology', 0, 1, '2007'),
(377, 171, 'Electronic Books', 'Electronic Circuit Analysis and Design', 'Neaman Donald', '2nd', 1232, 'McGraw-hill', 0, 1, '2001'),
(378, 172, 'Electronic Books', 'Introduction to PC Hardware and Troubleshooting', 'Meyers Michael', '', 447, 'McGraw-hill', 0, 1, '2003'),
(379, 173, 'Electronic Books', 'Electricity 1: Devices, Circuits and Materials', 'Thomas Kubala', '8th', 182, 'Cengage Learning', 0, 1, '2008'),
(380, 174, 'Electronic Books', 'Electricity 2: Devices, Circuits and Materials', 'Thomas Kubala', '8th', 153, 'Cengage Learning', 0, 1, '2008'),
(381, 175, 'Electronic Books', 'Electricity 3: Power Generation and Delivery', 'Jeff Keljik', '8th', 254, 'Cengage Learning', 0, 1, '2008'),
(382, 176, 'Electronic Books', 'Electricity 4: AC/DC Motors, Controls and Maintenance', 'Jeff Keljik', '8th', 362, 'Cengage Learning', 0, 1, '2008'),
(383, 177, 'Electronic Books', 'Gregg College Keyboarding & Document Processing Lesson', 'Ober Scot', '10th', 191, 'McGraw-hill', 0, 1, '2008'),
(384, 178, 'Electronic Books', 'Engineering Electromagnetic', 'Hayt William', '7th', 582, 'McGraw-hill', 0, 1, '2006'),
(385, 179, 'Electronic Books', 'Simplified Electrical Circuit: DC Circuit', 'Cui-Waga, Madeleine', '1st', 0, 'Rex Book Store', 0, 1, '2010'),
(386, 180, 'Electronic Books', 'Modern Electronic Communication', 'Miller, Gary', '4th', 626, 'Regents/Prentice Hall', 0, 1, '1993'),
(387, 181, 'Electronic Books', 'Printer Troubleshooting Pocket Reference', 'Bigelow, Stephen', '', 436, 'McGraw-hill', 0, 1, '2000'),
(388, 182, 'Electronic Books', 'Virus Troubleshooting Pocket Reference', 'Bigelow, Stephen', '', 267, 'McGraw-hill', 0, 1, '2001'),
(389, 183, 'Electronic Books', 'Communication Electronics', 'Frenzel, Loius', '2nd', 428, 'Glencoe/ McGraw-hill', 0, 1, '1995'),
(390, 184, 'Electronic Books', 'Electronics made Easy', 'Stern, Lothar', 'revised and enlarged', 216, 'Popular Bookstore', 0, 1, '1962'),
(391, 185, 'Electronic Books', 'Fundamentals and Elements of Electricity', 'Cardenas, Elpidio J.', '2010 reprint', 141, 'Natl. Book Store', 0, 1, '1989'),
(392, 186, 'Electronic Books', 'IBM Personal Computer Troubleshooting and Repair', 'Brenner Robert', '1990 reprint', 488, 'Howard Sams', 0, 1, '1989'),
(394, 187, 'Math Books', 'Mathematics of Finance', 'Hernandez, Rogelio et.al', '', 169, 'Booklore', 0, 1, '2009'),
(395, 188, 'Math Books', 'Modern College Algebra', 'Dayrit, Benjamin C.', 'Revised, 2003 reprint', 238, 'Rex Book Store', 0, 1, '2002'),
(396, 189, 'Math Books', 'College Algebra Text/Workbook', 'Salamat Lorina', '4th', 275, 'Natl. Book Store', 0, 1, '2008'),
(397, 190, 'Math Books', 'College Algebra', 'Salazar, Douglas', '1st', 324, 'Rex Book Store', 0, 1, '2010'),
(398, 191, 'Math Books', 'College Algebra for Computer Science and Allied Programs', 'Lopez, Joseph', '', 248, 'Booklore', 0, 1, '2009'),
(399, 192, 'Math Books', 'Basic Mathematics for College Students', 'Benigno, Gloria D.', 'Revised, 2006 reprint', 280, 'Rex Book Store', 0, 1, '2006'),
(400, 193, 'Math Books', 'College Mathematics: A Modern Mathematics', 'Sta Maria, Antonina', '3rd 2009 reprint', 239, 'Natl. Book Store', 0, 1, '2008'),
(401, 194, 'Math Books', 'Strength of Materials', 'Mejia, Dominador A.', '1st, 2002 reprint', 133, 'Rex Book Store', 0, 1, '1998'),
(402, 195, 'Math Books', 'Mathematics of Investment', 'Florante M. Capitulo', '3rd, 2010 reprint', 357, 'Natl. Book Store', 0, 1, '2006'),
(403, 196, 'Math Books', 'Software Engineering', 'Bell, Douglas', '3rd', 470, 'Addison Wesley', 0, 1, '2002'),
(404, 197, 'Math Books', 'Mathematics in Business', 'Caras, Madeleine S. et. Al', '3rd', 289, 'Booklore', 0, 1, '2009'),
(405, 198, 'Math Books', 'Mathematics of Investment (Worktext)', 'Cervillion, Carmelita C.', '2010 reprint', 224, 'Natl. Book Store', 0, 1, '2003'),
(406, 199, 'Math Books', 'Understanding Operating Systems', 'Flynn Ida', '4th', 555, 'Course Technology', 0, 1, '2007'),
(407, 200, 'Math Books', 'Discrete Mathematics', 'Washburn, Sherwood', '', 370, 'Pearson Educ. Inc', 0, 1, '2002'),
(408, 201, 'Math Books', 'Analytic and Solid Geometry made easy', 'Comandante Jr., Felipe L.', 'Metric, 2008 reprint', 399, 'Natl. Book Store', 0, 1, '2000'),
(409, 202, 'Math Books', 'Introduction to Discrete Mathematics', 'Johnsonbaugh, Richard', '7th', 0, 'Global', 0, 1, '2006'),
(410, 203, 'Math Books', 'College Algebra', 'Rees, Paul', '10th', 574, 'McGraw-hill', 0, 1, '1990'),
(411, 204, 'Math Books', 'Discrete Mathematics', 'Johnsonbaugh, Richard', '6th', 672, 'Pearson Educ. Inc', 0, 1, '2006'),
(412, 205, 'Math Books', 'Succeeding Algebra and Trigonometry', 'Larson, Ron', '', 1281, 'Cengage Learning', 0, 1, '2010'),
(413, 206, 'Math Books', 'The Secretary for Corporate World', 'De Guzman, Dionisia', '1st', 322, 'Rex Book Store', 0, 1, '2006'),
(414, 207, 'Math Books', 'Rudiments of College Algebra and Trigonometry', 'Santos, Gil Nonato C.', '1st', 311, 'Rex Book Store', 0, 1, '2009'),
(415, 208, 'Math Books', 'College Algebra', 'Young, Felina', '2010 reprint', 493, 'Rex Book Store', 0, 1, '2005'),
(416, 209, 'Math Books', 'Algebra for College Students', 'Dugopolski, Mark', '', 889, 'McGraw-hill', 0, 1, '2006'),
(417, 210, 'Math Books', 'Basic Statistics for the Tertiary Level', 'Albert, Jose Ramon G.', '1st', 257, 'Rex Book Store', 0, 1, '2008'),
(418, 211, 'Math Books', 'Basic Concepts in Statistics (Worktext)', 'Tattao, Luis A.', '1st, 2009 reprint', 361, 'Rex Book Store', 0, 1, '2007'),
(419, 212, 'Math Books', 'Modern Algebra and Trigonometry', 'Vance, Elbridge P.', '3rd, 1984 reprint', 436, 'Addison Wesley', 0, 1, '1973'),
(420, 213, 'Math Books', 'Plane Trigonometry: Simplified and Integrated', 'Reyes, Edgardo A.', '2010 reprint', 241, 'Natl. Book Store', 0, 1, '1963'),
(421, 214, 'Math Books', 'Model Letters for all Occasions, Sentence stress, and Emphasis', 'Maria Odulio de Guzman', '2010 reprint', 81, 'Atlas', 0, 1, '1973'),
(422, 215, 'Math Books', 'Business Mathematics', 'Altares Priscilla', 'Revised 2010 reprint', 291, 'Rex Book Store', 0, 1, '2004'),
(423, 216, 'Math Books', 'Introductory Accounting ? Part 2', 'Passion D.S.', '2002 reprint', 252, 'Phoenix', 0, 1, '1968'),
(424, 217, 'Math Books', 'Accounting Principles 4 Text/Workbook', 'Arganda, Amelia', '4th', 177, 'Natl. Book Store', 0, 1, '2007'),
(425, 218, 'Math Books', 'Study Skills in English for a Changing World', 'Flores, Magelende', '1st, 2004 reprint', 228, 'Rex Book Store', 0, 1, '2001'),
(426, 219, 'Math Books', 'Modern English for College Freshmen', 'Bassig, Ricardo C.', '3rd', 220, 'South-Western', 0, 1, '1973'),
(427, 220, 'Math Books', 'Mathematical Analysis for Business Economics', 'Altares, Priscilla et. al', '1st, 2010 reprint', 242, 'Rex Book Store', 0, 1, '2007'),
(428, 221, 'Math Books', 'Solved Problems in Differential Calculus', 'Cabero, Jonathan B.', '', 88, 'Natl. Book Store', 0, 1, '2008'),
(429, 222, 'Math Books', 'Solved Problems in Integral Calculus', 'Cabero, Jonathan B.', '', 110, 'Natl. Book Store', 0, 1, '2008'),
(430, 223, 'Math Books', 'Quantitative Techniques for Business (with Computer Application)', 'Altares, Priscilla et. al', 'Revised, 2008 reprint', 301, 'Rex Book Store', 0, 1, '2004'),
(431, 224, 'Math Books', 'Simplified Approach to Integral Calculus', 'Apa-ap, Renato E. et. Al', '2009 reprint', 262, 'Natl. Book Store', 0, 1, '2007'),
(432, 225, 'Math Books', 'Mathematics of Investment by Scientific Calculator', 'Malaborbor, Pastor B.', '2nd', 203, 'Natl. Book Store', 0, 1, '2009'),
(433, 226, 'Math Books', 'Mathematics of Investment (based on CMO 03 Series 2007)', 'Arce et. Al', '1st', 262, 'Rex Book Store', 0, 1, '2010'),
(435, 227, 'Acctg, Management & Marketing', 'Management Advisory Services', 'Harina, Ricardo M.', '3rd revised', 514, 'Natl. Book Store', 0, 1, '2008'),
(436, 228, 'Acctg, Management & Marketing', 'College Accounting 2', 'Harina, Ricardo', 'revised', 203, 'Natl. Book Store', 0, 1, '2011'),
(437, 229, 'Acctg, Management & Marketing', 'Business Mathematics Text/Workbook', 'Lorina Gison Salamat', '3rd', 225, 'Natl. Book Store', 0, 1, '2008'),
(438, 230, 'Acctg, Management & Marketing', 'Accounting Principles 3 Text/Workbook', 'Herrero, Carmen C.', '4th, 2009 reprint', 300, 'Natl. Book Store', 0, 1, '2007'),
(439, 231, 'Acctg, Management & Marketing', 'Laboratory Manual in Statistics 1 (Elementary Statistics)', 'Nalangan, Li-anne', '1st', 102, 'Rex Book Store', 0, 1, '2009'),
(440, 232, 'Acctg, Management & Marketing', 'Analytic Geometry with Solid Mensuration made Easy', 'Comandante Jr., Felipe L.', '', 402, 'Natl. Book Store', 0, 1, '2000'),
(441, 233, 'Acctg, Management & Marketing', 'Introduction to the Theory of Computation', 'Sipser Michael', '2nd', 437, 'Course Technology', 0, 1, '2007'),
(442, 234, 'Acctg, Management & Marketing', 'Basic Business Finance: Management Approach', 'Alminar-Mutya, Ruby F.', '', 272, 'Natl. Book Store', 0, 1, '2010'),
(443, 235, 'Acctg, Management & Marketing', 'Artificial Intelligence', 'Luger, George F.', '4th', 856, 'Addison Wesley', 0, 1, '2003'),
(444, 236, 'Acctg, Management & Marketing', 'Tax Accounting Digest: An Accountants Guide', 'Co Untian Jr., Crescencio', '', 408, 'Rex Book Store', 0, 1, '2008'),
(445, 237, 'Acctg, Management & Marketing', 'Principles of Marketing', 'Medina, Roberto G.', 'revised', 326, 'Rex Book Store', 0, 1, '2008'),
(446, 238, 'Acctg, Management & Marketing', 'Basic Accounting Concepts and Procedures', 'Garcia, Percy C.', '1st', 226, 'Rex Book Store', 0, 1, '2006'),
(447, 239, 'Acctg, Management & Marketing', 'Selected Terms and Phrases in Finance, Accounting, and Economics', 'Ditablan, Eustaquio C.', '', 95, 'Natl. Book Store', 0, 1, '2008'),
(448, 240, 'Acctg, Management & Marketing', 'Modules for Marketing', 'Mendoza, Shirley', '1st, 2005 reprint', 184, 'Rex Book Store', 0, 1, '2003'),
(449, 241, 'Acctg, Management & Marketing', 'Differential Calculus Made Easy', 'Comandante Jr., Felipe L.', 'Mertic, 2010 reprint', 410, 'Natl. Book Store', 0, 1, '2005'),
(450, 242, 'Acctg, Management & Marketing', 'Basic Accounting for Non-Accountants', 'Monte-Galanza, Raquel', '1st, 2006 reprint', 170, 'Rex Book Store', 0, 1, '2005'),
(451, 243, 'Acctg, Management & Marketing', 'Logic: The Essentials of Deductive Reasoning', 'Agapay, Ramon', '2nd, 2009 reprint', 180, 'Natl. Book Store', 0, 1, '2007'),
(452, 244, 'Acctg, Management & Marketing', 'Introductory Statistics', 'Pagoso, Cristobal', '1997 reprint', 391, 'Rex Book Store', 0, 1, '1985'),
(453, 245, 'Acctg, Management & Marketing', 'Mathematics of Investment made simple', 'Young, Felina', '1st, 2010 reprint', 353, 'Rex Book Store', 0, 1, '2009'),
(454, 246, 'Acctg, Management & Marketing', 'Business Ethics', 'Padilla, Reynaldo', '1st, 2010 reprint', 184, 'Rex Book Store', 0, 1, '2004'),
(455, 247, 'Acctg, Management & Marketing', 'Business Finance', 'Medina, Roberto G.', '2nd, 2010 reprint', 228, 'Rex Book Store', 0, 1, '2007'),
(456, 248, 'Acctg, Management & Marketing', 'Business Finance', 'Dela Cruz, Manuel', '1st, 2006 reprint', 388, 'Rex Book Store', 0, 1, '2005'),
(457, 249, 'Acctg, Management & Marketing', 'Principles of Marketing', 'Medina, Roberto G.', 'revised', 326, 'Rex Book Store', 0, 1, '2008'),
(458, 250, 'Acctg, Management & Marketing', 'Essential Logic', 'Malitao, Arnel', '', 266, 'Natl. Book Store', 0, 1, '2003'),
(459, 251, 'Acctg, Management & Marketing', 'Accounting Principles & Procedures for a Sole Proprietorship', 'Monte-Galanza, Raquel', '1st, 2006 reprint', 255, 'Rex Book Store', 0, 1, '2003'),
(460, 252, 'Acctg, Management & Marketing', 'Fundamentals of Agribusiness Accounting', 'Umiten-Hipolito, Silva', '1st', 178, 'Rex Book Store', 0, 1, '2008'),
(461, 253, 'Acctg, Management & Marketing', 'Simplified Approaches to Differential Calculus', 'Jonathan B. Cabero et. Al', '2nd', 207, 'Natl. Book Store', 0, 1, '2010'),
(462, 254, 'Acctg, Management & Marketing', 'Introduction to College Algebra', 'Monta?a, Rizalina', '1st', 87, 'Rex Book Store', 0, 1, '2009'),
(463, 255, 'Acctg, Management & Marketing', 'Elements of Logic: An Integrated Approach', 'Maboloc, Christopher Ryan', '1st', 142, 'Rex Book Store', 0, 1, '2008'),
(464, 256, 'Acctg, Management & Marketing', 'Quantitative methods in Accounting', 'Ng, Mark Francis G.', '1st', 217, 'Rex Book Store', 0, 1, '2010'),
(465, 257, 'Acctg, Management & Marketing', 'Business Mathematics Made Easy', 'Paras-Bernal Ophelia', '1st, 2008 reprint', 201, 'Rex Book Store', 0, 1, '2007'),
(466, 258, 'Acctg, Management & Marketing', 'Mathematics of Investment', 'William L. Hart', '5th', 152, 'D.C. Health and Com', 0, 1, '1980'),
(467, 259, 'Acctg, Management & Marketing', 'Plane and Spherical Trigonometry with Tables', 'William L. Hart', '', 124, 'D.C. Health and Com', 0, 1, '1964'),
(468, 260, 'Acctg, Management & Marketing', 'Plane and Spherical Trigonometry with Tables', 'Paul R. Rider', '', 142, 'The MacMillan Comp', 0, 1, '1971'),
(469, 261, 'Acctg, Management & Marketing', 'Bookkeeping for Servicing & Merch. Firms applied Basic Accounting Practice', 'Ebusca, Saturnina', '1st', 387, 'Rex Book Store', 0, 1, '2007'),
(470, 262, 'Acctg, Management & Marketing', 'Global Marketing', 'Johansson Johnny', '4th', 647, 'McGraw-hill', 0, 1, '2006'),
(471, 263, 'Acctg, Management & Marketing', 'Partnership and Corporation Accounting', 'Carillo, Josefina', '1st new, 2005 reprint', 164, 'Rex Book Store', 0, 1, '1997'),
(472, 264, 'Acctg, Management & Marketing', 'Quantitative Techniques for Business Management (Textbook)', 'Victoriano, Praxedes S.', '2nd, 2010 reprint', 229, 'Rex Book Store', 0, 1, '1990'),
(473, 265, 'Acctg, Management & Marketing', 'Essentials of Investment', 'Bodie Zvi', '6th', 571, 'McGraw-hill', 0, 1, '2007'),
(474, 266, 'Acctg, Management & Marketing', 'Financial & Managerial Accounting', 'Williams Jan et.al', '14th', 1157, 'McGraw-hill', 0, 1, '2008'),
(475, 267, 'Acctg, Management & Marketing', 'Fundamentals of Accounting Principles (Theory & Application) Part 2', 'Chua Manuel', '', 608, 'Natl. Book Store', 0, 1, '2007'),
(476, 268, 'Acctg, Management & Marketing', 'Introduction to Managerial Accounting', 'Brewer Peter', '2nd', 640, 'McGraw-hill', 0, 1, '2005'),
(477, 269, 'Acctg, Management & Marketing', 'Managerial Accounting', 'Ray H. Garrison', '13th 2011', 804, 'McGraw-hill', 0, 1, '2011'),
(478, 270, 'Acctg, Management & Marketing', 'Partnership and Corporation Accounting and their Legal Bases', 'Hugo-Macapilit, Cecilia', '1st', 219, 'Rex Book Store', 0, 1, '2010'),
(479, 271, 'Acctg, Management & Marketing', 'Events Management Handbook', 'Romero, Eloisa', '1st, 2010 reprint', 86, 'Rex Book Store', 0, 1, '2009'),
(480, 272, 'Acctg, Management & Marketing', 'Personnel Management in the 21st Century', 'Sison, Perfecto S.', '7th, 2010 reprint', 218, 'Rex Book Store', 0, 1, '2003'),
(481, 273, 'Acctg, Management & Marketing', 'Principles of Marketing', 'Ac-ac, Maria Victorina M.', '', 285, 'Natl. Book Store', 0, 1, '2009'),
(482, 274, 'Acctg, Management & Marketing', 'Business Marketing', 'Dwyer, Robert', '3rd', 683, 'McGraw-hill', 0, 1, '2006'),
(483, 275, 'Acctg, Management & Marketing', 'Modern Technological Writing', 'Asuncion', '', 310, 'Rajh Publishing House', 0, 1, '2011'),
(484, 276, 'Acctg, Management & Marketing', 'Marketing for Dummies', 'Alexander Hiam', '3rd', 368, 'Wiley', 0, 1, '2009'),
(485, 277, 'Acctg, Management & Marketing', 'Basic Statistical Methods', 'Norville, Downie', '5th', 371, 'Harper & Row', 0, 1, '1984'),
(486, 278, 'Acctg, Management & Marketing', 'A Practical Guide to Business Communication', 'Taylor, Shirley', '4th', 429, 'Pearson Educ. Inc', 0, 1, '2006'),
(487, 279, 'Acctg, Management & Marketing', 'Elements of Marketing', 'Ruby Alminar-Mutya', '4th, 2008 reprint', 305, 'Natl. Book Store', 0, 1, '2007'),
(488, 280, 'Acctg, Management & Marketing', 'Principles of Marketing', 'Young, Felina', '1st, 2009 reprint', 433, 'Rex Book Store', 0, 1, '2008'),
(489, 281, 'Acctg, Management & Marketing', 'Fundamentals of Strategic Management', 'Orcullo Jr. Norberto', '1st, 2009 reprint', 302, 'Rex Book Store', 0, 1, '2007'),
(490, 282, 'Acctg, Management & Marketing', 'Management', 'Fajardo, Feliciano', '1st, 2009 reprint', 331, 'Rex Book Store', 0, 1, '1997'),
(491, 283, 'Acctg, Management & Marketing', 'Business Organization and Management', 'Medina, Roberto G.', '2009 reprint', 257, 'Rex Book Store', 0, 1, '2006'),
(492, 284, 'Acctg, Management & Marketing', 'Tagalog-English Dictionary', 'Leo, James', '2010 reprint', 1583, 'Natl. Book Store', 0, 1, '1969'),
(493, 285, 'Acctg, Management & Marketing', 'Comprehensive Review of Taxation', 'De Leon, Hector', '8th', 493, 'Rex Book Store', 0, 1, '2010'),
(494, 286, 'Acctg, Management & Marketing', 'Managing Human Resources in the 21st Century', 'Maximiano J.', '', 0, 'Rex Book Store', 0, 1, '2006'),
(495, 287, 'Acctg, Management & Marketing', 'Fundamentals of Financial Management', 'Anastacio, Ma. Flordeliza', '1st', 210, 'Rex Book Store', 0, 1, '2010'),
(496, 288, 'Acctg, Management & Marketing', 'Human Resource Management', 'Conception, Rodil Martires', '3rd, 2008 reprint', 461, 'Natl. Book Store', 0, 1, '1999'),
(497, 289, 'Acctg, Management & Marketing', 'Trigonometry', 'Reyes, Fe N. et.al', '2nd, 2008 reprint', 394, 'Natl. Book Store', 0, 1, '2000'),
(499, 290, 'Economic, Humanities & Law', 'Principles of Economics', 'Pagoso, Cristobal', '1st, 2010 reprint', 387, 'Rex Book Store', 0, 1, '2008'),
(500, 291, 'Economic, Humanities & Law', 'Introductory Macroeconomics', 'Pagoso, Cristobal', 'Revised 2011 reprint', 277, 'Rex Book Store', 0, 1, '2006'),
(501, 292, 'Economic, Humanities & Law', 'Principles of Economics', 'Case, Karl E.', '9th', 811, 'Prentice Hall', 0, 1, '2009'),
(502, 293, 'Economic, Humanities & Law', 'Principles of Economics with Taxation and Agrarian Reform', 'Marcelino, Ramon Benedict', '', 238, 'Natl. Book Store', 0, 1, '2010'),
(503, 294, 'Economic, Humanities & Law', 'Manual for Economics with Work Exercises', 'Silon et.al', '', 0, 'Rex Book Store', 0, 1, '2009'),
(504, 295, 'Economic, Humanities & Law', 'The Constitution of the Republic of the Philippines Explained', 'Nolledo, Jose', 'revised', 615, 'Natl. Book Store', 0, 1, '2005'),
(505, 296, 'Economic, Humanities & Law', 'Disquisitions on the 1987 Constitution of the Philippines', 'Aralar Reynaldo', '', 403, 'Natl. Book Store', 0, 1, '2008'),
(506, 297, 'Economic, Humanities & Law', 'Philippine Governance and the 1987 Constitution', 'Lazo, Ricardo S.', '2nd', 0, 'Rex Book Store', 0, 1, '2009'),
(507, 298, 'Economic, Humanities & Law', 'A Study Guide in Philippine History', 'Funtecha, Henry Florida', '1st', 142, 'Rex Book Store', 0, 1, '2010'),
(508, 299, 'Economic, Humanities & Law', 'Cooperatives', 'Fajardo, Feliciano', '4th, 2004 reprint', 308, 'Rex Book Store', 0, 1, '1999'),
(509, 300, 'Economic, Humanities & Law', 'Introduction to Accounting', 'Saguinsin, Artemio', '1st', 326, 'Rex Book Store', 0, 1, '2010'),
(510, 301, 'Economic, Humanities & Law', 'Elementary Economics 1', 'Sicat, Gerardo', 'new', 359, 'Anvil', 0, 1, '2003'),
(511, 302, 'Economic, Humanities & Law', 'Economics Concept Theories and Applications', 'Nebres, Abriel', '2010 reprint', 312, 'Natl. Book Store', 0, 1, '2008'),
(512, 303, 'Economic, Humanities & Law', 'Economics: It\'s Concepts and Principles with Agrarian Reform', 'Gabay, Bon Kristoffer', '1st, 2010 reprint', 321, 'Rex Book Store', 0, 1, '2007'),
(513, 304, 'Economic, Humanities & Law', 'Economics', 'Fajardo, Feliciano', '3rd, 2009 reprint', 367, 'Rex Book Store', 0, 1, '1995'),
(514, 305, 'Economic, Humanities & Law', 'Constitution Made Simple', 'De Leon, Hector', '3rd reprint', 321, 'Rex Book Store', 0, 1, '2010'),
(515, 306, 'Economic, Humanities & Law', 'Student\'s Manual on the Constitution', 'De Leon, Hector', '6th', 364, 'Rex Book Store', 0, 1, '2010'),
(516, 307, 'Economic, Humanities & Law', 'Statistics for Research', 'Subong Jr., Pablo E.', '1st, 2006 reprint', 209, 'Rex Book Store', 0, 1, '2005'),
(517, 308, 'Economic, Humanities & Law', 'Student\'s Manual on the New Constitution with Study Help', 'Nolledo, Jose N.', 'Revised 2010 reprint', 207, 'Natl. Book Store', 0, 1, '2008'),
(518, 309, 'Economic, Humanities & Law', 'Humanities and the Digital Arts', 'Bascara, Linda', '1st, 2007 reprint', 185, 'Rex Book Store', 0, 1, '2006'),
(519, 310, 'Economic, Humanities & Law', 'Ethics and Human Dignity', 'Maboloc, Christopher Ryan', '1st', 135, 'Rex Book Store', 0, 1, '2010'),
(520, 311, 'Economic, Humanities & Law', 'The Humanities', 'Zulueta, Francisco', 'Revised, 2008 reprint', 307, 'Natl. Book Store', 0, 1, '2003'),
(521, 312, 'Economic, Humanities & Law', 'Introduction to Humanities (The Art for Fine Living)', 'Josefina Estolas', '2008 reprint', 270, 'Natl. Book Store', 0, 1, '1995'),
(522, 313, 'Economic, Humanities & Law', 'Fundamentals of Political Science', 'Florentino Ayson', '2nd, 2009 reprint', 448, 'Natl. Book Store', 0, 1, '2000'),
(523, 314, 'Economic, Humanities & Law', 'Politics, Governance and the Philippine Constitution', 'Rivas, Dionisio', '1st', 327, 'Rex Book Store', 0, 1, '2010'),
(524, 315, 'Economic, Humanities & Law', 'Textbook on the Philippine Constitution', 'De Leon, Hector', '2009 reprint', 776, 'Rex Book Store', 0, 1, '2008'),
(525, 316, 'Economic, Humanities & Law', 'Law of Basic Taxation in the Philippines', 'Aban, Benjamin', 'Revised , 2009 reprint', 579, 'Natl. Book Store', 0, 1, '2009'),
(526, 317, 'Economic, Humanities & Law', 'Textbook on Agrarian Reform & Taxation with Cooperatives', 'De Leon, Hector', '13th', 453, 'Rex Book Store', 0, 1, '2005'),
(527, 318, 'Economic, Humanities & Law', 'The Law on Obligations and Contracts', 'De Leon, Hector', 'Revised 2010 reprint', 459, 'Rex Book Store', 0, 1, '2008'),
(528, 319, 'Economic, Humanities & Law', 'Politics and Governance', 'Costales, Rodrigo', '1st', 320, 'Rex Book Store', 0, 1, '2010'),
(529, 320, 'Economic, Humanities & Law', 'The Law on Partnership and Private Corporations', 'De Leon, Hector', '2011 reprint', 607, 'Rex Book Store', 0, 1, '2010'),
(530, 321, 'Economic, Humanities & Law', 'Comprehensive Review of Business Law', 'De Leon, Hector', '9th', 572, 'Rex Book Store', 0, 1, '2010'),
(531, 322, 'Economic, Humanities & Law', 'Business Ethics and Social Responsibility', 'Roa Floriano', '1st, 2010 reprint', 242, 'Rex Book Store', 0, 1, '2007'),
(532, 323, 'Economic, Humanities & Law', 'The 1987 Constitution of the Republic of the Philippines', '', '', 79, 'Natl. Book Store', 0, 1, '1987'),
(533, 324, 'Economic, Humanities & Law', 'Gymnastic Book', 'Di?oso, Clarita', '2009 reprint', 151, 'Rex Book Store', 0, 1, '1990'),
(534, 325, 'Economic, Humanities & Law', 'Typewriting/Keyboarding and Word Processing', 'Pineda, Dolores', '2010 reprint', 133, 'Natl. Book Store', 0, 1, '1994'),
(535, 326, 'Economic, Humanities & Law', 'Typewriting/Keyboarding and Word Processing', 'Pineda, Dolores', '2010 reprint', 133, 'Natl. Book Store', 0, 1, '1994'),
(536, 327, 'Economic, Humanities & Law', 'Typewriting for Beginners', 'Pineda, Dolores', 'Revised 2010 reprint', 152, 'Natl. Book Store', 0, 1, '1984'),
(563, 0, 'category', 'title', 'author', 'edition', 0, 'publisher', 0, 0, 'copyright'),
(564, 328, 'Business Books', 'Bookkeeping for Servicing & Merch. Firms (An Introduction to Accounting)', 'Ebusca, Saturnina', '2010 reprint', 454, 'Rex Book Store', 0, 1, '2008'),
(565, 329, 'Business Books', 'Money, Credit, and Banking', 'Pagoso, Cristobal', '1st, 2010 reprint', 263, 'Rex Book Store', 0, 1, '2010'),
(566, 330, 'Business Books', 'Handbook in Business Technology', 'Abello, Lovell', '', 96, 'Natl. Book Store', 0, 1, '2010'),
(567, 331, 'Business Books', 'Marketing Cases Book 2', 'Lao Jr., Felix', '', 134, 'Anvil', 0, 1, '2001'),
(568, 332, 'Business Books', 'Human Resource Management', 'Payos, Ranulfo', '', 265, 'Rex Book Store', 0, 1, '2010'),
(569, 333, 'Business Books', 'Fundamentals of  Philippine Income Taxation', 'Conti Indalicio', '1st, 2010 reprint', 456, 'Rex Book Store', 0, 1, '2009'),
(570, 334, 'Business Books', 'International Business', 'Shenkar Oded', '', 513, 'John Wiley & Sons Inc.', 0, 1, '2004'),
(571, 335, 'Business Books', 'Introduction to Entrepreneurship', 'Small Enterprise Research', '2008 reprint', 204, 'Anvil', 0, 1, '2006'),
(572, 336, 'Business Books', 'Business Plans Made Easy', 'Bangs Jr, David', '3rd', 361, 'Entrepreneur Media', 0, 1, '2005'),
(573, 337, 'Business Books', 'Business Law: An Overview', 'De Guzman, Rolando', '', 232, 'Rex Book Store', 0, 1, '2006'),
(574, 338, 'Business Books', 'Quantitative Techniques in Management', 'Apa-ap, Renato E. et. Al', 'revised', 182, 'Natl. Book Store', 0, 1, '2007'),
(575, 339, 'Business Books', 'The Fundamentals of Taxation', 'De Leon, Hector', '', 437, 'Rex Book Store', 0, 1, '2009'),
(576, 340, 'Business Books', 'The Law on Transfer and Business Taxation', 'De Leon, Hector', '', 668, 'Rex Book Store', 0, 1, '2009'),
(577, 341, 'Business Books', 'The Law on Sales Agency and Credit Transactions', 'De Leon, Hector', '', 494, 'Rex Book Store', 0, 1, '2010'),
(578, 342, 'Business Books', 'Insurance Principles and Practices', 'Ronquillo, Zacarias', 'revised', 136, 'Rex Book Store', 0, 1, '2007'),
(579, 343, 'Business Books', 'Bookkeeping Manual for Merchandising Companies', 'Monte-Galanza, Raquel', '', 113, 'Rex Book Store', 0, 1, '2009'),
(580, 344, 'Business Books', 'Entrepreneurship Unlimited Opportunities and Resources', 'Ditablan, Eustaquio C.', '2010 reprint', 235, 'Natl. Book Store', 0, 1, '2009'),
(581, 345, 'Business Books', 'Wealth Within your Reach: Pera Mo, Palaguin Mo 1', 'Colayco, Francisco', '', 328, 'Colayco Foundation', 0, 1, '2004'),
(582, 346, 'Business Books', 'Making your Money Work: Pera Mo, Palaguin Mo 2', 'Colayco, Francisco', '', 221, 'Colayco Foundation', 0, 1, '2005'),
(583, 347, 'Business Books', 'Business Ethics and Corporate Social Responsibility', 'Maximiano Jose Mario', '', 232, 'Anvil', 0, 1, '2007'),
(584, 348, 'Business Books', 'Human Behavior in Organizations', 'Concepcion, Rodil Martires', '3rd, 2010 reprint', 258, 'Natl. Book Store', 0, 1, '2003'),
(585, 349, 'Business Books', 'Entrepreneurship for Modern Business', 'Camposano, Jorge', '2008 reprint', 524, 'Natl. Book Store', 0, 1, '2006'),
(586, 350, 'Business Books', 'Entrepreneurship in the Philippine Setting', 'Asor, Winefreda', '1st, 2010 reprint', 238, 'Rex Book Store', 0, 1, '2009'),
(587, 351, 'Business Books', 'Global Business Ethics for Filipinos in the New Millennium', 'Maximiano Jose Mario', '', 244, 'Anvil', 0, 1, '2001'),
(588, 352, 'Business Books', 'Filipino Valuers Today', 'Florentino, Timbreza', '2008 reprint', 230, 'Natl. Book Store', 0, 1, '2003'),
(589, 0, 'category', 'title', 'author', 'edition', 0, 'publisher', 0, 0, 'copyright'),
(590, 353, 'Philosophy and Psychology', 'Ethics: A Class Manual in Moral Philosophy', 'Glenn Paul', '', 302, 'B. Herder Book Corp', 0, 1, '1968'),
(591, 354, 'Philosophy and Psychology', 'Introduction to the Humanities', 'Doris Van de Bogart', '', 422, 'Barnes & Noble Inc.', 0, 1, '1970'),
(592, 355, 'Philosophy and Psychology', 'Kapwa', 'De Guia, Katrin', '2008 reprint', 378, 'Anvil', 0, 1, '2005'),
(593, 356, 'Philosophy and Psychology', 'Modern and Contemporary Philosophy', 'Nabor-Nery, Maria Imelda', '', 224, 'Natl. Book Store', 0, 1, '2006'),
(594, 357, 'Philosophy and Psychology', 'Philosophy of Man: The Existential Drama', 'Maboloc, Christopher Ryan', '', 135, 'Rex Book Store', 0, 1, '2009'),
(595, 358, 'Philosophy and Psychology', 'Philosophy of Education', 'Duka, Cecilio D.', 'revised', 164, 'Rex Book Store', 0, 1, '2006'),
(596, 359, 'Philosophy and Psychology', 'Fundamental Philosophies of Education', 'Priscilla Bauzon', '3rd', 192, 'Natl. Book Store', 0, 1, '2009'),
(597, 360, 'Philosophy and Psychology', 'Understanding Human Behavior: A Psychology Worktext', 'Rodriguez, Tessie J.', '1st', 298, 'Rex Book Store', 0, 1, '2009'),
(598, 361, 'Philosophy and Psychology', 'Social Philosophy 2', 'Almeida, Adelaida B.', '1st, 2006 reprint', 101, 'Rex Book Store', 0, 1, '2005');
INSERT INTO `books` (`id`, `number`, `category`, `title`, `author`, `edition`, `pages`, `publisher`, `isbn`, `copies`, `copyright`) VALUES
(599, 362, 'Philosophy and Psychology', 'Social Philosophy: Foundations of Values Education', 'Tiempo, Alex', '1st, 2006 reprint', 134, 'Rex Book Store', 0, 1, '2005'),
(600, 363, 'Philosophy and Psychology', 'General Psychology', 'Zulueta, Francisco', '2006 reprint', 474, 'Natl. Book Store', 0, 1, '2004'),
(601, 364, 'Philosophy and Psychology', 'Educational Psychology', 'Gines, Adelaida', 'New 2005 reprint', 361, 'Rex Book Store', 0, 1, '1998'),
(602, 365, 'Philosophy and Psychology', 'Developmental Psychology', 'Gines, Adelaida', 'New 2007', 267, 'Rex Book Store', 0, 1, '1998'),
(603, 366, 'Philosophy and Psychology', 'General Psychology', 'Gines et.al', '', 0, 'Rex Book Store', 0, 1, '2003'),
(604, 367, 'Philosophy and Psychology', 'Smart Guide to Apprenticeship and Practicum Training', 'Cabulay, Danny Araneta', '1st', 191, 'Rex Book Store', 0, 1, '2009'),
(605, 368, 'Philosophy and Psychology', 'Facilitating Human Learning', 'Aquino, Avelina', '1st, 2010 reprint', 392, 'Rex Book Store', 0, 1, '2009'),
(606, 369, 'Philosophy and Psychology', 'Critical Thinking', 'Moore, Brooke Noel', '9th', 537, 'McGraw-hill', 0, 1, '2009'),
(607, 370, 'Philosophy and Psychology', 'Introduction to Psychology', 'Carson-Arenas, Aggie', '2005 reprint', 423, 'Rex Book Store', 0, 1, '2004'),
(608, 371, 'Philosophy and Psychology', 'Organizational Behavior: Human Behavior at Work', 'Newstrom, John W.', '13th', 554, 'McGraw-hill', 0, 1, '2011'),
(609, 372, 'Philosophy and Psychology', 'Psychology: Essentials to Understanding Behavior', 'Miranda, Norma C.', '', 338, 'Natl. Book Store', 0, 1, '2008'),
(610, 373, 'Philosophy and Psychology', 'Introduction to Psychology', 'Aquino, Gaudencio', '2nd, 2005  reprint', 647, 'Natl. Book Store', 0, 1, '2003'),
(611, 374, 'Philosophy and Psychology', 'Introduction to the Humanities', 'Sanchez, Custodiosa', '2009 reprint', 242, 'Rex Book Store', 0, 1, '2002'),
(612, 375, 'Philosophy and Psychology', 'General Sociology', 'Zulueta, Francisco', '', 233, 'Academic Publishing', 0, 1, '2002'),
(613, 376, 'Philosophy and Psychology', 'The Labor Code of the Philippines', 'Foz, Vicente B.', '', 584, 'Philippine Law Gazet', 0, 1, '2009'),
(614, 377, 'Philosophy and Psychology', 'Psychological Measurement and Evaluation', 'Santos, Zenaida C.', '1st', 221, 'Rex Book Store', 0, 1, '2009'),
(615, 378, 'Philosophy and Psychology', 'The Filipino Family in Constant Revolution', 'Guillermo, Maria Lirio', '1st', 28, 'Rex Book Store', 0, 1, '2007'),
(616, 379, 'Philosophy and Psychology', 'Philosophy of Man', 'Maria Imelda Nabor-Nery', '2009 reprint', 330, 'Natl. Book Store', 0, 1, '2007'),
(617, 380, 'Philosophy and Psychology', 'Globalization and Technology', 'Ramos, Christine Carmela', '1st, 2005 reprint', 121, 'Rex Book Store', 0, 1, '2003'),
(618, 381, 'Philosophy and Psychology', 'General Psychology with Values Development Lessons', 'Sevilla, Consuelo et.al', '4th, 2008 reprint', 495, 'Rex Book Store', 0, 1, '2006'),
(619, 382, 'Philosophy and Psychology', 'Principles of Economics', 'Medina, Roberto G.', '1st, 2009 reprint', 286, 'Rex Book Store', 0, 1, '2003'),
(620, 383, 'Philosophy and Psychology', 'General Psychology', 'Beltran, Jane', 'Revised , 2009 reprint', 202, 'Rex Book Store', 0, 1, '1996'),
(621, 384, 'Philosophy and Psychology', 'Counseling and Psychotherapy', 'Padolina, Miriam', '2004 reprint', 261, 'Rex Book Store', 0, 1, '1997'),
(622, 385, 'Philosophy and Psychology', 'Introduction to Values Education', 'Palispis, Epitacio', '2007 reprint', 179, 'Rex Book Store', 0, 1, '1995'),
(623, 386, 'Philosophy and Psychology', 'Guidance and Counseling in Schools', 'Linda Ambida-Cinco', '2008 reprint', 110, 'Natl. Book Store', 0, 1, '2008'),
(624, 387, 'Philosophy and Psychology', 'Fundamentals of Guidance and Counseling', 'Kapunan Rocio', 'Revised, 2007 reprint', 169, 'Rex Book Store', 0, 1, '1974'),
(625, 388, 'Philosophy and Psychology', 'Applied Consumer Psychology', 'Apruebo, Roxel A.', '1st', 243, 'Rex Book Store', 0, 1, '2005'),
(626, 389, 'Philosophy and Psychology', 'General Psychology', 'Sanchez, Custodiosa', '4th, 2010 reprint', 287, 'Rex Book Store', 0, 1, '2002'),
(627, 390, 'Philosophy and Psychology', 'Psychology Towards a New Millennium', 'Hernandez-Kahayon, Alicia', '2009 reprint', 438, 'Natl. Book Store', 0, 1, '2004'),
(628, 391, 'Philosophy and Psychology', 'Filipino Philosophy Today', 'Florentino, Timbreza', '', 323, 'Natl. Book Store', 0, 1, '2008'),
(629, 392, 'Philosophy and Psychology', 'Introduction to Philosophy', 'Felix Montemayor', 'Revised 2010 reprint', 268, 'Natl. Book Store', 0, 1, '1995'),
(630, 393, 'Philosophy and Psychology', 'Labor Economics', 'Pagoso, Cristobal', 'Updated, 2007 reprint', 343, 'Rex Book Store', 0, 1, '2006'),
(631, 394, 'Philosophy and Psychology', 'Introduction to Philosophy', 'Ramos, Christine Carmela', '2nd', 294, 'Rex Book Store', 0, 1, '2010'),
(632, 395, 'Philosophy and Psychology', 'The Law on Income Taxation w/ Illustration, Problems, and Solutions', 'De Leon, Hector', '13th', 0, 'Rex Book Store', 0, 1, '2009'),
(633, 396, 'Philosophy and Psychology', 'The Experienced of Philosophy', 'Articulo, Archimedes', '1st', 379, 'Rex Book Store', 0, 1, '2008'),
(634, 397, 'Philosophy and Psychology', 'Personality', 'Limpingco, Delia A.', '3rd', 166, 'Ken Incorporated', 0, 1, '2007'),
(635, 398, 'Philosophy and Psychology', 'Human Growth Development and Learning', 'Acero Victorina', '1st, 2010 reprint', 262, 'Rex Book Store', 0, 1, '2004'),
(636, 399, 'Philosophy and Psychology', 'Ground and Norm of Morality', 'Ramon, Reyes', 'revised', 150, 'Ateneo de Manila', 0, 1, '2009'),
(637, 400, 'Philosophy and Psychology', 'Essentials of Values Education', 'Priscilla Bauzon', '3rd', 169, 'Natl. Book Store', 0, 1, '2009'),
(638, 401, 'Philosophy and Psychology', 'Introductory to Sociology and Anthropology: A Pedagogy', 'Jeavier, Jessie', '1st, 2006 reprint', 491, 'Rex Book Store', 0, 1, '2002'),
(639, 402, 'Philosophy and Psychology', 'Philosophy of Education', 'Ordas-Botor, Celeste', '', 133, 'National Book Store', 0, 1, '2005'),
(640, 403, 'Philosophy and Psychology', 'Convention and Event Management', 'Zenaida L. Cruz', '2nd, 2009 reprint', 192, 'National Book Store', 0, 1, '2006'),
(641, 404, 'Philosophy and Psychology', 'Logic for Filipinos', 'Bauzon, Priscillano', '2nd, 2009 reprint', 251, 'Natl. Book Store', 0, 1, '2002'),
(642, 405, 'Philosophy and Psychology', 'A Breakthrough in School Guidance & Counseling', 'Doris D. Tulio', '', 213, 'Natl. Book Store', 0, 1, '2008'),
(643, 406, 'Philosophy and Psychology', 'Guidance and Counseling Today', 'Decal-Mendoza Elenita', '1st, 2005 reprint', 94, 'Rex Book Store', 0, 1, '2003'),
(644, 407, 'Philosophy and Psychology', 'Instructional Modules on Sex Education for College Students', 'Fontanilla, Ma. Alodia', '1st', 294, 'Rex Book Store', 0, 1, '2003'),
(645, 0, 'category', 'title', 'author', 'edition', 0, 'publisher', 0, 0, 'copyright'),
(646, 408, 'Statistics & Research', 'Probability and Statistical Concepts: An Introduction', 'Bola?os, Alex B.', '1st, 2010 reprint', 211, 'Rex Book Store', 0, 1, '1997'),
(647, 409, 'Statistics & Research', 'Euthenics', 'Ryan Malenab', '', 34, 'Natl. Book Store', 0, 1, '2008'),
(648, 410, 'Statistics & Research', 'Fundamentals of Management', 'Lantion, Clarita', '1st, 2001 reprint', 125, 'Rex Book Store', 0, 1, '1998'),
(649, 411, 'Statistics & Research', 'Quantitative Approaches in Decision Making with Computer Application', 'Copo, et. Al', '', 312, 'Rex Book Store', 0, 1, '2009'),
(650, 412, 'Statistics & Research', 'Statistics Based on CMO O3 Series 2007', 'Arao, Rosalia R. et.al', '1st', 250, 'Rex Book Store', 0, 1, '2010'),
(651, 413, 'Statistics & Research', 'Entrepreneurship and Small Business Management', 'Medina, Roberto G.', '2nd', 232, 'Rex Book Store', 0, 1, '2010'),
(652, 414, 'Statistics & Research', 'The Law and Accounting of Transfer and Business Taxation', 'Conti, Indalicio', '1st', 425, 'Rex Book Store', 0, 1, '2009'),
(653, 415, 'Statistics & Research', 'The Law on Business Organization', 'Torres Jr., Justo P.', '', 385, 'Rex Book Store', 0, 1, '2008'),
(654, 416, 'Statistics & Research', 'The Law on Insurance and Sales', 'De Leon, Hector S.', '2003 reprint', 404, 'Rex Book Store', 0, 1, '2000'),
(655, 417, 'Statistics & Research', 'Economics: 2 Macroeconomics', 'Sicat, Gerardo', 'new', 467, 'Anvil', 0, 1, '2003'),
(656, 418, 'Statistics & Research', 'Philippine Economic and Development Issues', 'Sicat, Gerardo', 'new', 387, 'Natl. Book Store', 0, 1, '2003'),
(657, 419, 'Statistics & Research', 'How to Write a Thesis', 'Rowena Muray', '2nd', 301, 'Open University Press', 0, 1, '2006'),
(658, 420, 'Statistics & Research', 'Fundamental Concepts and Methods in Statistics Part 2', 'Garcia, George', '', 341, 'University of Sto. Tomas', 0, 1, '2004'),
(659, 421, 'Statistics & Research', 'Personnel and Human Resources Management', 'Medina, Roberto G.', '2010 reprint', 275, 'Rex Book Store', 0, 1, '2008'),
(660, 422, 'Statistics & Research', 'Technology Education in the Philippines', 'Camarao, Fedesario', '2004 reprint', 448, 'Natl. Book Store', 0, 1, '1991'),
(661, 423, 'Statistics & Research', 'Teaching Strategies in Livelihood & Vocational Education', 'Dagoon, Jesse', '1st, 2006 reprint', 391, 'Rex Book Store', 0, 1, '2003'),
(662, 424, 'Statistics & Research', 'Human Resource Management', 'Corpuz, Crispina', 'Revised , 2009 reprint', 364, 'Rex Book Store', 0, 1, '2006'),
(663, 425, 'Statistics & Research', 'Foundations of Educations Vol. 1', 'Recto, Angel', '1st reprint', 309, 'Rex Book Store', 0, 1, '2005'),
(664, 426, 'Statistics & Research', 'Human Behavior in Business Organizations', 'Mison, Lone', '2010 reprint', 329, 'Natl. Book Store', 0, 1, '2004'),
(665, 427, 'Statistics & Research', 'Organizational Behavior and Management in Philippine Organizations', 'Zarate, Cynthia A.', '1st, 2009 reprint', 214, 'Rex Book Store', 0, 1, '2006'),
(666, 428, 'Statistics & Research', 'Introduction to Asia', 'Irapta, Angelina', '1st, 2008 reprint', 219, 'Rex Book Store', 0, 1, '2005'),
(667, 429, 'Statistics & Research', 'Political Science Made Simple', 'Abriel M. Nebres', '2009 reprint', 251, 'Natl. Book Store', 0, 1, '2007'),
(668, 430, 'Statistics & Research', 'Foundations of Educations Vol. II', 'Recto, Angel', '1st reprint', 137, 'Rex Book Store', 0, 1, '2005'),
(669, 431, 'Statistics & Research', 'Contemporary Social Problems & Issues', 'Sanchez, Custodiosa', '3rd, 2009 reprint', 286, 'Natl. Book Store', 0, 1, '1997'),
(670, 432, 'Statistics & Research', 'Glossary of Statistical Terms of Statisticians, Researches', 'Birion, Juan', '1st, 2000 reprint', 247, 'Rex Book Store', 0, 1, '1998'),
(671, 433, 'Statistics & Research', 'Introduction to Sociology and Anthropology', 'Palispis, Epitacio', 'Revised , 2008 reprint', 497, 'Rex Book Store', 0, 1, '2007'),
(672, 434, 'Statistics & Research', 'General Sociology: A Simplified Approach', 'Colon, Salvacion', 'revised', 256, 'Natl. Book Store', 0, 1, '2010'),
(673, 435, 'Statistics & Research', 'Sociology: Focus on the Philippines', 'Panopio, Isabel S.', '4th', 477, 'Ken Incorporated', 0, 1, '2004'),
(674, 436, 'Statistics & Research', 'Statistics made Simple for Researchers', 'Assad, Abubakar S.', '1st', 0, 'Rex Book Store', 0, 1, '2008'),
(675, 437, 'Statistics & Research', 'Anthropological & Sociological Concept and Perspective', 'Zulueta, Francisco', '2009 reprint', 433, 'Natl. Book Store', 0, 1, '2006'),
(676, 438, 'Statistics & Research', 'Social Research', 'Reyes, Milagros Z.', '1st, 2004 reprint', 187, 'Rex Book Store', 0, 1, '2004'),
(680, 1232133123, 'Programming', '213213', '123', '123', 123, '123', 0, 100, '2018'),
(681, 12, 'Programming', 'MS Excel 2018', 'Jemma Development Team', 'version 1.1', 200, 'Jemma Corp.', 0, 100, '2018'),
(682, 32333, 'Programming', '333333', '3333', '333', 33333, '33333', 2147483647, 200, '2018');

-- --------------------------------------------------------

--
-- Table structure for table `borrow_tb`
--

CREATE TABLE `borrow_tb` (
  `id` int(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `stud_num` int(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `book_num` int(100) NOT NULL,
  `isbn` int(50) NOT NULL,
  `avail_copies` int(11) NOT NULL,
  `copies` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrow_tb`
--

INSERT INTO `borrow_tb` (`id`, `lname`, `fname`, `stud_num`, `title`, `book_num`, `isbn`, `avail_copies`, `copies`, `date`) VALUES
(3, '221', '1', 1, 'MS Excel 2010', 1, 2147483647, 0, 1, '2005-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `id` int(11) NOT NULL,
  `last` varchar(50) NOT NULL,
  `first` varchar(50) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `stud_num` int(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`id`, `last`, `first`, `grade`, `section`, `stud_num`, `username`, `email`, `password`, `repassword`) VALUES
(22, 'chavez', 'Jumar', '12', 'IC2DA', 161082, 'jumar_chavez', 'jumarchavez@yahoo.com', 'admin', 'admin'),
(23, 'cha', 'cha', '11', 'cha', 1212, 'cha', 'cha@yahoo.com', 'cha', 'cha'),
(26, 'dela Cruz', 'Joyce', '11', 'GA1MA', 121212, 'joyt', 'joyt@yahoo.com', 'yahyahyah', 'yahyahyah'),
(30, 'Alimpia', 'Jerone', '12', 'IC2Ma', 101010, 'jerone123', 'jerone@yahoo.com', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrow_tb`
--
ALTER TABLE `borrow_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=683;

--
-- AUTO_INCREMENT for table `borrow_tb`
--
ALTER TABLE `borrow_tb`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
