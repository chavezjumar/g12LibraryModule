<?php
include ('header_index.php');
?>

	<div class="container">	
	</div>	
	<body class="container">
	<div class="loginbody">
<div class="signupbody"><br><br><br>
	<center>
		<div class="modal-content">
		<form method="post" action="register.php"><br>
			<h4>Registration</h4><br>
				<label>Name:</label>
					<input type="text" class="input-sm" name="last" placeholder="Last" required>
					<input type="text" class="input-sm" name="first" placeholder="First" required><br>
				<label>Grade:</label>
					<input type="number" class="input-sm" name="grade" placeholder="Grade" required>
					<input type="text" class="input-sm" name="section" placeholder="Section" required><br>
				<label>Student Number:</label>
					<input type="number" class="input-sm" name="stud_num" maxlength="6" required><br>
				<label>Username:</label>
					<input type="text" class="input-sm" name="username" required><br>
				<label>Email:</label>
					<input type="email" class="input-sm" name="email" required><br>
				<label>Password:</label>
					<input type="password" class="input-sm" name="password" required><br>
				<label>Confirm Password:</label>
					<input type="password" class="input-sm" name="repassword" required><br><br>
					
				<input type="submit" id="btn" class="btn-primary" value="Submit" name="submit">
			</form>
			
			<a href="index.php" class="bak_1"><button class="btn-primary">back</button></a>
		</div>
	</center>
	</div>
</div>
</body>
<?php
include('footer.php');
?>