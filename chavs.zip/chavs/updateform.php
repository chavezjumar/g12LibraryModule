<?php
error_reporting(0);

$id= $_GET['id'];
$bookname= $_GET['bookname'];
$booknumber= $_GET['booknumber'];
$category= $_GET['category'];
$isbn= $_GET['isbn'];
$author= $_GET['author'];
?>

<style>

input{
	display:block;
	margin-left:5px;
} 

select{
	display:block;
	margin-left:5px;
} 

</style>

<head>

<title>Register</title>
	
</head>
	
	
<body>
<label>Update Info</label>
<form action="update.php" method="post" enctype="multipart/form-data">
ID:<input type="text" name="id" value="<?=$id?>">
Bookname:<br><input type="text" name="bookname" value="<?=$bookname?>"><br>
Booknumber:<br> <input type="number" name="booknumber" value="<?=$booknumber?>"><br>
Category:	<select name="category" value="<?=$category?>">
				<option value="mathematics">Mathematics</option>
				<option value="business">Business</option>
				<option value="programming">Programming</option>
				<option value="fiction">Fiction</option>
			<select><br>
ISBN:<br><input type="number" name="isbn" type="text"  maxlength="50"  autocomplete="off" value="<?=$isbn?>"><br>
Author:<br>	<input type="text" name="author" type="text" value="<?=$author?>"><br>


<a href="home.php?user=<?=$bookname?>">&laquo Back</a>
<button type="submit" class="button">Update</button>

</ul>
</form>

						
</body>
	
	