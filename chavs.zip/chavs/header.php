<head>
	<meta charset="UTF-8">
		<title>awlm.com</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/style.css">
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">

	</head>
	<body>
		<header>
			<a href="home.php"><img src="images/LOGO2.png" alt="logo" class="logo" ></a><br>
			<h1 class="head">Asian Institute of Computer Studies</h1>
		</header>
		<style type="text/css">
		.a_header{
	display:inline-block;
	margin-right:20px;
	margin-bottom:0px;
	background:#0066cc;
	color:white;
	padding:10px;
	border-radius:5px;
}
			.a_header:hover{
	display:inline-block;
	margin-right:20px;
	margin-bottom:0px;
	background:white;
	padding:10px;
	color:black;	
	border-radius:5px;
	}
		</style>

		<div class="div_hdr">
	<a class="a_header" href="	home.php">HOME</a>
	<a class="a_header" href="	borrow_tb.php">BORROW TABLE</a>
	<a class="a_header" href="	signupform.php">ADD LIBRARIAN</a>
	<a class="a_header" href="	logout.php" onclick="return confirm('Do you really want to Logout?');">LOGOUT</a>
	<br><br>
	</div>
	