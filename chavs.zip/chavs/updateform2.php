<?php
error_reporting(0);

$id= $_GET['id'];
$username= $_GET['username'];
$password= $_GET['password'];
$fname= $_GET['fname'];
$lname= $_GET['lname'];
$email= $_GET['email'];
?>

<style>

li{
	display:block;
	height:30;
}


</style>

<head>

<title>Register</title>
	
</head>
	
	
<body>
<label>Update Info</label>
<form action="update2.php?id=<?=$id?>" method="post" enctype="multipart/form-data">
<ul>
<li><input name="fname" placeholder="First Name" value="<?=$fname?>"></li>
<li><input name="lname" placeholder="Last Name" value="<?=$lname?>"></li>
<li><input name="username" placeholder="New Username" value="<?=$username?>"></li>
<li><input name= "email" placeholder="New Email address" type="text"  maxlength="50"  autocomplete="off" value="<?=$email?>"></li>
<li><input id="password" name="password" placeholder="New Password" type="password" value="<?=$password?>"></li>

<li><label for="file">New Profile:</label>
<input type="file" name="image"></li>

<a href="home.php?user=<?=$username?>">&laquo Back</a>
<button type="submit" class="button">Update</button>

</ul>
</form>

						
</body>
	
	