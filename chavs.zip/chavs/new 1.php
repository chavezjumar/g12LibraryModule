<html>

<?php 
 echo "Hello World."

?>


<script>
</script>
<style>


	<tr>
		<th colspan="7">List of Books</th>
		<th><a style="float:right; " href="addbooks.php">add</a></th>

	</tr>

	<tr>
		<th colspan="8">
			<form action="search.php" method="GET">
			<label>Search By:</label>
			<select name="filter">
				<option></option>
				<option value="id">No.</option>
				<option value="title">Title</option>
				<option value="author">Author</option>
				<option value="edition">Edition</option>
				<option value="publisher">Publisher</option>
			</select>
			
				<input type="search" name="keyword" placeholder="Search"/>
				<input type="submit" value="search">
			</form>	
		</th>
	</tr>

	<tr>
		<th>No.</th>
		<th>Title</th>
		<th>Author</th>
		<th>Edition</th>
		<th>Pages</th>
		<th>Publisher</th>
	
	</tr>








</style>

</html>

	<tr>
		<th style="height:30px; width:750px;">No.</th>
		<th style="height:30px; width:750px;">Title</th>
		<th style="height:30px; width:750px;">Author</th>
		<th style="height:30px; width:750px;">Edition</th>
		<th style="height:30px; width:750px;">Pages</th>
		<th style="height:30px; width:750px;">Publisher</th>
	
	</tr>

	
	<tr>
		<th colspan="8">
			<form action="search.php" method="GET">
			<label>Search By:</label>
			<select name="filter">
				<option></option>
				<option value="id">No.</option>
				<option value="title">Title</option>
				<option value="author">Author</option>
				<option value="edition">Edition</option>
				<option value="publisher">Publisher</option>
			</select>
			
				<input type="search" name="keyword" placeholder="Search"/>
				<input type="submit" value="search">
			</form>	
		</th>
	</tr>

	
