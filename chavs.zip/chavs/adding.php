<?php

$host="localhost";
$root="root";
$dbpass="";
$dbname="thesis";
$konekta=new mysqli($host,$root,$dbpass,$dbname);


if(mysqli_error($konekta)){
	echo "hindi ka konektado sa i yong database";
}else{

	
$number=$_POST['number'];
$category=$_POST['category'];
$title=$_POST['title'];
$author=$_POST['author'];
$edition=$_POST['edition'];
$pages=$_POST['pages'];
$publisher=$_POST['publisher'];
$isbn=$_POST['isbn'];
$copies=$_POST['copies'];
$copyright=$_POST['copyright'];


$resulta =  $konekta->query("SELECT * from books where  isbn ='$isbn' ");
$bilang = $resulta->num_rows;

if($bilang == 1){
	
	echo "<script>alert('Books is already existing!');history.back();</script>";
}else{
$result =  $konekta->query("INSERT INTO books 
					(number,category,title,author,edition,pages,publisher,isbn,copies,copyright) 
					values('$number','$category','$title','$author', '$edition', '$pages', '$publisher', '$isbn', '$copies', '$copyright')   ");
				
echo "<script>alert('You Add Books Successfully!');window.location.href='home.php'</script>";	 
}
}
mysqli_close($konekta);

?>


