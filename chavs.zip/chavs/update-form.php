<?php
include('header.php');


$id=$_GET['id'];
$number=$_GET['number'];
$category=$_GET['category'];
$title=$_GET['title'];
$author=$_GET['author'];
$edition=$_GET['edition'];
$pages=$_GET['pages'];
$publisher=$_GET['publisher'];
$isbn=$_GET['isbn'];
$copies=$_GET['copies'];
$copyright=$_GET['copyright'];

?>
<style type="text/css">

		input{margin: 5px;
			display: inline-block;
			height: 37px;
			width: 210px;
			border-radius: 5px;	
			padding: 5px;

		}
		button{margin: 5px;
			display: inline-block;
			height: 37px;
			width: 150px;
			border-radius: 5px;	
			padding: 5px;

		}

				button{margin: 5px;
			display: inline-block;
			height: 37px;
			width: 150px;
			border-radius: 5px;	
			padding: 5px;		

		}


		button:hover{margin: 5px;
			display: inline-block;
			height: 37px;
			width: 150px;
			border-radius: 5px;	
			padding: 5px;
			background-color: gray;
			color: white;
		}

		label{margin: 5px;
			display: inline-block;		
		}
	

</style>	
<div class="container">	

	</div>
<br><br>

	<body class="container">
	<div class="body_search">
		<center>


<div id="content"><br><br><br><br>
<h1>Update</h1>
<form class="insert-form" method="POST" action="update.php">
<br>
<label>ID:</label><input type="number" name="id" value="<?=$id?>" readonly><br>
<label>Book Number:</label><input type="number" name="number" value="<?=$number?>"><br>
<label>Category:</label>
									<select class="inpt_add" name="category" value="<?=$category?>">Category
									<option class="inpt_add" value="Programming">Programming</option>
									<option class="inpt_add" value="Operating Books">Operating Books</option>
									<option class="inpt_add" value="Computer Dictionaries">Computer Dictionaries</option>
									<option class="inpt_add" value="Computer Books">Computer Books</option>
									<option class="inpt_add" value="Electronic Books">Electronic Books</option>
									<option class="inpt_add" value="Math Books">Math Books</option>
									<option class="inpt_add" value="Acctg, Management & Marketing">Acctg, Management & Marketing</option>
									<option class="inpt_add" value="Economic, Humanities & Law">Economic, Humanities & Law</option>0
									<option class="inpt_add" value="Business Books">Business Books</option>
									<option class="inpt_add" value="Philosophy and Psychology">Philosophy and Psychology</option>
									<option class="inpt_add" value="Statistics & Research">Statistics & Research</option>
									<option class="inpt_add" value="P.E Books">P.E Books</option>
									<option class="inpt_add" value="English Books">English Books</option>
									<option class="inpt_add" value="k-12 Books">k-12 Books</option>
									<option class="inpt_add" value="Teaching and Learning Guidelines">Teaching and Learning Guidelines</option>
									
								<select>


<br>
<label>Title:</label><input type="text" name="title" value="<?=$title?>"><br> 
<label>Author:</label><input type="text" name="author" value="<?=$author?>"><br>
<label>Edition:</label><input type="text" name="edition" value="<?=$edition?>"><br>
<label>Pages:</label><input type="number" name="pages" value="<?=$pages?>"><br>						
<label>Publisher:</label><input type="text" name="publisher" value="<?=$publisher?>"><br>
<label>ISBN:</label><input type="number" name="isbn" value="<?=$isbn?>" maxlength="225"><br>
<label>Copies:</label><input type="number" name="copies" value="<?=$copies?>"><br>						
<label>Copyright:</label><input type="number" name="copyright" value="<?=$copyright?>"><br>						
						
	<a href="home.php" >Back</a>						
	<button type="submit" >UPDATE</button>
</a>



<br><br><br>

</form>
</center>
</div>
</body>

<?php
include('footer.php');
?>	