<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>awls.com</title>
<link rel="stylesheet" type="text/css" href="bootstrap/css/style.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">

</head>
<body>
<header>
		<a href="index.php"><img src="images/LOGO2.png" alt="logo" class="logo" ></a><br>
		<h1 class="head">Asian Institute of Computer Studies</h1>
</header>
	<div class="container">
		<nav>
			<ul>
				<li><a href="index.php">HOME</a></li>
				<li><a href="loginform.php">LOG IN</a></li>
				<li><a href="#">ABOUT</a></li>
				<li><a href="signupform.php">SIGNUP</a></li> 
			</ul>
		</nav>
	</div>	


<div class="loginbody">
<br><br><br>

</div>

<footer><br>
Copyright All Rights Reserved &copy 2018 AWLS
</footer>
</body>
</html>