<?php
session_start();
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="thesis";
$connect = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$un = $_SESSION["email"];
$pw = $_SESSION["password"];

$sql = $connect->query("SELECT * from librarian where email = '$un' AND password = '$pw' ");
$row = mysqli_fetch_array($sql);
$user=$row['email'];
$pass=$row['password'];
//echo $check;
if(!isset($user)||!isset($pass)){
header('Location: ../home.php');
}

?>
