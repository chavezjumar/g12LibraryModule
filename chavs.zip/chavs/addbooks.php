
<?php
	include ('header.php');
	?>
<div class="container">
	<center>
		<div class="add_body"><br>
		<h2 class="ad_h1">Add Books</h2>
			<form class="insert-form" method="POST" action="adding.php" enctype="multipart/form-data">
	
				<label class="lbl_add">No:</label>
					<input class="inpt_add"type="number" name="number" required><br>
				<label class="lbl_add">Category:</label>
									<select class="inpt_add" name="category" >Category
									<option class="inpt_add" value="Programming">Programming</option>
									<option class="inpt_add" value="Operating Books">Operating Books</option>
									<option class="inpt_add" value="Computer Dictionaries">Computer Dictionaries</option>
									<option class="inpt_add" value="Computer Books">Computer Books</option>
									<option class="inpt_add" value="Electronic Books">Electronic Books</option>
									<option class="inpt_add" value="Math Books">Math Books</option>
									<option class="inpt_add" value="Acctg, Management & Marketing">Acctg, Management & Marketing</option>
									<option class="inpt_add" value="Economic, Humanities & Law">Economic, Humanities & Law</option>0
									<option class="inpt_add" value="Business Books">Business Books</option>
									<option class="inpt_add" value="Philosophy and Psychology">Philosophy and Psychology</option>
									<option class="inpt_add" value="Statistics & Research">Statistics & Research</option>
									<option class="inpt_add" value="P.E Books">P.E Books</option>
									<option class="inpt_add" value="English Books">English Books</option>
									<option class="inpt_add" value="k-12 Books">k-12 Books</option>
									<option class="inpt_add" value="Teaching and Learning Guidelines">Teaching and Learning Guidelines</option>
									
								<select>
								<br>
				<label class="lbl_add">Title:</label>
					<input class="inpt_add"type="text" name="title" required><br>
				<label class="lbl_add">Author:</label>
					<input class="inpt_add"type="text" name="author" required><br>
							
				<label class="lbl_add">Edition:</label>
					<input class="inpt_add" type="text" name="edition" ><br>
				<label class="lbl_add">Pages:</label>
					<input class="inpt_add" type="number" name="pages"><br><br>
				<label class="lbl_add">Publisher:</label>
									<input class="inpt_add" type="text" name="publisher" required><br><br>
				<label class="lbl_add">ISBN:</label>
									<input class="inpt_add" type="number" name="isbn" required><br><br>
				<label class="lbl_add">No. of Copies:</label>
									<input class="inpt_add" type="number" name="copies" required><br><br>
				<label class="lbl_add">Copyright:</label>
									<input class="inpt_add" type="number" name="copyright" required>

					<input class="btn_add" type="submit" value="ADD BOOKS" style="float:right; margin-right:30px;">
	
	
			</form>
	<br><br>
		</div>
	</center>
</div>
<?php
	include ('footer.php');
	?>
