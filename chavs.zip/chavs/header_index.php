<head>
	<meta charset="UTF-8">
		<title>awlm.com</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/style.css">
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">

	</head>
	<body>
		<header>
			<a href="index.php"><img src="images/LOGO2.png" alt="logo" class="logo" ></a><br>
			<h1 class="head">Asian Institute of Computer Studies</h1>
		</header>
		
		</head>