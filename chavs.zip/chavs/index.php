<!DOCTYPE html>
<html>
<?php


include ('header_index.php');



?>

	<div class="container">	
	</div>
	<body class="container">
			<div class="loginbody"><br><br><br>
		<center>
			<form method="POST" class="modal-content" action="login.php"><br>
			<center>
			<h4>Login</h4><br>
				<label>Email:</label> <br>		<input type="email" class="input-sm" name="email" required><br><br>
				<label>Password:</label><br>	<input type="password" class="input-sm" name="password" required><br><br>
				<input type="submit" class="btn-primary" value="Login" name="loginsubmit"><br>

				<a href="signupform1.php">Not yet Registered?</a>
			</center>
			</form>
		</center>
	</div>
	<footer><br>
		Copyright All Rights Reserved &copy 2018 AWLS
	</footer>
	</body>
</html>
