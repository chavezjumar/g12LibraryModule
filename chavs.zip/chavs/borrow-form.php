<?php

include('header.php');

$number=$_GET['number'];
$category=$_GET['category'];
$title=$_GET['title'];
$author=$_GET['author'];
$edition=$_GET['edition'];
$pages=$_GET['pages'];
$publisher=$_GET['publisher'];
$isbn=$_GET['isbn'];
$copies=$_GET['copies'];


$date = date("m/d/Y")

?>
<style>
input{margin:5px;
		text-align:center;

}
</style>

	<div class="container">	

	</div>
<br><br>

	<body class="container">
	<div class="body_search">
		<center>


<div id="content"><br><br><br><br>
<h1>Borrow</h1>
<form class="insert-form" method="GET" action="borrow.php">
<br>
<label>Total Books:</label><br><input type="number" name="copies" value="<?=$copies?>"readonly><br>
<label>Book Number:</label><br><input type="number" name="book_num" value="<?=$number?>"readonly><br>
<label>Title:</label><br><input type="text" name="title" value="<?=$title?>"readonly><br>
<label>ISBN:</label><br><input type="number" name="isbn" value="<?=$isbn?>"readonly><br>
<label>Name:</label><br><input type="text" name="lname" placeholder="Last">
						<input type="text" name="fname" placeholder="First"><br>
<label>Student Number:</label><br><input type="number" name="stud_num" maxlength="6"><br>
<label>Number of Books To Borrow:</label><br><input type="number" name="mcopies"><br>
<label>Date:</label><br><input type="text" name="date" value="<?=$date?> " readonly>					
						
						
						
						
	<button type="submit" >Submit</button>
</a>



<br><br><br>

</form>
</center>
</div>
</body>

<?php
include('footer.php');
?>	