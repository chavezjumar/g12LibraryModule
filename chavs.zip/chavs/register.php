<?php
session_start();
$username="";
$password2="";

$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="thesis";

$connect = new mysqli ($dbhost,$dbusername,$dbpassword,$dbname);
	
$last=$_POST['last'];
$first=$_POST['first'];
$grade=$_POST['grade'];
$section=$_POST['section'];
$stud_num=$_POST['stud_num'];
$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];
$repassword=$_POST['repassword'];


if($password == $repassword){
	
	$result =  $connect->query("SELECT * from librarian where first ='$first' AND last ='$last' AND stud_num ='$stud_num' ");
$numrow = $result->num_rows;
if($numrow==1){
	
	echo "<script>alert('Librarian is already existing!');history.back();</script>";
}else{
	$result =  $connect->query("INSERT INTO librarian 
					(last,first,grade,section,stud_num,username,email,password,repassword) 
					values('$last','$first','$grade','$section', '$stud_num', '$username', '$email', '$password', '$repassword')   ");


			$_SESSION['username'] = $username;
					
echo "<script>alert('Registation Successful!');window.location.href='index.php'</script>";	
}
}else{
echo "<script>alert('Password Did Not Match');history.back();</script>";
}
?>