<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="thesis";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);



$id = $_GET['id'];
$book_num = $_GET['book_num'];

$copies = $_GET['copies'];
$avail_copies1 = $_GET['avail_copies1'];


	$minus = $copies + $avail_copies1 ;

		
		$resulta =  $dbserver->query("DELETE from borrow_tb where id='$id' ");
			


	$result =  $dbserver->query("UPDATE books SET copies='$minus' where number='$book_num' ");				
		


					

	echo "<script>alert('You Return it Successfully');window.location.href='home.php';</script>";	


?>

