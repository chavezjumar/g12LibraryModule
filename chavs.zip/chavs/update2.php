<?php
$connect = mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("userdata",$connect) or die (mysql_error());

$id = $_GET['id'];
$email= ($_POST['email']);
$password= ($_POST['password']);
$username= ($_POST['username']);
$fname= ($_POST['fname']);
$lname= ($_POST['lname']);

				
if (!isset($_FILES['image']['tmp_name'])) {
	echo "<script>alert('Please complete all fields!');history.back();</script>";
	}else{
	
//To save photo
	addslashes(file_get_contents($_FILES['image']['tmp_name']));
	addslashes($_FILES['image']['name']);
	move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);

			$location="photos/" . $_FILES["image"]["name"];
			
//To update data from database			
	mysql_query("update account set 
			fname='".$fname."',
			lname='".$lname."',
			password='".$password."',
			username='".$username."',
			location='".$location."',
			email='".$email."' 
			where id = '".$id."' ");
					
	echo "<script>alert('Update successful!');window.location.href = 'index.php';</script>"; 
												
	}				
				
					

						
	
?>