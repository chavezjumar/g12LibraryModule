<?php

$host="localhost";
$root="root";
$dbpass="";
$dbname="thesis";
$konekta=new mysqli($host,$root,$dbpass,$dbname);


if(mysqli_error($konekta)){
	echo "hindi ka konektado sa i yong database";
}else{

	
$number=$_POST['number'];
$category=$_POST['category'];
$title=$_POST['title'];
$author=$_POST['author'];
$edition=$_POST['edition'];
$pages=$_POST['pages'];
$publisher=$_POST['publisher'];
$isbn=$_POST['isbn'];
$copies=$_POST['copies'];



$result =  $konekta->query("INSERT INTO books(number,category,title,author,edition,pages,publisher,isbn,copies) 
					values('$number','$title','$author','$edition','$pages','$publisher','$isbn','$copies') ");
				
echo "<script>alert('You added Stock  Successfully!');</script>";	
	}

mysqli_close($konekta);

?>


