<!DOCTYPE html>

<html lang="en">
	<?php
	include ('header.php');




	?>
	<style type="text/css">
			.a_borrow :hover{
		padding-left:23px;
		padding-right:23px; 
		padding-bottom:5px;
		padding-top:3px;
		background:red;
		color:white;
	}

.td_borrow :hover{
	padding-left:23px;
	padding-right:23px; 
	padding-bottom:5px;
	padding-top:3px;
	background:gray;
	color:white;
}
	.a_borrow{
		padding-left:23px;
		padding-right:23px; 
		padding-bottom:5px;
		padding-top:3px;
		background:gray;
		color:white;
		display: block;
	}

	</style>
	
	<div class="container">	
	</div>	
<div class="body">
	<?php
		$dbhost="localhost";
		$dbusername="root";
		$dbpassword="";
		$dbname="thesis";
			$connect = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);
			
			//To display all data from database
		$result =  $connect->query("SELECT * FROM books");
			$numrow = $result->num_rows;
		$results =  $connect->query("SELECT * FROM librarian ");
			$numrows = $result->num_rows;
	
	?>
	<br>
		<center>
	
				<h1>Welcome</h1>
			
			<table border=1	 style="border-radius:20px; height:auto; width:auto;">
			
				<tr>
					<th  style="text-align:center; font-size:20px;" colspan="10">List of Books </th>
					<th  style="text-align:center; padding:20px; font-size:20px;" colspan="1" rowspan="auto"><a href="addbooks.php">ADD</a></th>
				</tr>
			
				<tr>
					<td colspan="11" style="height:40px;"><center>								
					
						<form action="search.php" method="POST"  >
						<label style="font-size:17px;">Search By:</label>
						<select style="font-size:17px;" name="filter">
							<option value="number">No.</option>
							<option value="category">Category</option>
							<option value="title">Title</option>
							<option value="author">Author</option>
							<option value="edition">Edition</option>
							<option value="publisher">Publisher</option>
							<option value="isbn">ISBN</option>
							<option value="copyright">Copyright</option>
						</select>
						
							<input style="font-size:17px;" type="search" name="keyword" placeholder="Search">
							<input style="font-size:17px;" type="submit" value="search">
							</center>
						</form>	
					
					</td>
				</tr>
			
				<tr>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>No.</u></th>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>Category</u></th>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>Title</u></th>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>Author</u></th>
					<th style="text-align:center; height:30px; width:200px; font-size:17px;"><u>Edition</u></th>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>Pages</u></th>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>Publisher</u></th>
					<th style="text-align:center; height:30px; width:100px; font-size:17px;"><u>ISBN</u></th>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>No. of Copies</u></th>
					<th style="text-align:center; height:30px; width:auto; font-size:17px;"><u>Copyright</u></th>
						<th style="text-align:center; height:30px; width:500px; font-size:17px;"><u>Action</u></th>
	
				</tr>
			
			<?php
				
			if($numrow==0){
			echo "<tr><td colspan=11 style='color:black;'><i><b>Not Available</b></	i></td></tr>";
			}else{
			
				
				while($row = mysqli_fetch_assoc($result)){
			?>
			
			<tr>
			<td><?=$row['number']?></td>
			<td><?=$row['category']?></td>
			<td><strong><?=$row['title']?></strong></td>
			<td><?=$row['author']?></td>
			<td><?=$row['edition']?></td>
			<td><?=$row['pages']?></td>
			<td><?=$row['publisher']?></td>
			<td><?=$row['isbn']?></td>
			<td><?=$row['copies']?></td>
			<td><?=$row['copyright']?></td>
			
			<td class="td_borrow"><a id="a_borrow" href="update-form.php?
					id=<?=$row['id']?>
					&number=<?=$row['number']?>
					&category=<?=$row['category']?>
					&title=<?=$row['title']?>
					&author=<?=$row['author']?>
					&edition=<?=$row['edition']?>
					&pages=<?=$row['pages']?>
					&publisher=<?=$row['publisher']?>
					&isbn=<?=$row['isbn']?>
					&copies=<?=$row['copies']?>
					&copyright=<?=$row['copyright']?>
					" style=" padding-left:30px; padding-right:30px; border:1px;padding-bottom:5px; padding-top:5px;">
					Update
				</a> &nbsp

			<a id="a_borrow" href="borrow-form.php?
					number=<?=$row['number']?>
					&category=<?=$row['category']?>
					&title=<?=$row['title']?>
					&author=<?=$row['author']?>
					&edition=<?=$row['edition']?>
					&pages=<?=$row['pages']?>
					&publisher=<?=$row['publisher']?>
					&isbn=<?=$row['isbn']?>
					&copies=<?=$row['copies']?>
					&copyright=<?=$row['copyright']?>
					" style="padding-left:30px; padding-right:30px; padding-bottom:5px; padding-top:5px;">
					Borrow
				</a>
			
			</tr>
			<?php
			}
			}
			?>
			</table>
			
<br><br><br><br><br><br><br><br><br>
</center>
					
</div>



<?php
include ('footer.php');
?>
</body>
</html>