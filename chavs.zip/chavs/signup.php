<?php
$connect = mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("thesis_db",$connect) or die (mysql_error());


$last= $_POST['last'];
$first= $_POST['first'];
$grade= $_POST['grade'];
$section= $_POST['section'];
$stud_num= $_POST['stud_num'];
$username= $_POST['username'];
$email= $_POST['email'];
$password= $_POST['password'];
$repassword= $_POST['repassword'];

if ($password == $repassword)
{
	mysql_query("INSERT librarian_tbl set 
			last='".$last."',
			first='".$first."',
			grade='".$grade."',
			section='".$section."',
			stud_num='".$stud_num."',
			email='".$email."',
			password='".$password."',
			repassword='".$repassword."' ");
	
    echo "<script>alert('Registration successful!');window.location.href = 'loginform.php';</script>";
	}
 else 
{
    echo "<script>alert('PASSWORD DID MATCH!');history.back();</script>";
}
	
			

?>