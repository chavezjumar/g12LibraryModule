<?php
session_start();
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="thesis";


$connect = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$un = $_POST['email'];
$pw = $_POST['password'];




$sql = $connect->query("SELECT * from librarian where email='$un' AND password = '$pw' ");
$count = $sql->num_rows;
if($count==1){
echo "<script>alert('Login Successful!');</script>";

$_SESSION['user'] = $un;
$_SESSION['pass'] = $pw;



	echo "<script>window.location.href='home.php'</script>";


}else{
echo "<script>alert('Login Failed!'); history.back();</script>";
}

mysqli_close($connect);

?>