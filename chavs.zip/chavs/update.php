<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="thesis";
$dbserver = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

$id=$_POST['id'];
$number=$_POST['number'];
$category=$_POST['category'];
$title=$_POST['title'];
$author=$_POST['author'];
$edition=$_POST['edition'];
$pages=$_POST['pages'];
$publisher=$_POST['publisher'];
$isbn=$_POST['isbn'];
$copies=$_POST['copies'];
$copyright=$_POST['copyright'];


$result =  $dbserver->query("SELECT * from books where id ='$id'");
$numrow = $result->num_rows;
if($numrow==1){
	
if($number==""||$category==""||$title==""||$author==""||$pages==""||$publisher==""||$copies==""){
	echo "<script>alert('Please complete all fields');history.back();</script>";
}else{
$result =  $dbserver->query("UPDATE books SET 
		number='$number',
		category='$category',
		title='$title',
		author='$author',
		edition='$edition',
		pages='$pages',
		publisher='$publisher',
		isbn='$isbn',
		copies='$copies',
		copyright='$copyright'
		where id='$id' ");				
echo "<script>alert('Book Updated Successfully!');window.location.href='home.php'</script>";	
}
}
			
?>

