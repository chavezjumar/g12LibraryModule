<?php
//This is for DB Connection
$dbhost="localhost";
$dbusername="root";
$dbpassword="";
$dbname="thesis";
$dbserver = new mysqli ($dbhost,$dbusername,$dbpassword,$dbname);

$lname=$_GET['lname'];
$fname=$_GET['fname'];
$stud_num=$_GET['stud_num'];
$title=$_GET['title'];
$book_num = $_GET['book_num'];
$isbn = $_GET['isbn'];
$date = $_GET['date'];
$copies = $_GET['copies'];
$mcopies = $_GET['mcopies'];

	$minus = $copies - $mcopies ;




if ($copies == 0){		echo "<script>alert('Sorry. Book is Not Available No Copies yet.');window.location.href='home.php';</script>";
		


}elseif($mcopies <= 0){
	echo "<script>alert('Warning! Invalid Input!! Please Borrow NOT LESS than the TOTAL of Books.');history.back();</script>";
}elseif($mcopies > $copies){
	echo "<script>alert('Warning! Invalid Input!! Please Borrow NOT MORE than the TOTAL of Books.');history.back();</script>";
}else{
	
	$result =  $dbserver->query("INSERT INTO borrow_tb 
					(lname,fname,stud_num,title,book_num,isbn,avail_copies,copies,date) 
					values('$lname','$fname','$stud_num','$title', '$book_num', '$isbn', '$minus', '$mcopies', '$date')   ");
					
	
					
					$result =  $dbserver->query("UPDATE books SET copies='$minus' where number='$book_num' ");				

	echo "<script>alert('You Borrow $title Successfully');window.location.href='home.php';</script>";	
}
?>