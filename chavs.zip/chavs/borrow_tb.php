<!DOCTYPE html>
<html lang="en">
	<?php
	include ('header.php');

	
	?>
	
	<div class="container">	
	</div>	
<body class="container-fluid">
	<div class="body_search">
				<?php
					$dbhost="localhost";
					$dbusername="root";
					$dbpassword="";
					$dbname="thesis";
						$connect = new mysqli($dbhost,$dbusername,$dbpassword,$dbname);
						//To display all data from database
					$result =  $connect->query("SELECT * FROM borrow_tb");
					
							$resulta =  $connect->query("SELECT * FROM books where title ");
					
					$numrow = $result->num_rows;
						
				
				?>
				<br>
					<center>
				
							<h1>Welcome !</h1>
						
						<table border=1	 style="border-radius:20px; height:auto; width:auto;">
						
							<tr>
								<th  style="text-align:center; font-size:20px;" colspan="7">Borrowed Books </th>
								<th  style="text-align:center; padding:20px; font-size:20px;" colspan="1" rowspan="auto"><a href="addbooks.php">ADD</a></th>
							</tr>
						
							<tr>
								<td colspan="8" style="height:40px;"><center>								
								
									<form action="borrow_search.php" method="POST"  >
									<label style="font-size:17px;">Search By:</label>
									<select style="font-size:17px;" name="filter">
										<option value="fname">First Name</option>
										<option value="lname">Last Name</option>
										<option value="stud_num">Student Number</option>
										<option value="title">Title</option>
										<option value="book_num">Book Number</option>										
										<option value="isbn">ISBN</option>
										<option value="date">Date</option>
									</select>
									
										<input style="font-size:17px;" type="search" name="keyword" placeholder="Search">
										<input style="font-size:17px;" type="submit" value="search">
										</center>
									</form>	
								
								</td>
							</tr>
						
							<tr>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">Name</th>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">Student Number</th>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">Title</th>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">Book Number</th>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">ISBN</th>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">No. of Copies</th>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">Date</th>
								<th style="text-align:center; height:80px; width:175px; font-size:17px;">Action</th>
								
							</tr>
						
						<?php
							
						if($numrow==0){
						echo "<tr><td colspan=8 style='color:black;'><i><b>No Available</b></	i></td></tr>";
						}else{
						
									





										while($row = mysqli_fetch_assoc($result)){
									?>
									
									<tr>
									<td><?=$row['lname']?> &nbsp <?=$row['fname']?></td>
									<td><?=$row['stud_num']?></td>
									<td><?=$row['title']?></td>
									<td><?=$row['book_num']?></td>
									<td><?=$row['isbn']?></td>									
									<td><?=$row['copies']?></td>
									<td><?=$row['date']?></td>
			
						<?php 

									$title1 = $row['title'];

							$resulta =  $connect->query("SELECT * FROM books where title = '$title1' ");

										$numrowa = $resulta->num_rows;

										if($numrowa==1){
											while ($rowa = mysqli_fetch_assoc($resulta)) {
											

								$avail_copies1 = $rowa['copies'];					
			
						 ?>
									<?php 
										}
										}
									 ?>
			
			
									<td>

										

									<a href="return.php?id=<?=$row['id']?>&book_num=<?=$row['book_num']?>&isbn=<?=$row['isbn']?>&avail_copies1=<?=$avail_copies1;?>&copies=<?=$row['copies']?>" onclick="return confirm('Do you Really Want To Return?');">Return</a></td>
									</tr>
									<?php
									}
									}
									?>
									</table>
									
								<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
								</center>
											
	</div>
			
</body>
						
							
									<?php
									include ('footer.php');
						?>
</html>